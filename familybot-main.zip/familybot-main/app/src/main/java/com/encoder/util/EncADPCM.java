package com.encoder.util;

/* loaded from: classes.dex */
public class EncADPCM {
    public static native int Encode(byte[] bArr, int i, byte[] bArr2);

    public static native int ResetEncoder();

    static {
        try {
            System.loadLibrary("ADPCMAndroid");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(ADPCMAndroid)," + localUnsatisfiedLinkError.getMessage());
        }
    }
}
