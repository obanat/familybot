package com.encoder.util;

/* loaded from: classes.dex */
public class EncSpeex {
    public static native int Encode(short[] sArr, int i, byte[] bArr);

    public static native int InitEncoder(int i);

    public static native int UninitEncoder();

    static {
        try {
            System.loadLibrary("SpeexAndroid");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(SpeexAndroid)," + localUnsatisfiedLinkError.getMessage());
        }
    }
}
