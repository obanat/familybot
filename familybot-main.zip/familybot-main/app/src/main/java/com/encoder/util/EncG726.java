package com.encoder.util;

/* loaded from: classes.dex */
public class EncG726 {
    public static final int API_ER_ANDROID_NULL = -10000;
    public static final byte FORMAT_ALAW = 1;
    public static final byte FORMAT_LINEAR = 2;
    public static final byte FORMAT_ULAW = 0;
    public static final int G726_16 = 0;
    public static final int G726_24 = 1;
    public static final int G726_32 = 2;
    public static final int G726_40 = 3;

    public static native int g726_enc_state_create(byte b, byte b2);

    public static native void g726_enc_state_destroy();

    public static native int g726_encode(byte[] bArr, long j, byte[] bArr2, long[] jArr);

    static {
        try {
            System.loadLibrary("G726Android");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(G726Android)," + localUnsatisfiedLinkError.getMessage());
        }
    }

    public static byte[] shortToByteSmall(short[] buf) {
        byte[] bytes = new byte[buf.length * 2];
        int i = 0;
        int j = 0;
        while (i < buf.length) {
            short s = buf[i];
            byte b1 = (byte) (s & 255);
            byte b0 = (byte) ((s >> 8) & 255);
            bytes[j] = b1;
            bytes[j + 1] = b0;
            i++;
            j += 2;
        }
        return bytes;
    }
}
