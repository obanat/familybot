package com.example.stickyheadergridview;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;

/* loaded from: classes.dex */
public class ImageScanner {
    private Context mContext;
    Cursor mCursorImage;
    Cursor mCursorVideo;

    /* loaded from: classes.dex */
    public interface ScanCompleteCallBack {
        void scanComplete(Cursor cursor, Cursor cursor2);
    }

    public ImageScanner(Context context) {
        this.mContext = context;
    }

    public void scanImages(final ScanCompleteCallBack callback) {
        final Handler mHandler = new Handler() { // from class: com.example.stickyheadergridview.ImageScanner.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                callback.scanComplete(ImageScanner.this.mCursorVideo, ImageScanner.this.mCursorImage);
            }
        };
        new Thread(new Runnable() { // from class: com.example.stickyheadergridview.ImageScanner.2
            @Override // java.lang.Runnable
            public void run() {
                Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                ContentResolver mContentResolver = ImageScanner.this.mContext.getContentResolver();
                String whereClause2 = "_data LIKE '" + Environment.getExternalStorageDirectory() + "/eMan/Shot/%'";
                String[] projection2 = {"_data", "_id", "title", "_display_name", "date_modified"};
                ImageScanner.this.mCursorVideo = mContentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection2, whereClause2, null, null);
                Log.e("size:", "mCursorVideo:" + ImageScanner.this.mCursorVideo.getCount());
                String whereClause = "_data LIKE '" + Environment.getExternalStorageDirectory() + "/eMan/Shot/%'";
                String[] projection = {"_data", "_id", "title", "_display_name", "date_modified"};
                ImageScanner.this.mCursorImage = mContentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, whereClause, null, null);
                Log.e("size:", "mCursorImage:" + ImageScanner.this.mCursorImage.getCount());
                Message msg = mHandler.obtainMessage();
                mHandler.sendMessage(msg);
            }
        }).start();
    }
}
