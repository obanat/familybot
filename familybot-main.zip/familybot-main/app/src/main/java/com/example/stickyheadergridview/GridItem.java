package com.example.stickyheadergridview;

/* loaded from: classes.dex */
public class GridItem {
    private int mediaKind;
    private int media_ID;
    private String path;
    private int section;
    private String time;

    public GridItem(String path, String time, int ikind) {
        this.path = path;
        this.time = time;
        this.mediaKind = ikind;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getSection() {
        return this.section;
    }

    public void setSection(int section) {
        this.section = section;
    }

    public int getMediaKind() {
        return this.mediaKind;
    }

    public void setMidia_ID(int ID) {
        this.media_ID = ID;
    }

    public int getMeida_ID() {
        return this.media_ID;
    }
}
