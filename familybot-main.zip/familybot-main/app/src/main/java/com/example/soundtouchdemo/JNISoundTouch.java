package com.example.soundtouchdemo;

/* loaded from: classes.dex */
public class JNISoundTouch {
    public native void putSamples(short[] sArr, int i);

    public native short[] receiveSamples();

    public native void setChannels(int i);

    public native void setPitchSemiTones(int i);

    public native void setRateChange(float f);

    public native void setSampleRate(int i);

    public native void setTempoChange(float f);

    static {
        System.loadLibrary("soundtouch");
    }
}
