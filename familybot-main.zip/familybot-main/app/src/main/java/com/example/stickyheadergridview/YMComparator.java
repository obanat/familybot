package com.example.stickyheadergridview;

import java.util.Comparator;

/* loaded from: classes.dex */
public class YMComparator implements Comparator<GridItem> {
    @Override // java.util.Comparator
    public int compare(GridItem o1, GridItem o2) {
        return o2.getTime().compareTo(o1.getTime());
    }
}
