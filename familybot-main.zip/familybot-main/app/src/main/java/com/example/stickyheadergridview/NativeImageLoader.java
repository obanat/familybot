package com.example.stickyheadergridview;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Handler;
import android.os.Message;
import android.support.v4.util.LruCache;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: classes.dex */
public class NativeImageLoader {
    private static final String TAG = NativeImageLoader.class.getSimpleName();
    private static NativeImageLoader mInstance = new NativeImageLoader();
    private static LruCache<String, Bitmap> mMemoryCache;
    private ExecutorService mImageThreadPool = Executors.newFixedThreadPool(1);

    /* loaded from: classes.dex */
    public interface NativeImageCallBack {
        void onImageLoader(Bitmap bitmap, String str);
    }

    private NativeImageLoader() {
        int maxMemory = (int) Runtime.getRuntime().maxMemory();
        int cacheSize = maxMemory / 4;
        mMemoryCache = new LruCache<String, Bitmap>(cacheSize) { // from class: com.example.stickyheadergridview.NativeImageLoader.1
            @Override // android.support.v4.util.LruCache
            public int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getRowBytes() * bitmap.getHeight();
            }
        };
    }

    public static NativeImageLoader getInstance() {
        return mInstance;
    }

    public Bitmap loadNativeImage(String path, NativeImageCallBack mCallBack) {
        return loadNativeImage(path, null, mCallBack);
    }

    public Bitmap loadNativeImage(final String path, final Point mPoint, final NativeImageCallBack mCallBack) {
        Bitmap bitmap = getBitmapFromMemCache(path);
        final Handler mHander = new Handler() { // from class: com.example.stickyheadergridview.NativeImageLoader.2
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                mCallBack.onImageLoader((Bitmap) msg.obj, path);
            }
        };
        if (bitmap == null) {
            this.mImageThreadPool.execute(new Runnable() { // from class: com.example.stickyheadergridview.NativeImageLoader.3
                @Override // java.lang.Runnable
                public void run() {
                    Bitmap mBitmap = NativeImageLoader.this.decodeThumbBitmapForFile(path, mPoint == null ? 0 : mPoint.x, mPoint != null ? mPoint.y : 0);
                    Message msg = mHander.obtainMessage();
                    msg.obj = mBitmap;
                    mHander.sendMessage(msg);
                    NativeImageLoader.this.addBitmapToMemoryCache(path, mBitmap);
                }
            });
        }
        return bitmap;
    }

    public void addBitmapToMemoryCache(String key, Bitmap bitmap) {
        if (getBitmapFromMemCache(key) == null && bitmap != null) {
            mMemoryCache.put(key, bitmap);
        }
    }

    private Bitmap getBitmapFromMemCache(String key) {
        Bitmap bitmap = mMemoryCache.get(key);
        if (bitmap != null) {
            Log.i(TAG, "get image for MemCache , path = " + key);
        }
        return bitmap;
    }

    public Bitmap decodeThumbBitmapForFile(String path, int viewWidth, int viewHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);
        options.inSampleSize = computeScale(options, viewWidth, viewHeight);
        options.inJustDecodeBounds = false;
        Log.e(TAG, "get Iamge form file,  path = " + path);
        return BitmapFactory.decodeFile(path, options);
    }

    private int computeScale(BitmapFactory.Options options, int viewWidth, int viewHeight) {
        int inSampleSize = 1;
        if (viewWidth == 0 || viewWidth == 0) {
            return 1;
        }
        int bitmapWidth = options.outWidth;
        int bitmapHeight = options.outHeight;
        if (bitmapWidth > viewWidth || bitmapHeight > viewWidth) {
            int widthScale = Math.round(bitmapWidth / viewWidth);
            int heightScale = Math.round(bitmapHeight / viewWidth);
            inSampleSize = widthScale < heightScale ? widthScale : heightScale;
        }
        return inSampleSize;
    }
}
