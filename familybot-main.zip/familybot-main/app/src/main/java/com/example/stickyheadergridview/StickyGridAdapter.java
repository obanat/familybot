package com.example.stickyheadergridview;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import com.Robot.client.main.R;
import com.example.stickyheadergridview.MyImageView;
import com.example.stickyheadergridview.NativeImageLoader;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersSimpleAdapter;
import java.io.File;
import java.util.List;

/* loaded from: classes.dex */
public class StickyGridAdapter extends BaseAdapter implements StickyGridHeadersSimpleAdapter, View.OnClickListener {
    private List<GridItem> list;
    Context mContext;
    private GridView mGridView;
    private LayoutInflater mInflater;
    private Point mPoint = new Point(0, 0);

    /* loaded from: classes.dex */
    public static class HeaderViewHolder {
        public TextView mTextView;
    }

    /* loaded from: classes.dex */
    public static class ViewHolder {
        public MyImageView mImageView;
    }

    public StickyGridAdapter(Context context, List<GridItem> list, GridView mGridView) {
        this.list = list;
        this.mInflater = LayoutInflater.from(context);
        this.mGridView = mGridView;
        this.mContext = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.list.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return this.list.get(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder mViewHolder;
        Log.e("getView", "getView!!");
        if (convertView == null) {
            mViewHolder = new ViewHolder();
            convertView = this.mInflater.inflate(R.layout.grid_item, parent, false);
            mViewHolder.mImageView = (MyImageView) convertView.findViewById(R.id.grid_item);
            convertView.setTag(mViewHolder);
            mViewHolder.mImageView.setOnMeasureListener(new MyImageView.OnMeasureListener() { // from class: com.example.stickyheadergridview.StickyGridAdapter.1
                @Override // com.example.stickyheadergridview.MyImageView.OnMeasureListener
                public void onMeasureSize(int width, int height) {
                    Log.e("getView", "w:" + width + "height:" + height);
                    StickyGridAdapter.this.mPoint.set(width, height);
                }
            });
        } else {
            mViewHolder = (ViewHolder) convertView.getTag();
        }
        String path = this.list.get(position).getPath();
        mViewHolder.mImageView.setTag(path);
        int iMdiakind = this.list.get(position).getMediaKind();
        if (iMdiakind == 0) {
            Bitmap bitmap = NativeImageLoader.getInstance().loadNativeImage(path, this.mPoint, new NativeImageLoader.NativeImageCallBack() { // from class: com.example.stickyheadergridview.StickyGridAdapter.2
                @Override // com.example.stickyheadergridview.NativeImageLoader.NativeImageCallBack
                public void onImageLoader(Bitmap bitmap2, String path2) {
                    ImageView mImageView = (ImageView) StickyGridAdapter.this.mGridView.findViewWithTag(path2);
                    if (bitmap2 != null && mImageView != null) {
                        mImageView.setImageBitmap(bitmap2);
                    }
                }
            });
            if (bitmap != null) {
                mViewHolder.mImageView.setImageBitmap(bitmap);
            } else {
                mViewHolder.mImageView.setImageResource(R.drawable.eman);
            }
        } else {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inDither = false;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bitmap2 = MediaStore.Video.Thumbnails.getThumbnail(this.mContext.getContentResolver(), this.list.get(position).getMeida_ID(), 1, options);
            Log.e("ThumbnailUtils.createVideoThumbnail", "ThumbnailUtils.createVideoThumbnail");
            if (bitmap2 != null) {
                BitmapDrawable bd = new BitmapDrawable(this.mContext.getResources(), bitmap2);
                mViewHolder.mImageView.setBackground(bd);
                mViewHolder.mImageView.setImageResource(R.drawable.imgstyle2);
            } else {
                mViewHolder.mImageView.setImageResource(R.drawable.eman);
            }
        }
        mViewHolder.mImageView.setOnClickListener(this);
        return convertView;
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersSimpleAdapter
    public View getHeaderView(int position, View convertView, ViewGroup parent) {
        HeaderViewHolder mHeaderHolder;
        if (convertView == null) {
            mHeaderHolder = new HeaderViewHolder();
            convertView = this.mInflater.inflate(R.layout.header, parent, false);
            mHeaderHolder.mTextView = (TextView) convertView.findViewById(R.id.header);
            convertView.setTag(mHeaderHolder);
        } else {
            mHeaderHolder = (HeaderViewHolder) convertView.getTag();
        }
        mHeaderHolder.mTextView.setText(this.list.get(position).getTime());
        return convertView;
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersSimpleAdapter
    public long getHeaderId(int position) {
        return this.list.get(position).getSection();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        String path = (String) arg0.getTag();
        Intent intent = new Intent("android.intent.action.VIEW");
        File file = new File(path);
        if (path.endsWith(".mp4")) {
            intent.setDataAndType(Uri.fromFile(file), "video/*");
        } else {
            intent.setDataAndType(Uri.fromFile(file), "image/*");
        }
        this.mContext.startActivity(intent);
        Log.e("SSSSSS", path);
    }
}
