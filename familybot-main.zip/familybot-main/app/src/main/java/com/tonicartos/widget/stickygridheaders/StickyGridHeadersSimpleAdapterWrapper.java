package com.tonicartos.widget.stickygridheaders;

import android.database.DataSetObserver;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class StickyGridHeadersSimpleAdapterWrapper extends BaseAdapter implements StickyGridHeadersBaseAdapter {
    private StickyGridHeadersSimpleAdapter mDelegate;
    private HeaderData[] mHeaders;

    public StickyGridHeadersSimpleAdapterWrapper(StickyGridHeadersSimpleAdapter adapter) {
        this.mDelegate = adapter;
        adapter.registerDataSetObserver(new DataSetObserverExtension());
        this.mHeaders = generateHeaderList(adapter);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.mDelegate.getCount();
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersBaseAdapter
    public int getCountForHeader(int position) {
        return this.mHeaders[position].getCount();
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersBaseAdapter
    public View getHeaderView(int position, View convertView, ViewGroup parent) {
        return this.mDelegate.getHeaderView(this.mHeaders[position].getRefPosition(), convertView, parent);
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return this.mDelegate.getItem(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return this.mDelegate.getItemId(position);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int position) {
        return this.mDelegate.getItemViewType(position);
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersBaseAdapter
    public int getNumHeaders() {
        return this.mHeaders.length;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        return this.mDelegate.getView(position, convertView, parent);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return this.mDelegate.getViewTypeCount();
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return this.mDelegate.hasStableIds();
    }

    protected HeaderData[] generateHeaderList(StickyGridHeadersSimpleAdapter adapter) {
        Map<Long, HeaderData> mapping = new HashMap<>();
        List<HeaderData> headers = new ArrayList<>();
        for (int i = 0; i < adapter.getCount(); i++) {
            long headerId = adapter.getHeaderId(i);
            HeaderData headerData = mapping.get(Long.valueOf(headerId));
            if (headerData == null) {
                headerData = new HeaderData(i);
                headers.add(headerData);
            }
            headerData.incrementCount();
            mapping.put(Long.valueOf(headerId), headerData);
        }
        return (HeaderData[]) headers.toArray(new HeaderData[headers.size()]);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public final class DataSetObserverExtension extends DataSetObserver {
        private DataSetObserverExtension() {
            //StickyGridHeadersSimpleAdapterWrapper.this = r1;
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            StickyGridHeadersSimpleAdapterWrapper.this.mHeaders = StickyGridHeadersSimpleAdapterWrapper.this.generateHeaderList(StickyGridHeadersSimpleAdapterWrapper.this.mDelegate);
            StickyGridHeadersSimpleAdapterWrapper.this.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            StickyGridHeadersSimpleAdapterWrapper.this.mHeaders = StickyGridHeadersSimpleAdapterWrapper.this.generateHeaderList(StickyGridHeadersSimpleAdapterWrapper.this.mDelegate);
            StickyGridHeadersSimpleAdapterWrapper.this.notifyDataSetInvalidated();
        }
    }

    /* loaded from: classes.dex */
    public class HeaderData {
        private int mCount = 0;
        private int mRefPosition;

        public HeaderData(int refPosition) {
            //StickyGridHeadersSimpleAdapterWrapper.this = r2;
            this.mRefPosition = refPosition;
        }

        public int getCount() {
            return this.mCount;
        }

        public int getRefPosition() {
            return this.mRefPosition;
        }

        public void incrementCount() {
            this.mCount++;
        }
    }
}
