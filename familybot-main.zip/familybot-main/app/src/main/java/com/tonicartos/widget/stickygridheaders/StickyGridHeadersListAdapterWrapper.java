package com.tonicartos.widget.stickygridheaders;

import android.database.DataSetObserver;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;

/* loaded from: classes.dex */
public class StickyGridHeadersListAdapterWrapper extends BaseAdapter implements StickyGridHeadersBaseAdapter {
    private DataSetObserver mDataSetObserver = new DataSetObserver() { // from class: com.tonicartos.widget.stickygridheaders.StickyGridHeadersListAdapterWrapper.1
        @Override // android.database.DataSetObserver
        public void onChanged() {
            StickyGridHeadersListAdapterWrapper.this.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            StickyGridHeadersListAdapterWrapper.this.notifyDataSetInvalidated();
        }
    };
    private ListAdapter mDelegate;

    public StickyGridHeadersListAdapterWrapper(ListAdapter adapter) {
        this.mDelegate = adapter;
        if (adapter != null) {
            adapter.registerDataSetObserver(this.mDataSetObserver);
        }
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.mDelegate == null) {
            return 0;
        }
        return this.mDelegate.getCount();
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersBaseAdapter
    public int getCountForHeader(int header) {
        return 0;
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersBaseAdapter
    public View getHeaderView(int position, View convertView, ViewGroup parent) {
        return null;
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        if (this.mDelegate == null) {
            return null;
        }
        return this.mDelegate.getItem(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return this.mDelegate.getItemId(position);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int position) {
        return this.mDelegate.getItemViewType(position);
    }

    @Override // com.tonicartos.widget.stickygridheaders.StickyGridHeadersBaseAdapter
    public int getNumHeaders() {
        return 0;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        return this.mDelegate.getView(position, convertView, parent);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return this.mDelegate.getViewTypeCount();
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return this.mDelegate.hasStableIds();
    }
}
