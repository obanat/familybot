package com.seuic.jni;

/* loaded from: classes.dex */
public class AppCameraShooting {
    public static native void mp4close();

    public static native boolean mp4init(String str, int i, byte[] bArr);

    public static native void mp4packAudio(byte[] bArr, int i);

    public static native void mp4packVideo(byte[] bArr, int i, int i2);

    static {
        System.loadLibrary("CameraShooting");
    }
}
