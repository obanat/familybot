package com.seuic.singlerocker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.RanaEman.client.main.ui.EmanVideoActivity;
import com.Robot.client.main.R;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes.dex */
public class AppSingleRocker extends SurfaceView implements SurfaceHolder.Callback {
    public static final int ACTION_ATTACK_CAMERAMOVE = 4;
    public static final int ACTION_ATTACK_DEVICEMOVE = 2;
    public static final int ACTION_RUDDER = 1;
    public static final int ACTION_STOP = 3;
    public static final int MOVE_BACK = 1;
    public static final int MOVE_BACK2 = 5;
    public static final int MOVE_BACKLEFT = 10;
    public static final int MOVE_BACKRIGHT = 11;
    public static final int MOVE_LEFT = 3;
    public static final int MOVE_LEFT2 = 7;
    public static final int MOVE_RIGHT = 2;
    public static final int MOVE_RIGHT2 = 6;
    public static final int MOVE_STOP = 13;
    public static final int MOVE_UP = 0;
    public static final int MOVE_UP2 = 4;
    public static final int MOVE_UPLEFT = 8;
    public static final int MOVE_UPRIGHT = 9;
    long LastTouchTime;
    Bitmap bitmap;
    Bitmap bitmap2;
    int iRockerSizeX;
    int iRockerSizeY;
    int isHide;
    int len;
    private SingleRudderListener listener;
    private Point mCtrlPoint;
    private SurfaceHolder mHolder;
    private Paint mPaint;
    public Point mRockerPosition;
    private int mWheelRadius;
    int radianToSend;
    String tag;
    Timer timerSendCommd;

    /* loaded from: classes.dex */
    public interface SingleRudderListener {
        void onSteeringWheelChanged(int i, int i2);
    }

    public AppSingleRocker(Context context) {
        super(context);
        this.mCtrlPoint = new Point(240, 240);
        this.mWheelRadius = 180;
        this.isHide = 0;
        this.listener = null;
        this.tag = "Rocker";
        if (!isInEditMode()) {
            setKeepScreenOn(true);
            this.mHolder = getHolder();
            this.mHolder.addCallback(this);
            this.mPaint = new Paint();
            this.mPaint.setColor(-16711936);
            this.mPaint.setAntiAlias(true);
            this.mRockerPosition = new Point(this.mCtrlPoint);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setZOrderOnTop(true);
            this.mHolder.setFormat(-2);
        }
    }

    public AppSingleRocker(Context context, AttributeSet attribute) {
        super(context, attribute);
        this.mCtrlPoint = new Point(240, 240);
        this.mWheelRadius = 180;
        this.isHide = 0;
        this.listener = null;
        this.tag = "Rocker";
        if (!isInEditMode()) {
            setKeepScreenOn(true);
            this.mHolder = getHolder();
            this.mHolder.addCallback(this);
            this.mPaint = new Paint();
            this.mPaint.setColor(-16711936);
            this.mPaint.setAntiAlias(true);
            this.mRockerPosition = new Point(this.mCtrlPoint);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setZOrderOnTop(true);
            this.mHolder.setFormat(-2);
        }
    }

    public void setSingleRudderListener(SingleRudderListener rockerListener) {
        this.listener = rockerListener;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        try {
            if (this.isHide == 0) {
                switch (event.getAction()) {
                    case 0:
                        this.LastTouchTime = System.currentTimeMillis();
                        this.len = MathUtils.getLength(this.mCtrlPoint.x, this.mCtrlPoint.y, event.getX(), event.getY());
                        if (this.len <= this.iRockerSizeX / 2) {
                            if (this.len <= this.mWheelRadius) {
                                this.mRockerPosition.set((int) event.getX(), (int) event.getY());
                            } else {
                                this.mRockerPosition = MathUtils.getBorderPoint(this.mCtrlPoint, new Point((int) event.getX(), (int) event.getY()), this.mWheelRadius);
                            }
                            if (this.listener != null) {
                                this.timerSendCommd = new Timer();
                                this.timerSendCommd.schedule(new TimerTask() { // from class: com.seuic.singlerocker.AppSingleRocker.1
                                    @Override // java.util.TimerTask, java.lang.Runnable
                                    public void run() {
                                        if (AppSingleRocker.this.listener != null && AppSingleRocker.this.len >= 60) {
                                            if (AppSingleRocker.this.radianToSend >= 30 && AppSingleRocker.this.radianToSend <= 60) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 9);
                                            } else if (AppSingleRocker.this.radianToSend > 60 && AppSingleRocker.this.radianToSend <= 120) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 4);
                                            } else if (AppSingleRocker.this.radianToSend > 120 && AppSingleRocker.this.radianToSend <= 150) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 8);
                                            } else if (AppSingleRocker.this.radianToSend > 150 && AppSingleRocker.this.radianToSend <= 210) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 7);
                                            } else if (AppSingleRocker.this.radianToSend > 210 && AppSingleRocker.this.radianToSend <= 240) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 10);
                                            } else if (AppSingleRocker.this.radianToSend > 240 && AppSingleRocker.this.radianToSend <= 300) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 5);
                                            } else if (AppSingleRocker.this.radianToSend <= 300 || AppSingleRocker.this.radianToSend > 330) {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 6);
                                            } else {
                                                AppSingleRocker.this.listener.onSteeringWheelChanged(1, 11);
                                            }
                                        }
                                    }
                                }, 400L, 400L);
                                float radian = MathUtils.getRadian(this.mCtrlPoint, new Point((int) event.getX(), (int) event.getY()));
                                this.radianToSend = getAngleCouvert(radian);
                            }
                            Canvas_OK();
                            Thread.sleep(60L);
                            break;
                        }
                        break;
                    case 1:
                        if (this.timerSendCommd != null) {
                            this.timerSendCommd.cancel();
                            this.timerSendCommd = null;
                        }
                        this.mRockerPosition = new Point(this.mCtrlPoint);
                        if (this.listener != null) {
                            if (System.currentTimeMillis() - this.LastTouchTime < 400) {
                                if (this.len >= 60) {
                                    if (this.radianToSend >= 30 && this.radianToSend <= 60) {
                                        this.listener.onSteeringWheelChanged(1, 9);
                                    } else if (this.radianToSend > 60 && this.radianToSend <= 120) {
                                        this.listener.onSteeringWheelChanged(1, 0);
                                    } else if (this.radianToSend > 120 && this.radianToSend <= 150) {
                                        this.listener.onSteeringWheelChanged(1, 8);
                                    } else if (this.radianToSend > 150 && this.radianToSend <= 210) {
                                        this.listener.onSteeringWheelChanged(1, 3);
                                    } else if (this.radianToSend > 210 && this.radianToSend <= 240) {
                                        this.listener.onSteeringWheelChanged(1, 10);
                                    } else if (this.radianToSend > 240 && this.radianToSend <= 300) {
                                        this.listener.onSteeringWheelChanged(1, 1);
                                    } else if (this.radianToSend > 300 && this.radianToSend <= 330) {
                                        this.listener.onSteeringWheelChanged(1, 11);
                                    } else {
                                        this.listener.onSteeringWheelChanged(1, 2);
                                    }
                                }
                            } else {
                                this.listener.onSteeringWheelChanged(1, 13);
                            }
                        }
                        this.len = 0;
                        this.radianToSend = 0;
                        Canvas_OK();
                        Thread.sleep(60L);
                        break;
                    case 2:
                        this.len = MathUtils.getLength(this.mCtrlPoint.x, this.mCtrlPoint.y, event.getX(), event.getY());
                        if (this.len <= this.mWheelRadius) {
                            this.mRockerPosition.set((int) event.getX(), (int) event.getY());
                        } else {
                            this.mRockerPosition = MathUtils.getBorderPoint(this.mCtrlPoint, new Point((int) event.getX(), (int) event.getY()), this.mWheelRadius);
                        }
                        if (this.listener != null) {
                            float radian2 = MathUtils.getRadian(this.mCtrlPoint, new Point((int) event.getX(), (int) event.getY()));
                            this.radianToSend = getAngleCouvert(radian2);
                        }
                        Canvas_OK();
                        Thread.sleep(60L);
                        break;
                    default:
                        Canvas_OK();
                        Thread.sleep(60L);
                        break;
                }
            } else {
                Thread.sleep(200L);
            }
        } catch (Exception e) {
            Log.e("touchevent", "err:" + e.getMessage());
        }
        return true;
    }

    private int getAngleCouvert(float radian) {
        int tmp = (int) Math.round((radian / 3.141592653589793d) * 180.0d);
        return tmp < 0 ? -tmp : (180 - tmp) + 180;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder holder) {
    }

    public void setBitmap_bg(int i) {
        if (i == 1) {
            if (EmanVideoActivity.blnLandBoolean) {
                this.bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.j3);
            } else {
                this.bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.j4);
            }
        } else if (EmanVideoActivity.blnLandBoolean) {
            this.bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.j3_up);
        } else {
            this.bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.j4_up);
        }
        this.bitmap = Bitmap.createScaledBitmap(this.bitmap, this.iRockerSizeX, this.iRockerSizeY, false);
        Canvas_OK();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        this.iRockerSizeX = width;
        this.iRockerSizeY = height;
        if (EmanVideoActivity.blnLandBoolean) {
            this.bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.j3);
        } else {
            this.bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.j4);
        }
        this.bitmap = Bitmap.createScaledBitmap(this.bitmap, width, height, false);
        this.bitmap2 = BitmapFactory.decodeResource(getResources(), R.drawable.j5);
        this.bitmap2 = Bitmap.createScaledBitmap(this.bitmap2, width / 3, height / 3, false);
        this.mCtrlPoint = new Point(this.iRockerSizeX / 2, this.iRockerSizeY / 2);
        this.mRockerPosition = new Point(this.iRockerSizeX / 2, this.iRockerSizeY / 2);
        this.mWheelRadius = (this.iRockerSizeX / 2) - (this.iRockerSizeX / 6);
        if (!isInEditMode()) {
            Canvas_OK();
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder holder) {
    }

    public void Hided(int opt) {
        this.isHide = opt;
        Canvas_OK();
    }

    public void Canvas_OK() {
        if (!isInEditMode()) {
            Canvas canvas = null;
            try {
                try {
                    canvas = this.mHolder.lockCanvas();
                    canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                    canvas.drawBitmap(this.bitmap, 0.0f, 0.0f, this.mPaint);
                    canvas.drawBitmap(this.bitmap2, this.mRockerPosition.x - (this.iRockerSizeX / 6), this.mRockerPosition.y - (this.iRockerSizeX / 6), this.mPaint);
                    if (canvas != null) {
                        this.mHolder.unlockCanvasAndPost(canvas);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    if (canvas != null) {
                        this.mHolder.unlockCanvasAndPost(canvas);
                    }
                }
            } catch (Throwable th) {
                if (canvas != null) {
                    this.mHolder.unlockCanvasAndPost(canvas);
                }
                throw th;
            }
        }
    }
}
