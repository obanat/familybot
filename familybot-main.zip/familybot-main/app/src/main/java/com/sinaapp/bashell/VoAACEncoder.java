package com.sinaapp.bashell;

/* loaded from: classes.dex */
public class VoAACEncoder {
    public native byte[] Enc(byte[] bArr);

    public native int Init(int i, int i2, short s, short s2);

    public native int Uninit();

    static {
        System.loadLibrary("VoAACEncoder");
    }
}
