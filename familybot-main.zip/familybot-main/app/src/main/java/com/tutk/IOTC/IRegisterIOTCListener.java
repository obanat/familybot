package com.tutk.IOTC;

/* loaded from: classes.dex */
public interface IRegisterIOTCListener {
    void receiveChannelInfo(Camera camera, int i, int i2);

    void receiveFrameInfo(Camera camera, int i, long j, int i2, int i3, int i4, int i5);

    void receiveIOCtrlData(Camera camera, int i, int i2, byte[] bArr);

    void receiveRDTSendFileResult(Camera camera, int i, int i2, String str, int i3);

    void receiveSessionInfo(Camera camera, int i);
}
