package com.tutk.IOTC;

/* loaded from: classes.dex */
public class St_LanSearchResp {
    public byte[] UID = new byte[21];
    public byte[] IP = new byte[17];
    public int port = 0;
}
