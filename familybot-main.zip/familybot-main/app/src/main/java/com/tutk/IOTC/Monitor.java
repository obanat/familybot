package com.tutk.IOTC;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;

@SuppressLint({"NewApi"})
/* loaded from: classes.dex */
public class Monitor extends SurfaceView implements SurfaceHolder.Callback, View.OnTouchListener, GestureDetector.OnGestureListener {
    private static final float DEFAULT_MAX_ZOOM_SCALE = 2.0f;
    private static final int DRAG = 1;
    private static final int FLING_MIN_DISTANCE = 100;
    private static final int FLING_MIN_VELOCITY = 0;
    private static final int NONE = 0;
    private static final int PTZ_DELAY = 1500;
    private static final int PTZ_SPEED = 8;
    private static final int ZOOM = 2;
    public boolean blnIsSendbmpOK;
    boolean blnRetrunClick;
    private int mAVChannel;
    private Camera mCamera;
    private float mCurrentMaxScale;
    private float mCurrentScale;
    public boolean mEnableDither;
    private GestureDetector mGestureDetector;
    private Bitmap mLastFrame;
    private long mLastZoomTime;
    private PointF mMidPoint;
    private PointF mMidPointForCanvas;
    private float mOrigDist;
    private Paint mPaint;
    private int mPinchedMode;
    private Rect mRectCanvas;
    private Rect mRectMonitor;
    private PointF mStartPoint;
    private SurfaceHolder mSurHolder;
    private ThreadRender mThreadRender;
    surfaceCreatedChecker myChecker;
    private int vBottom;
    private int vLeft;
    private int vRight;
    private int vTop;

    /* loaded from: classes.dex */
    public interface surfaceCreatedChecker {
        void surfaceISCreatedOK();
    }

    public Monitor(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mPinchedMode = 0;
        this.mStartPoint = new PointF();
        this.mMidPoint = new PointF();
        this.mMidPointForCanvas = new PointF();
        this.mOrigDist = 0.0f;
        this.mCurrentScale = 1.0f;
        this.mCurrentMaxScale = DEFAULT_MAX_ZOOM_SCALE;
        this.mSurHolder = null;
        this.mRectCanvas = new Rect();
        this.mRectMonitor = new Rect();
        this.mAVChannel = -1;
        this.mThreadRender = null;
        this.mPaint = new Paint();
        this.mEnableDither = true;
        this.blnIsSendbmpOK = false;
        this.mSurHolder = getHolder();
        this.mSurHolder.addCallback(this);
        this.mGestureDetector = new GestureDetector(this);
        setOnTouchListener(this);
        setLongClickable(true);
    }

    public void setMaxZoom(float value) {
        this.mCurrentMaxScale = value;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.e("Monitor", "surfaceChanged");
        Log.e("Monitor", "width" + width);
        Log.e("Monitor", "height" + height);
        ViewGroup.LayoutParams lp = getLayoutParams();
        lp.height = (int) (width / 1.77777778d);
        Log.e("Monitor", "lp.height" + lp.height);
        Log.e("Monitor", "lp.width" + lp.width);
        setLayoutParams(lp);
    }

    public void setsurfaceCreatedCheckerListener(surfaceCreatedChecker listener) {
        this.myChecker = listener;
    }

    public void SetCamera(Camera camera) {
        this.mCamera = camera;
    }

    public void RemoveCamera() {
        this.mCamera = null;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder holder) {
        this.myChecker.surfaceISCreatedOK();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder holder) {
    }

    public void attachCamera(Camera camera, int avChannel) {
        this.mCamera = camera;
        this.mAVChannel = avChannel;
        if (this.mThreadRender == null) {
            this.mThreadRender = new ThreadRender();
            this.mThreadRender.start();
        }
    }

    public void deattachCamera() {
        this.mAVChannel = -1;
        if (this.mCamera != null) {
            this.mCamera = null;
        }
        if (this.mThreadRender != null) {
            this.mThreadRender.stopThread();
            try {
                this.mThreadRender.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            this.mThreadRender = null;
        }
    }

    @Override // android.view.View.OnTouchListener
    @SuppressLint({"NewApi"})
    public boolean onTouch(View view, MotionEvent event) {
        this.mGestureDetector.onTouchEvent(event);
        switch (event.getAction() & 255) {
            case 0:
                this.blnRetrunClick = true;
                this.mPinchedMode = 1;
                this.mStartPoint.set(event.getX(), event.getY());
                break;
            case 1:
                if (this.blnRetrunClick) {
                    return false;
                }
                return true;
            case 2:
                if (this.mPinchedMode == 1) {
                    if (System.currentTimeMillis() - this.mLastZoomTime < 33) {
                        return true;
                    }
                    PointF currentPoint = new PointF();
                    currentPoint.set(event.getX(), event.getY());
                    int offsetX = ((int) currentPoint.x) - ((int) this.mStartPoint.x);
                    int offsetY = ((int) currentPoint.y) - ((int) this.mStartPoint.y);
                    if (Math.abs(offsetX) > 10 || Math.abs(offsetY) > 10) {
                        this.blnRetrunClick = false;
                    }
                    this.mStartPoint = currentPoint;
                    Rect rect = new Rect();
                    rect.set(this.mRectCanvas);
                    rect.offset(offsetX, offsetY);
                    int width = rect.right - rect.left;
                    int height = rect.bottom - rect.top;
                    if (this.mRectMonitor.bottom - this.mRectMonitor.top > this.mRectMonitor.right - this.mRectMonitor.left) {
                        if (rect.left > this.mRectMonitor.left) {
                            rect.left = this.mRectMonitor.left;
                            rect.right = rect.left + width;
                        }
                        if (rect.top > this.mRectMonitor.top) {
                            rect.top = this.mRectCanvas.top;
                            rect.bottom = rect.top + height;
                        }
                        if (rect.right < this.mRectMonitor.right) {
                            rect.right = this.mRectMonitor.right;
                            rect.left = rect.right - width;
                        }
                        if (rect.bottom < this.mRectMonitor.bottom) {
                            rect.bottom = this.mRectCanvas.bottom;
                            rect.top = rect.bottom - height;
                        }
                    } else {
                        if (rect.left > this.mRectMonitor.left) {
                            rect.left = this.mRectCanvas.left;
                            rect.right = rect.left + width;
                        }
                        if (rect.top > this.mRectMonitor.top) {
                            rect.top = this.mRectMonitor.top;
                            rect.bottom = rect.top + height;
                        }
                        if (rect.right < this.mRectMonitor.right) {
                            rect.right = this.mRectCanvas.right;
                            rect.left = rect.right - width;
                        }
                        if (rect.bottom < this.mRectMonitor.bottom) {
                            rect.bottom = this.mRectMonitor.bottom;
                            rect.top = rect.bottom - height;
                        }
                    }
                    this.mRectCanvas.set(rect);
                    break;
                } else if (this.mPinchedMode == 2) {
                    if (System.currentTimeMillis() - this.mLastZoomTime < 33) {
                        return true;
                    }
                    if (event.getPointerCount() == 1) {
                        return false;
                    }
                    float newDist = spacing(event);
                    float scale = newDist / this.mOrigDist;
                    this.mCurrentScale *= scale;
                    this.mOrigDist = newDist;
                    if (this.mCurrentScale > this.mCurrentMaxScale) {
                        this.mCurrentScale = this.mCurrentMaxScale;
                        return false;
                    }
                    if (this.mCurrentScale < 1.0f) {
                        this.mCurrentScale = 1.0f;
                    }
                    System.out.println("newDist(" + newDist + ") / origDist(" + this.mOrigDist + ") = zoom scale(" + this.mCurrentScale + ")");
                    int maxWidth = (this.vRight - this.vLeft) * 3;
                    int maxHeight = (this.vBottom - this.vTop) * 3;
                    int scaledWidth = (int) ((this.vRight - this.vLeft) * this.mCurrentScale);
                    int scaledHeight = (int) ((this.vBottom - this.vTop) * this.mCurrentScale);
                    int origWidth = this.vRight - this.vLeft;
                    int origHeight = this.vBottom - this.vTop;
                    int l = (int) ((this.mRectMonitor.width() / 2) - (((this.mRectMonitor.width() / 2) - this.mRectCanvas.left) * scale));
                    int t = (int) ((this.mRectMonitor.height() / 2) - (((this.mRectMonitor.height() / 2) - this.mRectCanvas.top) * scale));
                    int r = l + scaledWidth;
                    int b = t + scaledHeight;
                    if (scaledWidth <= origWidth || scaledHeight <= origHeight) {
                        l = this.vLeft;
                        t = this.vTop;
                        r = this.vRight;
                        b = this.vBottom;
                    } else if (scaledWidth >= maxWidth || scaledHeight >= maxHeight) {
                        l = this.mRectCanvas.left;
                        t = this.mRectCanvas.top;
                        r = l + maxWidth;
                        b = t + maxHeight;
                    }
                    this.mRectCanvas.set(l, t, r, b);
                    System.out.println("zoom -> l: " + l + ", t: " + t + ", r: " + r + ", b: " + b + ",  width: " + scaledWidth + ", height: " + scaledHeight);
                    this.mLastZoomTime = System.currentTimeMillis();
                    break;
                }
                break;
            case 5:
                float dist = spacing(event);
                if (dist > 10.0f) {
                    this.mPinchedMode = 2;
                    this.mOrigDist = dist;
                    System.out.println("Action_Pointer_Down -> origDist(" + this.mOrigDist + ")");
                    break;
                }
                break;
            case 6:
                if (this.mCurrentScale == 1.0f) {
                    this.mPinchedMode = 0;
                    break;
                }
                break;
        }
        return false;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        if (this.mRectCanvas.left == this.vLeft && this.mRectCanvas.top == this.vTop && this.mRectCanvas.right == this.vRight && this.mRectCanvas.bottom == this.vBottom) {
            System.out.println("velocityX: " + Math.abs(velocityX) + ", velocityY: " + Math.abs(velocityY));
            if (e1.getX() - e2.getX() > 100.0f && Math.abs(velocityX) > 0.0f) {
                if (this.mCamera != null) {
                    this.mCamera.sendIOCtrl(0, 12288, Packet.intToByteArray_Little(2));
                }
            } else if (e2.getX() - e1.getX() > 100.0f && Math.abs(velocityX) > 0.0f) {
                if (this.mCamera != null) {
                    this.mCamera.sendIOCtrl(0, 12288, Packet.intToByteArray_Little(3));
                }
            } else if (e1.getY() - e2.getY() > 100.0f && Math.abs(velocityY) > 0.0f) {
                if (this.mCamera != null) {
                    Log.e("Monitor", "up");
                    this.mCamera.sendIOCtrl(0, 12354, Packet.intToByteArray_Little(0));
                }
            } else if (e2.getY() - e1.getY() > 100.0f && Math.abs(velocityY) > 0.0f && this.mCamera != null) {
                Log.e("Monitor", "down");
                this.mCamera.sendIOCtrl(0, 12353, Packet.intToByteArray_Little(0));
            }
            return true;
        }
        return false;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public void onLongPress(MotionEvent e) {
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return true;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public void onShowPress(MotionEvent e) {
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @SuppressLint({"FloatMath"})
    private float spacing(MotionEvent event) {
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt((x * x) + (y * y));
    }

    private void parseMidPoint(PointF point, float left, float top, float right, float bottom) {
        point.set((left + right) / DEFAULT_MAX_ZOOM_SCALE, (top + bottom) / DEFAULT_MAX_ZOOM_SCALE);
    }

    /* loaded from: classes.dex */
    private class ThreadRender extends Thread {
        private boolean mIsRunningThread;
        private Object mWaitObjectForStopThread;

        private ThreadRender() {
            //Monitor.this = r2;
            this.mIsRunningThread = false;
            this.mWaitObjectForStopThread = new Object();
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            this.mIsRunningThread = true;
            Canvas localCanvas = null;
            if (!Monitor.this.mPaint.isDither() && Monitor.this.mEnableDither) {
                Log.e("IOTCamera", "==== Enable Dithering ==== !!!This will decrease FPS.");
                Monitor.this.mPaint.setDither(Monitor.this.mEnableDither);
            }
            Log.e("Monitor", "RUNING.....");
            while (this.mIsRunningThread) {
                boolean blnbmpis_NotRecycle = false;
                boolean blnmLastFrame_Notnull = false;
                if (!this.mIsRunningThread) {
                    Log.e("IOTCamera", "===ThreadRender exit===");
                    return;
                }
                if (Monitor.this.mLastFrame != null) {
                    blnmLastFrame_Notnull = true;
                    if (!Monitor.this.mLastFrame.isRecycled()) {
                        blnbmpis_NotRecycle = true;
                    }
                }
                if (blnmLastFrame_Notnull && blnbmpis_NotRecycle) {
                    try {
                        try {
                            localCanvas = Monitor.this.mSurHolder.lockCanvas();
                            if (localCanvas != null) {
                                localCanvas.drawColor(0xff000000);
                                localCanvas.drawBitmap(Monitor.this.mLastFrame, (Rect) null, Monitor.this.mRectCanvas, Monitor.this.mPaint);
                            }
                            if (localCanvas != null) {
                                Monitor.this.mSurHolder.unlockCanvasAndPost(localCanvas);
                            }
                            localCanvas = null;
                            if (localCanvas != null) {
                                try {
                                    synchronized (this.mWaitObjectForStopThread) {
                                        this.mWaitObjectForStopThread.wait(33L);
                                    }
                                } catch (InterruptedException localInterruptedException) {
                                    localInterruptedException.printStackTrace();
                                }
                            }
                        } finally {
                            if (localCanvas != null) {
                                Monitor.this.mSurHolder.unlockCanvasAndPost(localCanvas);
                            }
                        }
                    } catch (Exception localException) {
                        Log.e("videoCanvas Error", localException.getMessage());
                        if (localCanvas != null) {
                            Monitor.this.mSurHolder.unlockCanvasAndPost(localCanvas);
                            localCanvas = null;
                            if (0 != 0) {
                                Monitor.this.mSurHolder.unlockCanvasAndPost(null);
                            }
                        } else if (localCanvas != null) {
                            Monitor.this.mSurHolder.unlockCanvasAndPost(localCanvas);
                        }
                    }
                } else {
                    try {
                        synchronized (this.mWaitObjectForStopThread) {
                            this.mWaitObjectForStopThread.wait(10L);
                        }
                    } catch (InterruptedException localInterruptedException2) {
                        localInterruptedException2.printStackTrace();
                    }
                }
            }
        }

        public void stopThread() {
            this.mIsRunningThread = false;
            try {
                this.mWaitObjectForStopThread.notify();
            } catch (Exception e) {
            }
        }
    }
}
