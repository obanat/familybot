package com.tutk.IOTC;

/* loaded from: classes.dex */
public class MyCamera extends Camera {
    private String mName;
    private String mPwd;
    private String mUID;
    private Boolean blnIsRecharge = false;
    private int iBat = 0;
    private int iMode = 0;
    private Boolean blnIsNewDevice = false;
    private Boolean blnUserNeedAP = false;

    public MyCamera(String name, String uid, String pwd) {
        this.mName = name;
        this.mUID = uid;
        this.mPwd = pwd;
    }

    public void setIsNewDevice(Boolean blncharge) {
        this.blnIsNewDevice = blncharge;
    }

    public Boolean isNewDevice() {
        return this.blnIsNewDevice;
    }

    public void setUserNeedAP(Boolean blncharge) {
        this.blnUserNeedAP = blncharge;
    }

    public Boolean isUserNeedAP() {
        return this.blnUserNeedAP;
    }

    public void setBat(int ibat) {
        this.iBat = ibat;
    }

    public int getMode() {
        return this.iMode;
    }

    public void setMode(int ibat) {
        this.iMode = ibat;
    }

    public int getBat() {
        return this.iBat;
    }

    public void setRecharge(Boolean blncharge) {
        this.blnIsRecharge = blncharge;
    }

    public Boolean isRecharge() {
        return this.blnIsRecharge;
    }

    @Override // com.tutk.IOTC.Camera
    public void connect(String uid, String pwd) {
        super.connect(uid, pwd);
        this.mUID = uid;
    }

    @Override // com.tutk.IOTC.Camera
    public void connect(String uid) {
        super.connect(uid);
        this.mUID = uid;
    }

    public String getName() {
        return this.mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getUID() {
        return this.mUID;
    }

    public String getPassword() {
        return this.mPwd;
    }

    public void SetPassword(String pwd) {
        this.mPwd = pwd;
    }
}
