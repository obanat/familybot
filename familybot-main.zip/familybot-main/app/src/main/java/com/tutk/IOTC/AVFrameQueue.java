package com.tutk.IOTC;

import java.util.LinkedList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class AVFrameQueue {
    private volatile LinkedList<AVFrame> listData = new LinkedList<>();
    private volatile int mSize = 0;

    public synchronized int getCount() {
        return this.mSize;
    }

    public synchronized void addLast(AVFrame node) {
        if (this.mSize > 300) {
            boolean bFirst = true;
            while (true) {
                AVFrame frame = this.listData.get(0);
                if (bFirst) {
                    if (frame.isIFrame()) {
                        System.out.println("drop I frame");
                    } else {
                        System.out.println("drop p frame");
                    }
                    this.listData.removeFirst();
                    this.mSize--;
                } else if (frame.isIFrame()) {
                    break;
                } else {
                    System.out.println("drop p frame");
                    this.listData.removeFirst();
                    this.mSize--;
                }
                bFirst = false;
            }
        }
        this.listData.addLast(node);
        this.mSize++;
    }

    public synchronized AVFrame removeHead() {
        AVFrame removeFirst;
        if (this.mSize == 0) {
            removeFirst = null;
        } else {
            removeFirst = this.listData.removeFirst();
            this.mSize--;
        }
        return removeFirst;
    }

    public synchronized void removeAll() {
        if (!this.listData.isEmpty()) {
            this.listData.clear();
        }
        this.mSize = 0;
    }
}
