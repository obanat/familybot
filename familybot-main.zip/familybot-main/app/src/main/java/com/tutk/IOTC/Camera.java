package com.tutk.IOTC;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Environment;
import android.os.Process;
import android.util.Log;
import android.view.Surface;
import com.decoder.util.DecADPCM;
import com.decoder.util.DecG726;
import com.decoder.util.DecMp3;
import com.decoder.util.DecSpeex;
import com.decoder.util.G711;
import com.example.soundtouchdemo.JNISoundTouch;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import com.seuic.jni.AppCameraShooting;
import com.sinaapp.bashell.VoAACEncoder;
import com.tutk.IOTC.AVIOCTRLDEFs;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

/* loaded from: classes.dex */
public class Camera {
    public static final int CONNECTION_STATE_CONNECTED = 2;
    public static final int CONNECTION_STATE_CONNECTING = 1;
    public static final int CONNECTION_STATE_CONNECT_FAILED = 8;
    public static final int CONNECTION_STATE_DISCONNECTED = 3;
    public static final int CONNECTION_STATE_NONE = 0;
    public static final int CONNECTION_STATE_TIMEOUT = 6;
    public static final int CONNECTION_STATE_UNKNOWN_DEVICE = 4;
    public static final int CONNECTION_STATE_UNSUPPORTED = 7;
    public static final int CONNECTION_STATE_WRONG_PASSWORD = 5;
    public static final int DEFAULT_AV_CHANNEL = 0;
    private static final String HEXES = "0123456789ABCDEF";
    public static final int MAXSIZE_RECVBUF = 1024;
    public static final int MP4_FILE_OK = 8;
    public static final int RDTR_FILE_END = 6;
    public static final int RDTR_FILE_ERR = 7;
    public static final int RDTR_FILE_PROGRESS = 5;
    public static final int RDTR_FILE_START = 4;
    public static final int RDTS_FILE_END = 2;
    public static final int RDTS_FILE_ERR = 3;
    public static final int RDTS_FILE_PROGRESS = 1;
    public static final int RDTS_FILE_START = 0;
    public static final int RDT_WAIT_TIMEMS = 3000;
    private static volatile int mCameraCount = 0;
    private static int mDefaultMaxCameraLimit = 1;
    public static int nFlow_total_FPS_count = 0;
    public static int nFlow_total_FPS_count_noClear = 0;
    private static final String tag = "CAMERA_HU";
    private static final String tag2 = "CAMERA.threadStartg726";
    private String mDevPwd;
    public String mDevUID;
    MediaCodec mediaCodec;
    MicAmpListener miclistener;
    private volatile int nDispFrmPreSec;
    private volatile int nRecvFrmPreSec;
    Surface surface;
    private final Object mWaitObjectForConnected = new Object();
    private ThreadConnectDev mThreadConnectDev = null;
    private ThreadCheckDevStatus mThreadChkDevStatus = null;
    private ThreadRecordingAudioG711 mThreadRecordingG711file = null;
    private ThreadPlayG726AudioQueue mPThreadplayG711_Queue = null;
    private ThreadSendAudioG726_file mPThreadRRDT_SendFile = null;
    private volatile int mSID = -1;
    private volatile int mSessionMode = -1;
    private volatile int nGet_SID = -1;
    public boolean mEnableDither = true;
    private boolean mInitAudio = false;
    private AudioTrack mAudioTrack = null;
    private int mCamIndex = 4;
    private volatile int[] bResend = new int[1];
    private List<IRegisterIOTCListener> mIOTCListeners = Collections.synchronizedList(new Vector());
    private List<AVChannel> mAVChannels = Collections.synchronizedList(new Vector());
    int avIndexForSendAudioG726 = -1;
    VoAACEncoder voAAC = null;
    private JNISoundTouch soundtouch = new JNISoundTouch();
    private volatile Boolean blnNeedSaveAudio = false;
    private volatile Boolean blnNeedRecording = false;
    private Boolean blnIsVideoOK = false;
    public int iStatus = 0;
    public int iAP = 0;

    /* loaded from: classes.dex */
    public interface MicAmpListener {
        void onRecvMicAmp(int i);
    }

    public Camera() {
        Log.e(tag, "Camera() 构造");
        this.mDevUID = BuildConfig.FLAVOR;
        this.mDevPwd = BuildConfig.FLAVOR;
    }

    public void SetRecording(boolean index) {
        this.blnNeedRecording = Boolean.valueOf(index);
    }

    public boolean GetRecording() {
        return this.blnNeedRecording.booleanValue();
    }

    public void SetCamIndex(int index) {
        this.mCamIndex = index;
    }

    public int getSessionMode() {
        return this.mSessionMode;
    }

    public long getChannelServiceType(int avChannel) {
        long ret = 0;
        synchronized (this.mAVChannels) {
            Iterator<AVChannel> it = this.mAVChannels.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                AVChannel ch = it.next();
                if (ch.getChannel() == avChannel) {
                    ret = ch.getServiceType();
                    break;
                }
            }
        }
        return ret;
    }

    public boolean registerIOTCListener(IRegisterIOTCListener listener) {
        if (this.mIOTCListeners.contains(listener)) {
            return false;
        }
        Log.e(tag, "register IOTC listener" + listener.getClass().getName());
        this.mIOTCListeners.add(listener);
        return true;
    }

    public boolean unregisterIOTCListener(IRegisterIOTCListener listener) {
        boolean result = false;
        if (listener == null) {
            Log.e(tag, "unregisterIOTCListener NULL");
            return true;
        }
        if (this.mIOTCListeners.size() > 0 && this.mIOTCListeners.contains(listener)) {
            this.mIOTCListeners.remove(listener);
            result = true;
        }
        return result;
    }

    public static synchronized st_LanSearchInfo[] SearchLAN() {
        st_LanSearchInfo[] ab_LanSearchInfo;
        synchronized (Camera.class) {
            int[] nArray = new int[1];
            ab_LanSearchInfo = IOTCAPIs.IOTC_Lan_Search(nArray, 2000);
            Log.e(tag, "st_LanSearchInfo  === " + nArray[0]);
            for (int i = 0; i < nArray[0]; i++) {
            }
        }
        return ab_LanSearchInfo;
    }

    public static void setMaxCameraLimit(int limit) {
        mDefaultMaxCameraLimit = limit;
    }

    public static synchronized int init() {
        int nRet;
        synchronized (Camera.class) {
            nRet = 0;
            if (mCameraCount == 0) {
                int port = (int) ((System.currentTimeMillis() % 10000) + 10000);
                nRet = IOTCAPIs.IOTC_Initialize2(port);
                Log.e(tag, "IOTC_Initialize2() port:" + port + " returns " + nRet);
                if (nRet >= 0) {
                    nRet = AVAPIs.avInitialize(mDefaultMaxCameraLimit);
                    Log.e(tag, "avInitialize() = " + nRet);
                    if (nRet >= 0) {
                        int rdtCh = RDTAPIs.RDT_Initialize();
                        if (rdtCh <= 0) {
                            nRet = 0;
                        }
                    }
                }
            }
            mCameraCount++;
            Log.e(tag, "avInitialize()mCameraCount: = " + mCameraCount);
        }
        return nRet;
    }

    public static synchronized int uninit() {
        int nRet;
        synchronized (Camera.class) {
            nRet = 0;
            Log.e(tag, "avDeInitialize() mCameraCount: " + mCameraCount);
            if (mCameraCount > 0) {
                mCameraCount--;
                if (mCameraCount == 0) {
                    Log.e(tag, "avDeInitialize() mCameraCount == 0 ");
                    Log.e(tag, "avDeInitialize() returns " + AVAPIs.avDeInitialize());
                    Log.e(tag, "RDT_DeInitialize() returns " + RDTAPIs.RDT_DeInitialize());
                    nRet = IOTCAPIs.IOTC_DeInitialize();
                    Log.e(tag, "IOTC_DeInitialize() returns " + nRet);
                }
            }
        }
        return nRet;
    }

    public boolean isSessionConnected() {
        return this.mSID >= 0;
    }

    public boolean isChannelConnected(int avChannel) {
        boolean result = false;
        synchronized (this.mAVChannels) {
            Iterator<AVChannel> it = this.mAVChannels.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                AVChannel ch = it.next();
                if (avChannel == ch.getChannel()) {
                    result = this.mSID >= 0 && ch.getAVIndex() >= 0;
                }
            }
        }
        return result;
    }

    public void sendIOCtrl(int avChannel, int type, byte[] data) {
        synchronized (this.mAVChannels) {
            for (AVChannel ch : this.mAVChannels) {
                if (avChannel == ch.getChannel()) {
                    ch.IOCtrlQueue.Enqueue(type, data);
                }
            }
        }
    }

    public void connect(String uid) {
        this.mDevUID = uid;
        if (this.mThreadConnectDev == null) {
            this.mThreadConnectDev = new ThreadConnectDev(0);
            this.mThreadConnectDev.start();
        }
        if (this.mThreadChkDevStatus == null) {
            this.mThreadChkDevStatus = new ThreadCheckDevStatus();
            this.mThreadChkDevStatus.start();
        }
    }

    public void connect(String uid, String pwd) {
        this.mDevUID = uid;
        this.mDevPwd = pwd;
        if (this.mThreadConnectDev == null) {
            this.mThreadConnectDev = new ThreadConnectDev(1);
            this.mThreadConnectDev.start();
        }
        if (this.mThreadChkDevStatus == null) {
            this.mThreadChkDevStatus = new ThreadCheckDevStatus();
            this.mThreadChkDevStatus.start();
        }
    }

    public void disconnect() {
        synchronized (this.mAVChannels) {
            for (AVChannel ch : this.mAVChannels) {
                if (ch.threadStartDev != null) {
                    ch.threadStartDev.stopThread();
                }
                if (this.mPThreadplayG711_Queue != null) {
                    this.blnNeedSaveAudio = false;
                    this.mPThreadplayG711_Queue.stopThread();
                }
                if (ch.threadDecVideoHD != null) {
                    ch.threadDecVideoHD.stopThread();
                }
                if (ch.threadRecvVideo != null) {
                    ch.threadRecvVideo.stopThread();
                }
                if (ch.threadRecvIOCtrl != null) {
                    ch.threadRecvIOCtrl.stopThread();
                }
                if (ch.threadSendIOCtrl != null) {
                    ch.threadSendIOCtrl.stopThread();
                }
                if (ch.threadRecvVideo != null) {
                    try {
                        ch.threadRecvVideo.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    ch.threadRecvVideo = null;
                }
                if (ch.threadDecVideoHD != null) {
                    try {
                        ch.threadDecVideoHD.join();
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                    ch.threadDecVideoHD = null;
                }
                if (ch.threadRecvIOCtrl != null) {
                    try {
                        ch.threadRecvIOCtrl.join();
                    } catch (InterruptedException e3) {
                        e3.printStackTrace();
                    }
                    ch.threadRecvIOCtrl = null;
                }
                if (ch.threadSendIOCtrl != null) {
                    try {
                        ch.threadSendIOCtrl.join();
                    } catch (InterruptedException e4) {
                        e4.printStackTrace();
                    }
                    ch.threadSendIOCtrl = null;
                }
                if (ch.threadStartDev != null && ch.threadStartDev.isAlive()) {
                    try {
                        ch.threadStartDev.join();
                    } catch (InterruptedException e5) {
                        e5.printStackTrace();
                    }
                }
                ch.threadStartDev = null;
                ch.AudioFrameQueue.removeAll();
                ch.AudioFrameQueue = null;
                ch.VideoFrameQueue.removeAll();
                ch.VideoFrameQueue = null;
                ch.IOCtrlQueue.removeAll();
                ch.IOCtrlQueue = null;
                if (ch.getAVIndex() >= 0) {
                    AVAPIs.avClientStop(ch.getAVIndex());
                    Log.e(tag, "!!!avClientStop(avIndex = " + ch.getAVIndex() + ")");
                }
            }
        }
        this.mAVChannels.clear();
        synchronized (this.mWaitObjectForConnected) {
            this.mWaitObjectForConnected.notify();
        }
        if (this.mThreadChkDevStatus != null) {
            this.mThreadChkDevStatus.stopThread();
        }
        if (this.mThreadConnectDev != null) {
            this.mThreadConnectDev.stopThread();
        }
        if (this.mThreadChkDevStatus != null) {
            try {
                this.mThreadChkDevStatus.join();
            } catch (InterruptedException e6) {
                e6.printStackTrace();
            }
            this.mThreadChkDevStatus = null;
        }
        if (this.mThreadConnectDev != null && this.mThreadConnectDev.isAlive()) {
            try {
                this.mThreadConnectDev.join();
            } catch (InterruptedException e7) {
                e7.printStackTrace();
            }
        }
        this.mThreadConnectDev = null;
        if (this.mSID >= 0) {
            IOTCAPIs.IOTC_Session_Close(this.mSID);
            Log.e(tag, "IOTC_Session_Close(nSID = " + this.mSID + ")");
            this.mSID = -1;
        }
        this.mSessionMode = -1;
    }

    public void start(int avChannel, String viewAccount, String viewPasswd) {
        AVChannel session = null;
        synchronized (this.mAVChannels) {
            Iterator<AVChannel> it = this.mAVChannels.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                AVChannel ch = it.next();
                if (ch.getChannel() == avChannel) {
                    session = ch;
                    Log.e(tag, "找到通道！");
                    break;
                }
            }
        }
        if (session == null) {
            Log.e(tag, "session == null");
            AVChannel ch2 = new AVChannel(avChannel, viewAccount, viewPasswd);
            this.mAVChannels.add(ch2);
            ch2.threadStartDev = new ThreadStartDev(ch2);
            ch2.threadStartDev.start();
            ch2.threadRecvIOCtrl = new ThreadRecvIOCtrl(ch2);
            ch2.threadRecvIOCtrl.start();
            ch2.threadSendIOCtrl = new ThreadSendIOCtrl(ch2);
            ch2.threadSendIOCtrl.start();
            return;
        }
        Log.e(tag, "session ！！！= null");
        Log.e(tag, "servType:" + session.getServiceType());
        if (session.threadStartDev.isAlive()) {
            Log.e(tag, "session.threadStartDev true!");
        } else {
            Log.e(tag, "挂了！");
            session.threadStartDev = null;
        }
        if (session.threadStartDev == null) {
            Log.e(tag, "session.threadStartDev == null");
            session.mViewPwd = viewPasswd;
            session.threadStartDev = new ThreadStartDev(session);
            session.threadStartDev.start();
        }
        if (session.threadRecvIOCtrl == null) {
            session.threadRecvIOCtrl = new ThreadRecvIOCtrl(session);
            session.threadRecvIOCtrl.start();
        }
        if (session.threadSendIOCtrl == null) {
            session.threadSendIOCtrl = new ThreadSendIOCtrl(session);
            session.threadSendIOCtrl.start();
        }
    }

    public void startShowHD(int avChannel, Surface sfs) {
        //synchronized (this.mAVChannels) {
            int i = 0;
            while (true) {
                if (i >= this.mAVChannels.size()) {
                    break;
                }
                AVChannel ch = this.mAVChannels.get(i);
                if (ch.getChannel() != avChannel) {
                    i++;
                } else {
                    if (ch.threadRecvVideo == null) {
                        ch.VideoFrameQueue.removeAll();
                        ch.threadRecvVideo = new ThreadRecvVideo(ch);
                        ch.threadRecvVideo.start();
                    }
                    if (ch.threadDecVideoHD == null) {
                        ch.threadDecVideoHD = new ThreadDecodeVideoHD(ch, sfs);
                        ch.threadDecVideoHD.start();
                    }
                }
            }
        //}
    }

    /* JADX WARN: Code restructure failed: missing block: B:50:0x001c, code lost:
        if (r0.threadDecVideoHD == null) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x001e, code lost:
        r0.threadDecVideoHD.stopThread();
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x0023, code lost:
        r0.threadDecVideoHD.join();
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x0043, code lost:
        r1 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x0044, code lost:
        r1.printStackTrace();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void stopShowHD(int r6) {
        /*
            r5 = this;
            java.util.List<com.tutk.IOTC.Camera$AVChannel> r4 = r5.mAVChannels
            monitor-enter(r4)
            r2 = 0
        L4:
            java.util.List<com.tutk.IOTC.Camera$AVChannel> r3 = r5.mAVChannels     // Catch: java.lang.Throwable -> L48
            int r3 = r3.size()     // Catch: java.lang.Throwable -> L48
            if (r2 >= r3) goto L41
            java.util.List<com.tutk.IOTC.Camera$AVChannel> r3 = r5.mAVChannels     // Catch: java.lang.Throwable -> L48
            java.lang.Object r0 = r3.get(r2)     // Catch: java.lang.Throwable -> L48
            com.tutk.IOTC.Camera$AVChannel r0 = (com.tutk.IOTC.Camera.AVChannel) r0     // Catch: java.lang.Throwable -> L48
            int r3 = r0.getChannel()     // Catch: java.lang.Throwable -> L48
            if (r3 != r6) goto L50
            com.tutk.IOTC.Camera$ThreadDecodeVideoHD r3 = r0.threadDecVideoHD     // Catch: java.lang.Throwable -> L48
            if (r3 == 0) goto L2b
            com.tutk.IOTC.Camera$ThreadDecodeVideoHD r3 = r0.threadDecVideoHD     // Catch: java.lang.Throwable -> L48
            r3.stopThread()     // Catch: java.lang.Throwable -> L48
            com.tutk.IOTC.Camera$ThreadDecodeVideoHD r3 = r0.threadDecVideoHD     // Catch: java.lang.InterruptedException -> L43 java.lang.Throwable -> L48
            r3.join()     // Catch: java.lang.InterruptedException -> L43 java.lang.Throwable -> L48
        L28:
            r3 = 0
            r0.threadDecVideoHD = r3     // Catch: java.lang.Throwable -> L48
        L2b:
            com.tutk.IOTC.AVFrameQueue r3 = r0.VideoFrameQueue     // Catch: java.lang.Throwable -> L48
            r3.removeAll()     // Catch: java.lang.Throwable -> L48
            com.tutk.IOTC.Camera$ThreadRecvVideo r3 = r0.threadRecvVideo     // Catch: java.lang.Throwable -> L48
            if (r3 == 0) goto L41
            com.tutk.IOTC.Camera$ThreadRecvVideo r3 = r0.threadRecvVideo     // Catch: java.lang.Throwable -> L48
            r3.stopThread()     // Catch: java.lang.Throwable -> L48
            com.tutk.IOTC.Camera$ThreadRecvVideo r3 = r0.threadRecvVideo     // Catch: java.lang.Throwable -> L48 java.lang.InterruptedException -> L4b
            r3.join()     // Catch: java.lang.Throwable -> L48 java.lang.InterruptedException -> L4b
        L3e:
            r3 = 0
            r0.threadRecvVideo = r3     // Catch: java.lang.Throwable -> L48
        L41:
            monitor-exit(r4)     // Catch: java.lang.Throwable -> L48
            return
        L43:
            r1 = move-exception
            r1.printStackTrace()     // Catch: java.lang.Throwable -> L48
            goto L28
        L48:
            r3 = move-exception
            monitor-exit(r4)     // Catch: java.lang.Throwable -> L48
            throw r3
        L4b:
            r1 = move-exception
            r1.printStackTrace()     // Catch: java.lang.Throwable -> L48
            goto L3e
        L50:
            int r2 = r2 + 1
            goto L4
        */
        //throw new UnsupportedOperationException("Method not decompiled: com.tutk.IOTC.Camera.stopShowHD(int):void");
    }

    public void startPlayQueueG711(int avChannel) {
        if (this.mPThreadplayG711_Queue != null) {
            this.mPThreadplayG711_Queue.stopThread();
            this.mPThreadplayG711_Queue = null;
        }
        synchronized (this.mAVChannels) {
            int i = 0;
            while (true) {
                if (i >= this.mAVChannels.size()) {
                    break;
                }
                AVChannel ch = this.mAVChannels.get(i);
                if (ch.getChannel() != avChannel) {
                    i++;
                } else {
                    ch.AudioFrameQueue.removeAll();
                    if (this.mPThreadplayG711_Queue == null) {
                        this.blnNeedSaveAudio = true;
                        this.mPThreadplayG711_Queue = new ThreadPlayG726AudioQueue(ch);
                        this.mPThreadplayG711_Queue.start();
                    }
                }
            }
        }
    }

    public void StopPlayQueueG711() {
        this.blnNeedSaveAudio = false;
        if (this.mPThreadplayG711_Queue != null) {
            this.mPThreadplayG711_Queue.stopThread();
            this.mPThreadplayG711_Queue = null;
        }
    }

    public void startRecordingG711(int avChannel, int iAudioLikeKind) {
        synchronized (this.mAVChannels) {
            int i = 0;
            while (true) {
                if (i >= this.mAVChannels.size()) {
                    break;
                }
                AVChannel ch = this.mAVChannels.get(i);
                if (ch.getChannel() != avChannel) {
                    i++;
                } else {
                    ch.AudioFrameQueue.removeAll();
                    if (this.mThreadRecordingG711file == null) {
                        this.mThreadRecordingG711file = new ThreadRecordingAudioG711(ch, iAudioLikeKind);
                        this.mThreadRecordingG711file.start();
                    }
                }
            }
        }
    }

    public void startRDT_SendFile(int avChannel, int iFileKind) {
        synchronized (this.mAVChannels) {
            int i = 0;
            while (true) {
                if (i >= this.mAVChannels.size()) {
                    break;
                }
                AVChannel ch = this.mAVChannels.get(i);
                if (ch.getChannel() != avChannel) {
                    i++;
                } else {
                    this.mPThreadRRDT_SendFile = new ThreadSendAudioG726_file(ch, iFileKind);
                    this.mPThreadRRDT_SendFile.start();
                    break;
                }
            }
        }
    }

    public void startRDT_SendFile(int avChannel, int iFileKind, String sFileNameString) {
        synchronized (this.mAVChannels) {
            int i = 0;
            while (true) {
                if (i >= this.mAVChannels.size()) {
                    break;
                }
                AVChannel ch = this.mAVChannels.get(i);
                if (ch.getChannel() != avChannel) {
                    i++;
                } else {
                    this.mPThreadRRDT_SendFile = new ThreadSendAudioG726_file(ch, iFileKind, sFileNameString);
                    this.mPThreadRRDT_SendFile.start();
                    break;
                }
            }
        }
    }

    public void stopRecordingG711(int avChannel, boolean needSend) {
        if (this.mThreadRecordingG711file != null) {
            this.mThreadRecordingG711file.stopThread(needSend);
            try {
                this.mThreadRecordingG711file.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            this.mThreadRecordingG711file = null;
        }
    }

    public void startRecvPhoto_file(int avChannel, int isize) {
        new ThreadRDT_RecvPhoto_file(avChannel, isize).start();
    }

    private synchronized boolean audioDev_init(int sampleRateInHz, int channel, int dataBit, int codec_id) {
        boolean z;
        String valueOf;
        if (!this.mInitAudio) {
            int channelConfig = channel == 1 ? 3 : 2;
            int audioFormat = dataBit == 1 ? 2 : 3;
            int mMinBufSize = AudioTrack.getMinBufferSize(sampleRateInHz, channelConfig, audioFormat);
            if (mMinBufSize == -2 || mMinBufSize == -1) {
                z = false;
            } else {
                try {
                    this.mAudioTrack = new AudioTrack(3, sampleRateInHz, channelConfig, 2, mMinBufSize, 1);
                    StringBuilder append = new StringBuilder().append("init AudioTrack with SampleRate:").append(sampleRateInHz).append(" ");
                    if (dataBit == 1) {
                        valueOf = String.valueOf(16);
                    } else {
                        valueOf = String.valueOf(8);
                    }
                    Log.e(tag, append.append(valueOf).append("bit ").append(channel == 1 ? "Stereo" : "Mono").toString());
                    if (codec_id == 141) {
                        DecSpeex.InitDecoder(sampleRateInHz);
                    } else if (codec_id == 142) {
                        int bit = dataBit == 1 ? 16 : 8;
                        DecMp3.InitDecoder(sampleRateInHz, bit);
                    } else if (codec_id == 139 || codec_id == 140) {
                        DecADPCM.ResetDecoder();
                    } else if (codec_id == 143) {
                        DecG726.g726_dec_state_create((byte) 0, (byte) 2);
                    }
                    this.mAudioTrack.play();
                    this.mInitAudio = true;
                    z = true;
                } catch (IllegalArgumentException iae) {
                    iae.printStackTrace();
                    z = false;
                }
            }
        } else {
            z = false;
        }
        return z;
    }

    public synchronized void audioDev_stop(int codec_id) {
        if (this.mInitAudio) {
            if (this.mAudioTrack != null) {
                this.mAudioTrack.stop();
                this.mAudioTrack.release();
                this.mAudioTrack = null;
            }
            if (codec_id == 141) {
                DecSpeex.UninitDecoder();
            } else if (codec_id == 142) {
                DecMp3.UninitDecoder();
            } else if (codec_id == 143) {
                DecG726.g726_dec_state_destroy();
            }
            this.mInitAudio = false;
        }
    }

    /* loaded from: classes.dex */
    public class ThreadRecvVideo extends Thread {
        private static final int BUFSIZE = 1843200;
        private boolean bIsRunning = false;
        private AVChannel mAVChannel;

        public ThreadRecvVideo(AVChannel channel) {
            //Camera.this = r2;
            this.mAVChannel = channel;
        }

        public void stopThread() {
            this.bIsRunning = false;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            System.gc();
            this.bIsRunning = true;
            while (this.bIsRunning && (Camera.this.mSID < 0 || this.mAVChannel.getAVIndex() < 0)) {
                try {
                    synchronized (Camera.this.mWaitObjectForConnected) {
                        Camera.this.mWaitObjectForConnected.wait();
                        break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            this.mAVChannel.VideoBPS = 0;
            byte[] recvBuf = new byte[512000];
            byte[] bytAVFrame = new byte[24];
            int[] pFrmNo = new int[1];
            int[] arrayOfInt2 = new int[1];
            int[] arrayOfInt3 = new int[1];
            int[] arrayOfInt4 = new int[1];
            int nFrmCount = 0;
            int nIncompleteFrmCount = 0;
            int nOnlineNumber = 0;
            long llastFrmnoLog = -2;
            long lastTimeStamp = System.currentTimeMillis();
            if (this.bIsRunning && Camera.this.mSID >= 0 && this.mAVChannel.getAVIndex() >= 0) {
                this.mAVChannel.IOCtrlQueue.Enqueue(this.mAVChannel.getAVIndex(), AVIOCTRLDEFs.IOTYPE_USER_IPCAM_START, Packet.intToByteArray_Little(Camera.this.mCamIndex));
                Log.e(Camera.tag, "IOCtrlQueue mCamIndex:" + Camera.this.mCamIndex);
            }
            AVAPIs.avClientCleanVideoBuf(this.mAVChannel.getAVIndex());
            this.mAVChannel.VideoFrameQueue.removeAll();
            while (this.bIsRunning) {
                if (Camera.this.mSID >= 0 && this.mAVChannel.getAVIndex() >= 0) {
                    if (System.currentTimeMillis() - lastTimeStamp > 1000) {
                        lastTimeStamp = System.currentTimeMillis();
                        for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                            IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                            listener.receiveFrameInfo(Camera.this, this.mAVChannel.getChannel(), ((this.mAVChannel.AudioBPS + this.mAVChannel.VideoBPS) * 8) / 1024, this.mAVChannel.VideoFPS, nOnlineNumber, nFrmCount, nIncompleteFrmCount);
                        }
                        AVChannel aVChannel = this.mAVChannel;
                        AVChannel aVChannel2 = this.mAVChannel;
                        this.mAVChannel.AudioBPS = 0;
                        aVChannel2.VideoBPS = 0;
                        aVChannel.VideoFPS = 0;
                    }
                    int nReadSize = AVAPIs.avRecvFrameData2(this.mAVChannel.getAVIndex(), recvBuf, recvBuf.length, arrayOfInt2, arrayOfInt3, bytAVFrame, 16, arrayOfInt4, pFrmNo);
                    if (nReadSize > 0) {
                        this.mAVChannel.VideoBPS += nReadSize;
                        nFrmCount++;
                        int iAudioSize = Packet.byteArrayToInt_Little(bytAVFrame, 8) * 320;
                        byte[] frameData = new byte[nReadSize - iAudioSize];
                        System.arraycopy(recvBuf, 0, frameData, 0, nReadSize - iAudioSize);
                        if (Camera.this.blnNeedSaveAudio.booleanValue() && iAudioSize > 0 && iAudioSize < 1281) {
                            byte[] frameAudioData = new byte[iAudioSize];
                            System.arraycopy(recvBuf, nReadSize - iAudioSize, frameAudioData, 0, iAudioSize);
                            AVFrame audioframe = new AVFrame(pFrmNo[0], (byte) 0, bytAVFrame, frameAudioData, iAudioSize, System.currentTimeMillis());
                            this.mAVChannel.AudioFrameQueue.addLast(audioframe);
                        }
                        AVFrame frame = new AVFrame(pFrmNo[0], (byte) 0, bytAVFrame, frameData, nReadSize - iAudioSize, System.currentTimeMillis());
                        int nCodecId = frame.getCodecId();
                        nOnlineNumber = frame.getOnlineNum();
                        if (nCodecId == 78) {
                            if (frame.isIFrame() || pFrmNo[0] == 1 + llastFrmnoLog) {
                                this.mAVChannel.VideoFrameQueue.addLast(frame);
                                llastFrmnoLog = pFrmNo[0];
                                try {
                                    Thread.sleep(33L);
                                } catch (InterruptedException e2) {
                                    e2.printStackTrace();
                                }
                            } else {
                                Log.e("Recv_Vedio", "lost framno:" + llastFrmnoLog);
                            }
                        } else if (nCodecId == 76) {
                            this.mAVChannel.VideoFrameQueue.addLast(frame);
                        } else if (nCodecId == 79) {
                            Bitmap bmp = BitmapFactory.decodeByteArray(frameData, 0, nReadSize);
                            if (bmp != null) {
                            }
                            try {
                                Thread.sleep(33L);
                            } catch (InterruptedException e3) {
                                e3.printStackTrace();
                            }
                        }
                    } else if (nReadSize == -20013) {
                        Log.e(Camera.tag, "AV_ER_INCOMPLETE_FRAME");
                        nFrmCount++;
                        nIncompleteFrmCount++;
                    } else if (nReadSize == -20014) {
                        nFrmCount++;
                        nIncompleteFrmCount++;
                    } else if (nReadSize == -20003) {
                        Log.e(Camera.tag, "AV_ER_MEM_INSUFF");
                    } else if (nReadSize == -20012) {
                        try {
                            Thread.sleep(33L);
                        } catch (InterruptedException e4) {
                            e4.printStackTrace();
                        }
                    } else if (nReadSize == -20016) {
                        Log.e(Camera.tag, "AV_ER_REMOTE_TIMEOUT_DISCONNECT");
                    } else if (nReadSize == -20015) {
                        Log.e(Camera.tag, "AV_ER_SESSION_CLOSE_BY_REMOTE");
                    } else {
                        try {
                            Thread.sleep(33L);
                        } catch (InterruptedException e5) {
                            e5.printStackTrace();
                        }
                    }
                }
            }
            this.mAVChannel.IOCtrlQueue.Enqueue(this.mAVChannel.getAVIndex(), AVIOCTRLDEFs.IOTYPE_USER_IPCAM_STOP, Packet.intToByteArray_Little(Camera.this.mCamIndex));
            Log.e(Camera.tag, "===ThreadRecvVideo exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadPlayG726AudioQueue extends Thread {
        private boolean bIsRunning = false;
        private boolean blnIsIniAacCode = false;
        private AVChannel mAVChannel;

        public ThreadPlayG726AudioQueue(AVChannel channel) {
            //Camera.this = r2;
            this.mAVChannel = channel;
        }

        public void stopThread() {
            this.bIsRunning = false;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            Process.setThreadPriority(-19);
            this.bIsRunning = true;
            while (this.bIsRunning && (Camera.this.mSID < 0 || this.mAVChannel.getAVIndex() < 0)) {
                try {
                    synchronized (Camera.this.mWaitObjectForConnected) {
                        Camera.this.mWaitObjectForConnected.wait(100L);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            this.mAVChannel.AudioBPS = 0;
            byte[] byteG711AudioBuf = new byte[2560];
            byte[] bytetemp = new byte[2560];
            byte[] bytecomplete = new byte[2048];
            int iLastLeft = 0;
            Boolean bFirst = true;
            while (this.bIsRunning) {
                int icount = this.mAVChannel.AudioFrameQueue.getCount();
                if (icount > 0) {
                    AVFrame avFrame = this.mAVChannel.AudioFrameQueue.removeHead();
                    int avFrameSize = avFrame.getFrmSize();
                    G711.ulaw2pcm(avFrame.frmData, byteG711AudioBuf, avFrameSize);
                    int iByteFramSize = avFrameSize * 2;
                    if (Camera.this.blnNeedRecording.booleanValue()) {
                        if (!this.blnIsIniAacCode) {
                            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                            String outFilepath = formatter.format(Long.valueOf(System.currentTimeMillis())) + ".aac";
                            String str = Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Shot/" + outFilepath;
                            Camera.this.voAAC = new VoAACEncoder();
                            Camera.this.voAAC.Init(8000, 32000, (short) 1, (short) 1);
                            this.blnIsIniAacCode = true;
                            Log.e(Camera.tag, "blnIsIniAacCode = true;");
                        }
                        if (Camera.this.blnIsVideoOK.booleanValue()) {
                            if (iLastLeft + iByteFramSize >= 2048) {
                                if (iLastLeft > 0) {
                                    System.arraycopy(bytetemp, 0, bytecomplete, 0, iLastLeft);
                                }
                                System.arraycopy(byteG711AudioBuf, 0, bytecomplete, iLastLeft, 2048 - iLastLeft);
                                int iThisLeft = iByteFramSize - (2048 - iLastLeft);
                                if (iThisLeft > 0) {
                                    System.arraycopy(byteG711AudioBuf, 2048 - iLastLeft, bytetemp, 0, iThisLeft);
                                }
                                iLastLeft = iThisLeft;
                                byte[] rect = Camera.this.voAAC.Enc(bytecomplete);
                                Log.e(Camera.tag, " ret.length:" + rect.length);
                                if (rect.length > 0) {
                                    AppCameraShooting.mp4packAudio(rect, rect.length);
                                }
                            } else {
                                System.arraycopy(byteG711AudioBuf, 0, bytetemp, iLastLeft, iByteFramSize);
                                iLastLeft += iByteFramSize;
                            }
                        } else {
                            Log.e(Camera.tag, "blnIsVideoOK==false!!!!!!!!!!!");
                        }
                    } else if (this.blnIsIniAacCode) {
                        Camera.this.voAAC.Uninit();
                        this.blnIsIniAacCode = false;
                    }
                    if (icount > 15 && System.currentTimeMillis() - avFrame.frmTimeStamp > 1000) {
                        Log.e("decodeHD", "AudioFrameQueue:" + icount);
                        Log.e("decodeHD", "abandon this Audiofrm:" + avFrame.getFrmNo());
                    } else {
                        if (bFirst.booleanValue()) {
                            int mMinBufSize = AudioTrack.getMinBufferSize(8000, 4, 2);
                            Camera.this.mAudioTrack = new AudioTrack(3, 8000, 4, 2, mMinBufSize, 1);
                            bFirst = false;
                            Camera.this.mAudioTrack.play();
                        }
                        Camera.this.mAudioTrack.write(byteG711AudioBuf, 0, iByteFramSize);
                        try {
                            sleep(10L);
                        } catch (InterruptedException e2) {
                            e2.printStackTrace();
                        }
                    }
                }
            }
            Camera.this.audioDev_stop(144);
            if (this.blnIsIniAacCode) {
                Camera.this.voAAC.Uninit();
            }
            Log.e(Camera.tag, "===ThreadPlayg711AudioQueue exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadRecordingAudioG711 extends Thread {
        int iAudiokind;
        private AVChannel mAVChannel;
        private boolean m_bIsRunning = false;
        long lLastTimeLong = 0;
        boolean blnSendVoice = true;

        public ThreadRecordingAudioG711(AVChannel ch, int ikind) {
            //Camera.this = r3;
            this.mAVChannel = null;
            this.iAudiokind = 0;
            this.mAVChannel = ch;
            this.iAudiokind = ikind;
        }

        public void stopThread(boolean NeedSend) {
            this.blnSendVoice = NeedSend;
            this.m_bIsRunning = false;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            int iAmp;
            short[] buffer;
            super.run();
            if (Camera.this.mSID < 0) {
                Log.e(Camera.tag, "=== ThreadRecordingAudioG711 exit because SID < 0 ===");
                return;
            }
            this.m_bIsRunning = true;
            boolean bInitG726Enc = false;
            int nMinBufSize = 0;
            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/SendAudio/Ranasee.temp");
            if (file.exists()) {
                file.delete();
            }
            try {
                file.createNewFile();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            OutputStream os = null;
            try {
                OutputStream os2 = new FileOutputStream(file);
                os = os2;
            } catch (Throwable th) {
                Log.e("AudioRecord", "Recording Failed");
            }
            if (this.m_bIsRunning) {
                bInitG726Enc = true;
                nMinBufSize = AudioRecord.getMinBufferSize(8000, 16, 2);
                Log.e(Camera.tag, "G726 encoder init minbufsize:" + nMinBufSize);
            }
            AudioRecord recorder = null;
            if (this.m_bIsRunning && bInitG726Enc) {
                recorder = new AudioRecord(1, 8000, 16, 2, nMinBufSize * 2);
                recorder.startRecording();
            }
            short[] inG726Buf = new short[320];
            byte[] outG726Buf = new byte[AVIOCTRLDEFs.IOTYPE_USER_IPCAM_SETSTREAMCTRL_REQ];
            if (this.iAudiokind > 0) {
                Camera.this.soundtouch.setSampleRate(8000);
                Camera.this.soundtouch.setChannels(1);
                if (this.iAudiokind == 1) {
                    Camera.this.soundtouch.setPitchSemiTones(3);
                    Camera.this.soundtouch.setRateChange(0.0f);
                    Camera.this.soundtouch.setTempoChange(-45.0f);
                } else if (this.iAudiokind == 2) {
                    Camera.this.soundtouch.setPitchSemiTones(-8);
                    Camera.this.soundtouch.setRateChange(0.0f);
                    Camera.this.soundtouch.setTempoChange(-30.0f);
                } else if (this.iAudiokind == 3) {
                    Camera.this.soundtouch.setPitchSemiTones(9);
                    Camera.this.soundtouch.setRateChange(0.0f);
                    Camera.this.soundtouch.setTempoChange(0.0f);
                }
            }
            while (this.m_bIsRunning) {
                int nReadBytes = recorder.read(inG726Buf, 0, inG726Buf.length);
                if (nReadBytes > 0) {
                    if (this.iAudiokind > 0) {
                        Camera.this.soundtouch.putSamples(inG726Buf, nReadBytes);
                        do {
                            buffer = Camera.this.soundtouch.receiveSamples();
                            Log.e(Camera.tag, "soundtouch.receiveSamples():" + buffer.length);
                            G711.pcm2ulaw(buffer, 0, outG726Buf, buffer.length);
                            try {
                                os.write(outG726Buf, 0, buffer.length);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } while (buffer.length > 0);
                    } else {
                        G711.pcm2ulaw(inG726Buf, 0, outG726Buf, nReadBytes);
                        try {
                            os.write(outG726Buf, 0, nReadBytes);
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    if (System.currentTimeMillis() - this.lLastTimeLong > 150) {
                        this.lLastTimeLong = System.currentTimeMillis();
                        long v = 0;
                        for (int i = 0; i < nReadBytes; i++) {
                            v += inG726Buf[i] * inG726Buf[i];
                        }
                        double mean = v / nReadBytes;
                        double volume = 10.0d * Math.log10(mean);
                        if (Camera.this.miclistener != null) {
                            if (volume < 40.0d) {
                                iAmp = 0;
                            } else if (volume <= 43.0d) {
                                iAmp = 1;
                            } else if (volume <= 47.0d) {
                                iAmp = 2;
                            } else if (volume <= 51.0d) {
                                iAmp = 3;
                            } else if (volume <= 56.0d) {
                                iAmp = 4;
                            } else if (volume <= 61.0d) {
                                iAmp = 5;
                            } else if (volume <= 65.0d) {
                                iAmp = 6;
                            } else if (volume <= 69.0d) {
                                iAmp = 7;
                            } else if (volume <= 75.0d) {
                                iAmp = 8;
                            } else {
                                iAmp = 9;
                            }
                            Camera.this.miclistener.onRecvMicAmp(iAmp);
                        }
                    }
                }
            }
            if (recorder != null) {
                recorder.stop();
                recorder.release();
                try {
                    os.close();
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                Log.e(Camera.tag, "startRDT_SendFile(0,11)");
                if (this.blnSendVoice) {
                    Camera.this.startRDT_SendFile(0, 11);
                }
            }
            Log.e(Camera.tag, "===ThreadRecordingAudioG711 exit===");
        }
    }

    public void setMicAmpListenerListener(MicAmpListener rockerListener) {
        this.miclistener = rockerListener;
    }

    public void unRigAmpListenerListener() {
        this.miclistener = null;
    }

    /* loaded from: classes.dex */
    public class ThreadSendAudioG726_file extends Thread {
        private AVChannel mAVChannel;
        int miFileKind;
        String sFileNameString;

        public ThreadSendAudioG726_file(AVChannel ch, int iFileKind) {
            //Camera.this = r3;
            this.mAVChannel = null;
            this.miFileKind = -1;
            this.sFileNameString = null;
            this.mAVChannel = ch;
            this.miFileKind = iFileKind;
        }

        public ThreadSendAudioG726_file(AVChannel ch, int iFileKind, String fileName) {
            //Camera.this = r3;
            this.mAVChannel = null;
            this.miFileKind = -1;
            this.sFileNameString = null;
            this.mAVChannel = ch;
            this.miFileKind = iFileKind;
            this.sFileNameString = fileName;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            super.run();
            if (Camera.this.mSID < 0) {
                Log.e(Camera.tag, "=== ThreadSendAudioG726_file exit because SID < 0 ===");
                for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                    IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                    listener.receiveRDTSendFileResult(Camera.this, this.miFileKind, Camera.this.mSID, "mSID err", 3);
                }
                return;
            }
            St_RDT_Status rdtStatus = new St_RDT_Status();
            File file = null;
            if (this.miFileKind == 11) {
                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/SendAudio/Ranasee.temp");
            } else if (this.miFileKind == 12) {
                file = new File(this.sFileNameString);
            } else if (this.miFileKind == 1) {
                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/CustomVoice/spin_custom.726");
            } else if (this.miFileKind == 2) {
                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/CustomVoice/smile_custom.726");
            } else if (this.miFileKind == 3) {
                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/CustomVoice/shy_custom.726");
            } else if (this.miFileKind == 4) {
                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/CustomVoice/sad_custom.726");
            } else if (this.miFileKind == 5) {
                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/CustomVoice/pride_custom.726");
            }
            int musicLength = (int) file.length();
            Log.e(Camera.tag, "musicLength=" + musicLength);
            byte[] byteSend = new byte[8];
            System.arraycopy(Packet.intToByteArray_Little(this.miFileKind), 0, byteSend, 0, 4);
            System.arraycopy(Packet.intToByteArray_Little(musicLength), 0, byteSend, 4, 4);
            Camera.this.sendIOCtrl(this.mAVChannel.mChannel, 12361, byteSend);
            int nRDTIndex = RDTAPIs.RDT_Create(Camera.this.mSID, Camera.RDT_WAIT_TIMEMS, 11);
            if (nRDTIndex < 0) {
                Log.e(Camera.tag, "=== ThreadSendAudioG726_file exit because nRDTIndex < 0 ===");
                for (int i2 = 0; i2 < Camera.this.mIOTCListeners.size(); i2++) {
                    IRegisterIOTCListener listener2 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i2);
                    listener2.receiveRDTSendFileResult(Camera.this, this.miFileKind, nRDTIndex, file.getName(), 3);
                }
                return;
            }
            byte[] sendStart = new byte[24];
            System.arraycopy("FILE_SEND_START_".getBytes(), 0, sendStart, 0, 16);
            System.arraycopy(Packet.intToByteArray_Little(this.miFileKind), 0, sendStart, 16, 4);
            System.arraycopy(Packet.intToByteArray_Little(musicLength), 0, sendStart, 20, 4);
            Log.e(Camera.tag, "musicLength2=" + musicLength);
            byte[] recvBuf = new byte[1024];
            int RectRW = RDTAPIs.RDT_Write(nRDTIndex, sendStart, sendStart.length);
            Log.e(Camera.tag, "RDT_Write FILE_SEND_START ret:" + RectRW);
            int RectRW2 = RDTAPIs.RDT_Read(nRDTIndex, recvBuf, 2, Camera.RDT_WAIT_TIMEMS);
            Log.e(Camera.tag, "RDT_Read FILE_SEND_START REC ret:" + RectRW2);
            if (new String(recvBuf).trim().equals("OK")) {
                Log.e(Camera.tag, "RDT_Read FILE_SEND_START REC OK");
            }
            InputStream is = null;
            try {
                InputStream is2 = new FileInputStream(file);
                is = is2;
            } catch (Throwable th) {
                Log.e("AudioTrack", "Playback Failed");
            }
            byte[] buffer = new byte[4096];
            int count = 0;
            while (true) {
                int iread = -1;
                try {
                    iread = is.read(buffer, 0, buffer.length);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (iread > 0) {
                    count += iread;
                    int iProgress = (int) ((count / musicLength) * 100.0f);
                    RDTAPIs.RDT_Write(nRDTIndex, buffer, iread);
                    for (int i3 = 0; i3 < Camera.this.mIOTCListeners.size(); i3++) {
                        IRegisterIOTCListener listener3 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i3);
                        listener3.receiveRDTSendFileResult(Camera.this, this.miFileKind, iProgress, file.getName(), 1);
                    }
                }
                if (iread < 0) {
                    break;
                }
                int RectRW3 = RDTAPIs.RDT_Status_Check(nRDTIndex, rdtStatus);
                if (RectRW3 == 0) {
                    if (Camera.this.mSessionMode == 2) {
                        if (rdtStatus.BufSizeInSendQueue > 1024000) {
                            try {
                                sleep(50L);
                            } catch (InterruptedException e2) {
                                e2.printStackTrace();
                            }
                        }
                    } else if (rdtStatus.BufSizeInSendQueue > 1024000) {
                        try {
                            sleep(80L);
                        } catch (InterruptedException e3) {
                            e3.printStackTrace();
                        }
                    }
                } else {
                    Log.e(Camera.tag, "RDT status check error:" + RectRW3);
                }
            }
            byte[] bArr = new byte[16];
            byte[] sendStart2 = "FILE_SEND_END___".getBytes();
            int RectRW4 = RDTAPIs.RDT_Write(nRDTIndex, sendStart2, sendStart2.length);
            Log.e(Camera.tag, "RDT_Write FILE_SEND_END ret:" + RectRW4);
            for (int i4 = 0; i4 < Camera.this.mIOTCListeners.size(); i4++) {
                IRegisterIOTCListener listener4 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i4);
                listener4.receiveRDTSendFileResult(Camera.this, this.miFileKind, RectRW4, file.getName(), 2);
            }
            RDTAPIs.RDT_Destroy(nRDTIndex);
            Log.e(Camera.tag, "===ThreadSendAudiog726_FILE exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadStartDev extends Thread {
        private AVChannel mAVChannel;
        private boolean mIsRunning = false;
        private Object mWaitObject = new Object();

        public ThreadStartDev(AVChannel channel) {
            //Camera.this = r2;
            this.mAVChannel = channel;
        }

        public void stopThread() {
            this.mIsRunning = false;
            if (Camera.this.mSID >= 0) {
                AVAPIs.avClientExit(Camera.this.mSID, this.mAVChannel.getChannel());
                Log.e(Camera.tag, "avClientExit(" + Camera.this.mSID + ", " + this.mAVChannel.getChannel() + ")");
            }
            synchronized (this.mWaitObject) {
                this.mWaitObject.notify();
            }
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            this.mIsRunning = true;
            Log.e(Camera.tag, "===ThreadStartDev Start===");
            while (true) {
                if (!this.mIsRunning) {
                    break;
                } else if (Camera.this.mSID < 0) {
                    try {
                        synchronized (Camera.this.mWaitObjectForConnected) {
                            Camera.this.mWaitObjectForConnected.wait(100L);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                        IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                        listener.receiveChannelInfo(Camera.this, this.mAVChannel.getChannel(), 3);
                    }
                    long[] nServType = {-1};
                    Log.e(Camera.tag, "avClientStart--begin---");
                    int avIndex = AVAPIs.avClientStart2(Camera.this.mSID, this.mAVChannel.getViewAcc(), this.mAVChannel.getViewPwd(), 30L, nServType, this.mAVChannel.getChannel(), Camera.this.bResend);
                    Log.e(Camera.tag, "avClientStart(" + this.mAVChannel.getChannel() + ", " + this.mAVChannel.getViewAcc() + ", " + this.mAVChannel.getViewPwd() + ") in Session(" + Camera.this.mSID + ") returns " + avIndex + " bResend = " + Camera.this.bResend[0]);
                    long servType = nServType[0];
                    if (avIndex >= 0) {
                        this.mAVChannel.setAVIndex(avIndex);
                        this.mAVChannel.setServiceType(servType);
                        Log.e(Camera.tag, "servType:" + servType);
                        for (int i2 = 0; i2 < Camera.this.mIOTCListeners.size(); i2++) {
                            IRegisterIOTCListener listener2 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i2);
                            listener2.receiveChannelInfo(Camera.this, this.mAVChannel.getChannel(), 9);
                        }
                        this.mIsRunning = false;
                    } else if (avIndex == -20000) {
                        Log.e(Camera.tag, "mIOTCListeners SIZE:" + Camera.this.mIOTCListeners.size());
                        for (int i3 = 0; i3 < Camera.this.mIOTCListeners.size(); i3++) {
                            IRegisterIOTCListener listener3 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i3);
                            listener3.receiveChannelInfo(Camera.this, this.mAVChannel.getChannel(), -1);
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {

                        }
                    } else if (avIndex == -20009) {
                        Log.e(Camera.tag, "mIOTCListeners SIZE:" + Camera.this.mIOTCListeners.size());
                        for (int i4 = 0; i4 < Camera.this.mIOTCListeners.size(); i4++) {
                            IRegisterIOTCListener listener4 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i4);
                            listener4.receiveChannelInfo(Camera.this, this.mAVChannel.getChannel(), 5);
                        }
                    } else {
                        try {
                            synchronized (this.mWaitObject) {
                                this.mWaitObject.wait(100L);
                            }
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                }
            }
            Log.e(Camera.tag, "===ThreadStartDev exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadCheckDevStatus extends Thread {
        private boolean m_bIsRunning;
        private Object m_waitObjForCheckDevStatus;

        private ThreadCheckDevStatus() {
            //Camera.this = r2;
            this.m_bIsRunning = false;
            this.m_waitObjForCheckDevStatus = new Object();
        }

        public void stopThread() {
            this.m_bIsRunning = false;
            synchronized (this.m_waitObjForCheckDevStatus) {
                this.m_waitObjForCheckDevStatus.notify();
            }
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            super.run();
            this.m_bIsRunning = true;
            St_SInfo stSInfo = new St_SInfo();
            do {
                try {
                    synchronized (Camera.this.mWaitObjectForConnected) {
                        Camera.this.mWaitObjectForConnected.wait(1000L);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (!this.m_bIsRunning) {
                    break;
                }
            } while (Camera.this.mSID < 0);
            Log.e(Camera.tag, "===ThreadCheckDevStatus Start===");
            while (this.m_bIsRunning) {
                if (Camera.this.mSID >= 0) {
                    int ret = IOTCAPIs.IOTC_Session_Check(Camera.this.mSID, stSInfo);
                    if (ret >= 0) {
                        if (Camera.this.mSessionMode != stSInfo.Mode) {
                            Camera.this.mSessionMode = stSInfo.Mode;
                        }
                    } else if (ret == -23 || ret == -13) {
                        Log.e(Camera.tag, "IOTC_Session_Check(" + Camera.this.mSID + ") timeout");
                        for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                            IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                            listener.receiveSessionInfo(Camera.this, 6);
                        }
                    } else {
                        Log.e(Camera.tag, "IOTC_Session_Check(" + Camera.this.mSID + ") Failed return " + ret);
                        for (int i2 = 0; i2 < Camera.this.mIOTCListeners.size(); i2++) {
                            IRegisterIOTCListener listener2 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i2);
                            listener2.receiveSessionInfo(Camera.this, 8);
                        }
                    }
                }
                synchronized (this.m_waitObjForCheckDevStatus) {
                    try {
                        this.m_waitObjForCheckDevStatus.wait(5000L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            Log.e(Camera.tag, "===ThreadCheckDevStatus exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadConnectDev extends Thread {
        private int mConnType;
        private boolean mIsRunning = false;
        private Object m_waitForStopConnectThread = new Object();

        public ThreadConnectDev(int connType) {
            //Camera.this = r2;
            this.mConnType = -1;
            this.mConnType = connType;
        }

        public void stopThread() {
            this.mIsRunning = false;
            Log.e(Camera.tag, "IOTC_Connect_Stop_BySID:" + Camera.this.nGet_SID);
            int nRet = IOTCAPIs.IOTC_Connect_Stop_BySID(Camera.this.nGet_SID);
            Log.e(Camera.tag, "IOTC_Connect_Stop_BySID_Ret:" + nRet);
            synchronized (this.m_waitForStopConnectThread) {
                this.m_waitForStopConnectThread.notify();
            }
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            int nRetryForIOTC_Conn = 0;
            this.mIsRunning = true;
            Log.e(Camera.tag, "===ThreadConnectDev start===!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            while (true) {
                if (!this.mIsRunning || Camera.this.mSID >= 0) {
                    break;
                }
                for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                    IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                    listener.receiveSessionInfo(Camera.this, 1);
                }
                if (this.mConnType == 0) {
                    Camera.this.nGet_SID = IOTCAPIs.IOTC_Get_SessionID();
                    Log.e("IOTCamera", "IOTC_Get_SessionID SID = " + Camera.this.nGet_SID);
                    if (Camera.this.nGet_SID >= 0) {
                        Log.e(Camera.tag, "IOTC_Connect_ByUID start---_SID:" + Camera.this.nGet_SID);
                        Camera.this.mSID = IOTCAPIs.IOTC_Connect_ByUID_Parallel(Camera.this.mDevUID, Camera.this.nGet_SID);
                        Log.e(Camera.tag, "IOTC_Connect_ByUID end (" + Camera.this.mDevUID + ") returns " + Camera.this.mSID);
                    }
                } else if (this.mConnType != 0) {
                    return;
                }
                if (this.mIsRunning) {
                    if (Camera.this.mSID < 0) {
                        if (Camera.this.mSID != -20) {
                            if (Camera.this.mSID == -15 || Camera.this.mSID == -10 || Camera.this.mSID == -19 || Camera.this.mSID == -13 || Camera.this.mSID == -42 || Camera.this.mSID == -41) {
                                if (Camera.this.mSID != -13) {
                                    for (int i2 = 0; i2 < Camera.this.mIOTCListeners.size(); i2++) {
                                        IRegisterIOTCListener listener2 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i2);
                                        listener2.receiveSessionInfo(Camera.this, 4);
                                    }
                                }
                                nRetryForIOTC_Conn++;
                                long sleepTime = nRetryForIOTC_Conn > 60 ? 60000L : nRetryForIOTC_Conn * AVAPIs.TIME_SPAN_LOSED;
                                try {
                                    synchronized (this.m_waitForStopConnectThread) {
                                        this.m_waitForStopConnectThread.wait(sleepTime);
                                    }
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            } else if (Camera.this.mSID == -36 || Camera.this.mSID == -37) {
                                for (int i3 = 0; i3 < Camera.this.mIOTCListeners.size(); i3++) {
                                    IRegisterIOTCListener listener3 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i3);
                                    listener3.receiveSessionInfo(Camera.this, 7);
                                }
                            } else {
                                for (int i4 = 0; i4 < Camera.this.mIOTCListeners.size(); i4++) {
                                    IRegisterIOTCListener listener4 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i4);
                                    listener4.receiveSessionInfo(Camera.this, 8);
                                    Log.e(Camera.tag, "ThreadConnectDev-->listener.receiveSessionInfo(Camera.this, 8)");
                                }
                            }
                        } else {
                            try {
                                synchronized (this.m_waitForStopConnectThread) {
                                    this.m_waitForStopConnectThread.wait(1000L);
                                }
                            } catch (InterruptedException e2) {
                                e2.printStackTrace();
                            }
                        }
                    } else {
                        for (int i5 = 0; i5 < Camera.this.mIOTCListeners.size(); i5++) {
                            IRegisterIOTCListener listener5 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i5);
                            listener5.receiveSessionInfo(Camera.this, 2);
                        }
                        synchronized (Camera.this.mWaitObjectForConnected) {
                            Camera.this.mWaitObjectForConnected.notifyAll();
                        }
                    }
                } else {
                    return;
                }
            }
            Log.e(Camera.tag, "===ThreadConnectDev exit=ttttttttttttttttttttttttttttttttttttt==");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadDecodeVideoHD extends Thread {
        private AVChannel mAVChannel;
        private boolean m_bIsRunning = false;

        public ThreadDecodeVideoHD(AVChannel channel, Surface surfaceNeedShow) {
            //Camera.this = r2;
            this.mAVChannel = channel;

            Camera.this.surface = surfaceNeedShow;
        }

        public void stopThread() {
            this.m_bIsRunning = false;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            int iISfram;
            Process.setThreadPriority(-19);
            Camera.this.blnIsVideoOK = false;
            System.gc();
            AVFrame avFrame = null;
            boolean bWaitI = true;
            boolean blnIniDecode = true;
            this.mAVChannel.VideoFPS = 0;
            this.m_bIsRunning = true;
            System.gc();
            ByteBuffer[] inputBuffers = null;
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            byte[] header_sps = new byte[14];
            byte[] header_pps = new byte[9];
            byte[] sps_pps = new byte[17];
            boolean blnIsRecording = false;
            boolean blnFirstWriteI = false;
            String outFilepath = null;
            while (this.m_bIsRunning) {
                int icount = this.mAVChannel.VideoFrameQueue.getCount();
                if (icount > 0) {
                    avFrame = this.mAVChannel.VideoFrameQueue.removeHead();
                    if (avFrame != null) {
                        int avFrameSize = avFrame.getFrmSize();
                        boolean blnIsI = avFrame.isIFrame();
                        if (blnIsI) {
                            iISfram = 1;
                        } else {
                            iISfram = 0;
                        }
                        if (bWaitI) {
                            if (blnIsI && avFrame.getFrmState() == 0) {
                                bWaitI = false;
                            } else {
                                avFrame = null;
                                avFrameSize = 0;
                            }
                        }
                        if (avFrame != null && !blnIsI && 0 > 3) {
                            avFrame = null;
                        } else {
                            if (avFrameSize > 0) {
                                int id = avFrame.getCodecId();
                                if (id == 78) {
                                    if (blnIniDecode) {
                                        boolean blnFindsps = false;
                                        boolean blnFindpps = false;
                                        int spsPos = -1;
                                        int ppsPos = -1;
                                        for (int i = 0; i < avFrameSize - 5; i++) {
                                            if (avFrame.frmData[i] == 0 && avFrame.frmData[i + 1] == 0 && avFrame.frmData[i + 2] == 0 && avFrame.frmData[i + 3] == 1 && avFrame.frmData[i + 4] == 103) {
                                                blnFindsps = true;
                                                spsPos = i;
                                                Log.e(Camera.tag, "find  sps:" + i);
                                                int j = spsPos + 12;
                                                while (true) {
                                                    if (j >= avFrameSize - 5) {
                                                        break;
                                                    } else if (avFrame.frmData[i] != 0 || avFrame.frmData[j + 1] != 0 || avFrame.frmData[j + 2] != 0 || avFrame.frmData[j + 3] != 1 || avFrame.frmData[j + 4] != 104) {
                                                        j++;
                                                    } else {
                                                        blnFindpps = true;
                                                        ppsPos = j;
                                                        Log.e(Camera.tag, "find  pps:" + j);
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        if (blnFindsps && blnFindpps) {
                                            try {
                                                Camera.this.mediaCodec = MediaCodec.createDecoderByType("video/avc");
                                            } catch (IOException e) {
                                                throw new RuntimeException(e);
                                            }
                                            MediaFormat mediaFormat = MediaFormat.createVideoFormat("video/avc", 1280, 720);
                                            System.arraycopy(avFrame.frmData, spsPos, header_sps, 0, 13);
                                            Log.e(Camera.tag, Camera.getHex(header_sps, 13));
                                            System.arraycopy(avFrame.frmData, ppsPos, header_pps, 0, 8);
                                            Log.e(Camera.tag, Camera.getHex(header_pps, 8));
                                            System.arraycopy(header_sps, 4, sps_pps, 0, 10);
                                            System.arraycopy(header_pps, 4, sps_pps, 13, 4);
                                            Log.e(Camera.tag, Camera.getHex(sps_pps, 17));
                                            mediaFormat.setByteBuffer("csd-0", ByteBuffer.wrap(header_sps));
                                            mediaFormat.setByteBuffer("csd-1", ByteBuffer.wrap(header_pps));
                                            mediaFormat.setString("mime", "video/avc");
                                            Log.e(Camera.tag, " mediaCodec.configure.start()");
                                            Camera.this.mediaCodec.configure(mediaFormat, Camera.this.surface, (MediaCrypto) null, 0);
                                            Log.e(Camera.tag, " mediaCodec.configure.End()");
                                            Camera.this.mediaCodec.start();
                                            inputBuffers = Camera.this.mediaCodec.getInputBuffers();
                                            blnIniDecode = false;
                                        } else {
                                            Log.e(Camera.tag, "can't find pps or sps.");
                                        }
                                    }
                                    if (Camera.this.blnNeedRecording.booleanValue()) {
                                        if (!blnIsRecording) {
                                            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                                            String outFilepath2 = formatter.format(Long.valueOf(System.currentTimeMillis())) + ".mp4";
                                            outFilepath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Shot/" + outFilepath2;
                                            AppCameraShooting.mp4init(outFilepath, 1, sps_pps);
                                            blnIsRecording = true;
                                        }
                                        if (!blnFirstWriteI) {
                                            if (blnIsI) {
                                                byte[] toMp4 = new byte[avFrameSize];
                                                System.arraycopy(avFrame.frmData, 0, toMp4, 0, avFrameSize);
                                                AppCameraShooting.mp4packVideo(toMp4, avFrameSize, iISfram);
                                                Camera.this.blnIsVideoOK = true;
                                                blnFirstWriteI = true;
                                                Log.e(Camera.tag, "blnIsVideoOK = true;  ");
                                            }
                                        } else {
                                            byte[] toMp42 = new byte[avFrameSize];
                                            System.arraycopy(avFrame.frmData, 0, toMp42, 0, avFrameSize);
                                            AppCameraShooting.mp4packVideo(toMp42, avFrameSize, iISfram);
                                        }
                                    } else if (blnIsRecording) {
                                        AppCameraShooting.mp4close();
                                        blnIsRecording = false;
                                        Camera.this.blnIsVideoOK = false;
                                        blnFirstWriteI = false;
                                        if (outFilepath != null) {
                                            for (int i2 = 0; i2 < Camera.this.mIOTCListeners.size(); i2++) {
                                                IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i2);
                                                listener.receiveRDTSendFileResult(Camera.this, 0, 1, outFilepath, 8);
                                            }
                                        }
                                    }
                                    int inputBufferIndex = Camera.this.mediaCodec.dequeueInputBuffer(-1L);
                                    if (inputBufferIndex >= 0) {
                                        ByteBuffer inputBuffer = inputBuffers[inputBufferIndex];
                                        inputBuffer.clear();
                                        inputBuffer.put(avFrame.frmData, 0, avFrameSize);
                                        Camera.this.mediaCodec.queueInputBuffer(inputBufferIndex, 0, avFrameSize, avFrame.getTimeStamp(), 0);
                                    }
                                    int outputBufferIndex = Camera.this.mediaCodec.dequeueOutputBuffer(bufferInfo, 0L);
                                    while (outputBufferIndex >= 0) {
                                        Camera.this.mediaCodec.releaseOutputBuffer(outputBufferIndex, true);
                                        outputBufferIndex = Camera.this.mediaCodec.dequeueOutputBuffer(bufferInfo, 0L);
                                    }
                                }
                            }
                            this.mAVChannel.VideoFPS++;
                        }
                    }
                } else {
                    try {
                        Thread.sleep(10L);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if (avFrame != null) {
                    avFrame.frmData = null;
                }
                avFrame = null;
            }
            if (blnIsRecording) {
                AppCameraShooting.mp4close();
                blnIsRecording = false;
                Camera.this.blnIsVideoOK = false;
                if (outFilepath != null) {
                    for (int i3 = 0; i3 < Camera.this.mIOTCListeners.size(); i3++) {
                        IRegisterIOTCListener listener2 = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i3);
                        listener2.receiveRDTSendFileResult(Camera.this, 0, 1, outFilepath, 8);
                    }
                }
            }
            if (!blnIniDecode) {
                Log.e(Camera.tag, " mediaCodec.stop()");
                Camera.this.mediaCodec.stop();
                Camera.this.mediaCodec.release();
                Camera.this.mediaCodec = null;
            }
            if (blnIsRecording) {
                AppCameraShooting.mp4close();
            }
            System.gc();
            Log.e(Camera.tag, "===ThreadDecodeVideoHD exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadSendIOCtrl extends Thread {
        private boolean bIsRunning = false;
        private AVChannel mAVChannel;

        public ThreadSendIOCtrl(AVChannel channel) {
            //Camera.this = r2;
            this.mAVChannel = channel;
        }

        public void stopThread() {
            this.bIsRunning = false;
            if (this.mAVChannel.getAVIndex() >= 0) {
                Log.e(Camera.tag, "avSendIOCtrlExit(" + this.mAVChannel.getAVIndex() + ")");
                AVAPIs.avSendIOCtrlExit(this.mAVChannel.getAVIndex());
            }
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            this.bIsRunning = true;
            while (this.bIsRunning && (Camera.this.mSID < 0 || this.mAVChannel.getAVIndex() < 0)) {
                try {
                    synchronized (Camera.this.mWaitObjectForConnected) {
                        Camera.this.mWaitObjectForConnected.wait(1000L);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (!this.bIsRunning || Camera.this.mSID < 0 || this.mAVChannel.getAVIndex() >= 0) {
            }
            while (this.bIsRunning) {
                if (Camera.this.mSID >= 0 && this.mAVChannel.getAVIndex() >= 0 && !this.mAVChannel.IOCtrlQueue.isEmpty()) {
                    IOCtrlQueue.IOCtrlSet data = this.mAVChannel.IOCtrlQueue.Dequeue();
                    if (this.bIsRunning && data != null) {
                        int ret = AVAPIs.avSendIOCtrl(this.mAVChannel.getAVIndex(), data.IOCtrlType, data.IOCtrlBuf, data.IOCtrlBuf.length);
                        if (ret >= 0) {
                            Log.e(Camera.tag, "avSendIOCtrlReal(" + this.mAVChannel.getAVIndex() + ", 0x" + Integer.toHexString(data.IOCtrlType) + ", " + Camera.getHex(data.IOCtrlBuf, data.IOCtrlBuf.length) + ")");
                        } else {
                            Log.e(Camera.tag, "avSendIOCtrl failed : " + ret);
                            for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                                IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                                listener.receiveSessionInfo(Camera.this, 9999);
                            }
                        }
                    }
                } else {
                    try {
                        Thread.sleep(50L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            Log.e(Camera.tag, "===ThreadSendIOCtrl exit===");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadRDT_RecvPhoto_file extends Thread {
        File fRecFile;
        private int mNeedRecPack;
        private int mRDTChannel;
        private boolean bIsRunning = false;
        int nRDTIndex = -1;

        public ThreadRDT_RecvPhoto_file(int channel, int totalcount) {
            //Camera.this = r4;
            this.mRDTChannel = channel;
            this.mNeedRecPack = totalcount;
            Log.e(Camera.tag, "mNeedRecPack:" + this.mNeedRecPack);
        }

        public void stopThread() {
            this.bIsRunning = false;
        }

        /* JADX WARN: Code restructure failed: missing block: B:134:0x00e6, code lost:
            if (r28.nRDTIndex >= 0) goto L36;
         */
        /* JADX WARN: Code restructure failed: missing block: B:136:0x00ec, code lost:
            if (r28.bIsRunning == false) goto L92;
         */
        /* JADX WARN: Code restructure failed: missing block: B:137:0x00ee, code lost:
            com.tutk.IOTC.RDTAPIs.RDT_Read(r28.nRDTIndex, r0, 24, com.tutk.IOTC.Camera.RDT_WAIT_TIMEMS);
         */
        /* JADX WARN: Code restructure failed: missing block: B:138:0x010d, code lost:
            if (new java.lang.String(r0).trim().contains("FILE_SEND_END") == false) goto L40;
         */
        /* JADX WARN: Code restructure failed: missing block: B:139:0x010f, code lost:
            android.util.Log.e(com.tutk.IOTC.Camera.tag, "RDT_Read FILE_SEND_END.exit");
         */
        /* JADX WARN: Code restructure failed: missing block: B:145:0x012b, code lost:
            r28.mNeedRecPack = com.tutk.IOTC.Packet.byteArrayToInt_Little(r0, 20);
            r0 = new byte[]{79, 75};
            r12 = com.tutk.IOTC.RDTAPIs.RDT_Write(r28.nRDTIndex, r0, 2);
            android.util.Log.e(com.tutk.IOTC.Camera.tag, "RDT_Write OK ret:" + r12);
            r13 = true;
            r25 = null;
            r24 = null;
            r21 = null;
         */
        /* JADX WARN: Code restructure failed: missing block: B:147:0x0174, code lost:
            if (r28.bIsRunning == false) goto L80;
         */
        /* JADX WARN: Code restructure failed: missing block: B:148:0x0176, code lost:
            if (r13 == false) goto L58;
         */
        /* JADX WARN: Code restructure failed: missing block: B:149:0x0178, code lost:
            r13 = false;
            r17 = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault());
            r25 = r17.format(java.lang.Long.valueOf(java.lang.System.currentTimeMillis()));
            r24 = android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Shot/";
            r28.fRecFile = new java.io.File(r24 + r25 + ".tmp");
            r19 = 0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:150:0x01dd, code lost:
            if (r28.fRecFile.exists() == false) goto L47;
         */
        /* JADX WARN: Code restructure failed: missing block: B:151:0x01df, code lost:
            r28.fRecFile.delete();
         */
        /* JADX WARN: Code restructure failed: missing block: B:152:0x01e6, code lost:
            r28.fRecFile.createNewFile();
         */
        /* JADX WARN: Code restructure failed: missing block: B:165:0x02a0, code lost:
            r16 = move-exception;
         */
        /* JADX WARN: Code restructure failed: missing block: B:166:0x02a1, code lost:
            r16.printStackTrace();
         */
        /* JADX WARN: Removed duplicated region for block: B:157:0x0202  */
        /* JADX WARN: Removed duplicated region for block: B:164:0x027b A[LOOP:4: B:162:0x026b->B:164:0x027b, LOOP_END] */
        /* JADX WARN: Removed duplicated region for block: B:169:0x02b0  */
        /* JADX WARN: Removed duplicated region for block: B:178:0x034f A[LOOP:5: B:176:0x033f->B:178:0x034f, LOOP_END] */
        /* JADX WARN: Removed duplicated region for block: B:200:0x0212 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:202:0x0170 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:203:0x0170 A[SYNTHETIC] */
        @Override // java.lang.Thread, java.lang.Runnable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void run() {
            /*
                Method dump skipped, instructions count: 888
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.tutk.IOTC.Camera.ThreadRDT_RecvPhoto_file.run():void");
        }
    }

    /* loaded from: classes.dex */
    public class ThreadRecvIOCtrl extends Thread {
        private final int TIME_OUT = 0;
        private boolean bIsRunning = false;
        private AVChannel mAVChannel;

        public ThreadRecvIOCtrl(AVChannel channel) {
            //Camera.this = r2;
            this.mAVChannel = channel;
        }

        public void stopThread() {
            this.bIsRunning = false;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            this.bIsRunning = true;
            while (true) {
                try {
                    synchronized (Camera.this.mWaitObjectForConnected) {
                        Camera.this.mWaitObjectForConnected.wait();
                        break;
                    }
                } catch (Exception e) {
                    break;
                }

            }
            while (this.bIsRunning) {
                if (Camera.this.mSID >= 0 && this.mAVChannel.getAVIndex() >= 0) {
                    int[] ioCtrlType = new int[1];
                    byte[] ioCtrlBuf = new byte[1024];
                    int nRet = AVAPIs.avRecvIOCtrl(this.mAVChannel.getAVIndex(), ioCtrlType, ioCtrlBuf, ioCtrlBuf.length, 0);
                    if (nRet >= 0) {
                        Log.e(Camera.tag, "avRecvIOCtrlReal(" + this.mAVChannel.getAVIndex() + ", 0x" + Integer.toHexString(ioCtrlType[0]));
                        byte[] data = new byte[nRet];
                        System.arraycopy(ioCtrlBuf, 0, data, 0, nRet);
                        if (ioCtrlType[0] == 811) {
                            int channel = Packet.byteArrayToInt_Little(data, 0);
                            int format = Packet.byteArrayToInt_Little(data, 4);
                            Iterator it = Camera.this.mAVChannels.iterator();
                            while (true) {
                                if (!it.hasNext()) {
                                    break;
                                }
                                AVChannel ch = (AVChannel) it.next();
                                if (ch.getChannel() == channel) {
                                    ch.setAudioCodec(format);
                                    break;
                                }
                            }
                        } else if (ioCtrlType[0] == 912) {
                            int k = Packet.byteArrayToInt_Little(data, 0);
                            int m = Packet.byteArrayToInt_Little(data, 4);
                            Iterator it2 = Camera.this.mAVChannels.iterator();
                            while (true) {
                                if (!it2.hasNext()) {
                                    break;
                                }
                                AVChannel ch2 = (AVChannel) it2.next();
                                if (ch2.getChannel() == k) {
                                    ch2.flowInfoInterval = m;
                                    Camera.this.sendIOCtrl(this.mAVChannel.mChannel, AVIOCTRLDEFs.IOTYPE_USER_IPCAM_GET_FLOWINFO_RESP, AVIOCTRLDEFs.SMsgAVIoctrlGetFlowInfoResp.parseContent(k, ch2.flowInfoInterval));
                                    break;
                                }
                            }
                        }
                        for (int i = 0; i < Camera.this.mIOTCListeners.size(); i++) {
                            IRegisterIOTCListener listener = (IRegisterIOTCListener) Camera.this.mIOTCListeners.get(i);
                            listener.receiveIOCtrlData(Camera.this, this.mAVChannel.getChannel(), ioCtrlType[0], data);
                        }
                    } else {
                        try {
                            Thread.sleep(100L);
                        } catch (InterruptedException e2) {
                            e2.printStackTrace();
                        }
                    }
                }
            }
            Log.e(Camera.tag, "===ThreadRecvIOCtrl exit===");
        }
    }

    /* loaded from: classes.dex */
    public class AVChannel {
        public IOCtrlQueue IOCtrlQueue;
        public byte[] LastYuv;
        private int mAudioCodec;
        private volatile int mChannel;
        private long mServiceType;
        private String mViewAcc;
        private String mViewPwd;
        public int mnAVCodecCtxIdx_h264;
        private volatile int mAVIndex = -1;
        public ThreadStartDev threadStartDev = null;
        public ThreadRecvIOCtrl threadRecvIOCtrl = null;
        public ThreadSendIOCtrl threadSendIOCtrl = null;
        public ThreadRecvVideo threadRecvVideo = null;
        public ThreadDecodeVideoHD threadDecVideoHD = null;
        public int flowInfoInterval = 0;
        public int AudioBPS = 0;
        public int VideoBPS = 0;
        public int VideoFPS = 0;
        public Bitmap LastFrame = null;
        public AVFrameQueue VideoFrameQueue = new AVFrameQueue();
        public AVFrameQueue AudioFrameQueue = new AVFrameQueue();

        public AVChannel(int channel, String view_acc, String view_pwd) {
            //Camera.this = r7;
            this.mChannel = -1;
            this.mServiceType = 0L;
            this.mChannel = channel;
            this.mViewAcc = view_acc;
            this.mViewPwd = view_pwd;
            this.mServiceType = 0L;
            this.IOCtrlQueue = new IOCtrlQueue();
        }

        public int getChannel() {
            return this.mChannel;
        }

        public synchronized int getAVIndex() {
            return this.mAVIndex;
        }

        public synchronized void setAVIndex(int idx) {
            this.mAVIndex = idx;
        }

        public synchronized long getServiceType() {
            return this.mServiceType;
        }

        public synchronized int getAudioCodec() {
            return this.mAudioCodec;
        }

        public synchronized void setAudioCodec(int codec) {
            this.mAudioCodec = codec;
        }

        public synchronized void setServiceType(long serviceType) {
            this.mServiceType = serviceType;
            this.mAudioCodec = (4096 & serviceType) == 0 ? AVFrame.MEDIA_CODEC_AUDIO_SPEEX : AVFrame.MEDIA_CODEC_AUDIO_ADPCM;
        }

        public String getViewAcc() {
            return this.mViewAcc;
        }

        public String getViewPwd() {
            return this.mViewPwd;
        }
    }

    /* loaded from: classes.dex */
    public class IOCtrlQueue {
        LinkedList<IOCtrlSet> listData;

        private IOCtrlQueue() {
            //Camera.this = r2;
            this.listData = new LinkedList<>();
        }

        /* loaded from: classes.dex */
        public class IOCtrlSet {
            public byte[] IOCtrlBuf;
            public int IOCtrlType;

            public IOCtrlSet(int avIndex, int type, byte[] buf) {
                //IOCtrlQueue.this = this$1;
                this.IOCtrlType = type;
                this.IOCtrlBuf = buf;
            }

            public IOCtrlSet(int type, byte[] buf) {
                //IOCtrlQueue.this = this$1;
                this.IOCtrlType = type;
                this.IOCtrlBuf = buf;
            }
        }

        public synchronized boolean isEmpty() {
            return this.listData.isEmpty();
        }

        public synchronized void Enqueue(int type, byte[] data) {
            this.listData.addLast(new IOCtrlSet(type, data));
        }

        public synchronized void Enqueue(int avIndex, int type, byte[] data) {
            this.listData.addLast(new IOCtrlSet(avIndex, type, data));
        }

        public synchronized IOCtrlSet Dequeue() {
            return this.listData.isEmpty() ? null : this.listData.removeFirst();
        }

        public synchronized void removeAll() {
            if (!this.listData.isEmpty()) {
                this.listData.clear();
            }
        }
    }

    public static String getHex(byte[] raw, int size) {
        if (raw == null) {
            return null;
        }
        StringBuilder hex = new StringBuilder(raw.length * 2);
        int len = 0;
        for (byte b : raw) {
            hex.append(HEXES.charAt((b & 240) >> 4)).append(HEXES.charAt(b & 15)).append(" ");
            len++;
            if (len >= size) {
                break;
            }
        }
        return hex.toString();
    }
}
