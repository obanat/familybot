package com.tutk.IOTC;

/* loaded from: classes.dex */
public class St_RDT_Status {
    public long BufSizeInRecvQueue;
    public long BufSizeInSendQueue;
    public short Timeout;
    public short TimeoutThreshold;
}
