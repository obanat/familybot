package com.tutk.IOTC;

/* loaded from: classes.dex */
public class Packet {
    public static final short byteArrayToShort_Little(byte[] byt, int nBeginPos) {
        return (short) ((byt[nBeginPos] & AVFrame.FRM_STATE_UNKOWN) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 8));
    }

    public static final int byteArrayToInt_Little(byte[] byt, int nBeginPos) {
        return (byt[nBeginPos] & AVFrame.FRM_STATE_UNKOWN) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 8) | ((byt[nBeginPos + 2] & AVFrame.FRM_STATE_UNKOWN) << 16) | ((byt[nBeginPos + 3] & AVFrame.FRM_STATE_UNKOWN) << 24);
    }

    public static final int byteArrayToInt_Little(byte[] byt) {
        if (byt.length == 1) {
            return byt[0] & AVFrame.FRM_STATE_UNKOWN;
        }
        if (byt.length == 2) {
            return (byt[0] & AVFrame.FRM_STATE_UNKOWN) | ((byt[1] & AVFrame.FRM_STATE_UNKOWN) << 8);
        }
        if (byt.length == 4) {
            return (byt[0] & AVFrame.FRM_STATE_UNKOWN) | ((byt[1] & AVFrame.FRM_STATE_UNKOWN) << 8) | ((byt[2] & AVFrame.FRM_STATE_UNKOWN) << 16) | ((byt[3] & AVFrame.FRM_STATE_UNKOWN) << 24);
        }
        return 0;
    }

    public static final long byteArrayToLong_Little(byte[] byt, int nBeginPos) {
        return (byt[nBeginPos] & AVFrame.FRM_STATE_UNKOWN) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 8) | ((byt[nBeginPos + 2] & AVFrame.FRM_STATE_UNKOWN) << 16) | ((byt[nBeginPos + 3] & AVFrame.FRM_STATE_UNKOWN) << 24) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 32) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 40) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 48) | ((byt[nBeginPos + 1] & AVFrame.FRM_STATE_UNKOWN) << 56);
    }

    public static final int byteArrayToInt_Big(byte[] byt) {
        if (byt.length == 1) {
            return byt[0] & AVFrame.FRM_STATE_UNKOWN;
        }
        if (byt.length == 2) {
            return ((byt[0] & AVFrame.FRM_STATE_UNKOWN) << 8) | (byt[1] & AVFrame.FRM_STATE_UNKOWN);
        }
        if (byt.length == 4) {
            return ((byt[0] & AVFrame.FRM_STATE_UNKOWN) << 24) | ((byt[1] & AVFrame.FRM_STATE_UNKOWN) << 16) | ((byt[2] & AVFrame.FRM_STATE_UNKOWN) << 8) | (byt[3] & AVFrame.FRM_STATE_UNKOWN);
        }
        return 0;
    }

    public static final byte[] longToByteArray_Little(long value) {
        return new byte[]{(byte) value, (byte) (value >>> 8), (byte) (value >>> 16), (byte) (value >>> 24), (byte) (value >>> 32), (byte) (value >>> 40), (byte) (value >>> 48), (byte) (value >>> 56)};
    }

    public static final byte[] intToByteArray_Little(int value) {
        return new byte[]{(byte) value, (byte) (value >>> 8), (byte) (value >>> 16), (byte) (value >>> 24)};
    }

    public static final byte[] intToByteArray_Big(int value) {
        return new byte[]{(byte) (value >>> 24), (byte) (value >>> 16), (byte) (value >>> 8), (byte) value};
    }

    public static final byte[] shortToByteArray_Little(short value) {
        return new byte[]{(byte) value, (byte) (value >>> 8)};
    }

    public static final byte[] shortToByteArray_Big(short value) {
        return new byte[]{(byte) (value >>> 8), (byte) value};
    }
}
