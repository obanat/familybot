package com.tutk.IOTC;

/* loaded from: classes.dex */
public class AVFrame {
    public static final int AUDIO_CHANNEL_MONO = 0;
    public static final int AUDIO_CHANNEL_STERO = 1;
    public static final int AUDIO_DATABITS_16 = 1;
    public static final int AUDIO_DATABITS_8 = 0;
    public static final int AUDIO_SAMPLE_11K = 1;
    public static final int AUDIO_SAMPLE_12K = 2;
    public static final int AUDIO_SAMPLE_16K = 3;
    public static final int AUDIO_SAMPLE_22K = 4;
    public static final int AUDIO_SAMPLE_24K = 5;
    public static final int AUDIO_SAMPLE_32K = 6;
    public static final int AUDIO_SAMPLE_44K = 7;
    public static final int AUDIO_SAMPLE_48K = 8;
    public static final int AUDIO_SAMPLE_8K = 0;
    public static final int FRAMEINFO_SIZE = 24;
    public static final byte FRM_STATE_COMPLETE = 0;
    public static final byte FRM_STATE_INCOMPLETE = 1;
    public static final byte FRM_STATE_LOSED = 2;
    public static final byte FRM_STATE_UNKOWN = -1;
    public static final int IPC_FRAME_FLAG_IFRAME = 1;
    public static final int IPC_FRAME_FLAG_IO = 3;
    public static final int IPC_FRAME_FLAG_MD = 2;
    public static final int IPC_FRAME_FLAG_PBFRAME = 0;
    public static final int MEDIA_CODEC_AUDIO_ADPCM = 139;
    public static final int MEDIA_CODEC_AUDIO_G726 = 143;
    public static final int MEDIA_CODEC_AUDIO_MP3 = 142;
    public static final int MEDIA_CODEC_AUDIO_PCM = 140;
    public static final int MEDIA_CODEC_AUDIO_SPEEX = 141;
    public static final int MEDIA_CODEC_UNKNOWN = 0;
    public static final int MEDIA_CODEC_VIDEO_H263 = 77;
    public static final int MEDIA_CODEC_VIDEO_H264 = 78;
    public static final int MEDIA_CODEC_VIDEO_MJPEG = 79;
    public static final int MEDIA_CODEC_VIDEO_MPEG4 = 76;
    private byte camindex;
    private short codec_id;
    private byte flags;
    public byte[] frmData;
    private long frmNo;
    private int frmSize;
    private byte frmState;
    public long frmTimeStamp;
    private byte onlineNum;
    private int timestamp;
    private int videoHeight;
    private int videoWidth;

    public AVFrame(long frameNo, byte frameState, byte[] frameHead, byte[] frameData, int frameDataSize, long time) {
        this.codec_id = (short) 0;
        this.flags = (byte) -1;
        this.onlineNum = (byte) 0;
        this.timestamp = 0;
        this.camindex = (byte) 0;
        this.videoWidth = 0;
        this.videoHeight = 0;
        this.frmNo = -1L;
        this.frmState = (byte) 0;
        this.frmSize = 0;
        this.frmData = null;
        this.frmTimeStamp = 0L;
        this.codec_id = Packet.byteArrayToShort_Little(frameHead, 0);
        this.flags = frameHead[2];
        this.camindex = frameHead[3];
        this.frmState = frameState;
        this.frmNo = frameNo;
        this.onlineNum = frameHead[4];
        this.timestamp = Packet.byteArrayToInt_Little(frameHead, 12);
        this.videoWidth = frameHead.length > 16 ? Packet.byteArrayToInt_Little(frameHead, 16) : 0;
        this.videoHeight = frameHead.length > 16 ? Packet.byteArrayToInt_Little(frameHead, 20) : 0;
        this.frmSize = frameDataSize;
        this.frmData = frameData;
        this.frmTimeStamp = time;
    }

    public static int getSamplerate(byte flags) {
        switch (flags >>> 2) {
            case 0:
                return 8000;
            case 1:
                return 11025;
            case 2:
                return 12000;
            case 3:
                return 16000;
            case 4:
                return 22050;
            case 5:
                return 24000;
            case 6:
                return 32000;
            case 7:
                return 44100;
            case 8:
                return 48000;
            default:
                return 8000;
        }
    }

    public boolean isIFrame() {
        return (this.flags & 1) == 1;
    }

    public byte getFlags() {
        return this.flags;
    }

    public byte getCamIndex() {
        return this.camindex;
    }

    public byte getFrmState() {
        return this.frmState;
    }

    public long getFrmNo() {
        return this.frmNo;
    }

    public int getFrmSize() {
        return this.frmSize;
    }

    public byte getOnlineNum() {
        return this.onlineNum;
    }

    public short getCodecId() {
        return this.codec_id;
    }

    public int getTimeStamp() {
        return this.timestamp;
    }

    public int getVideoWidth() {
        return this.videoWidth;
    }

    public int getVideoHeight() {
        return this.videoHeight;
    }
}
