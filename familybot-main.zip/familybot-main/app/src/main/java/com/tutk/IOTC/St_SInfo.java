package com.tutk.IOTC;

/* loaded from: classes.dex */
public class St_SInfo {
    public byte CorD;
    public int GID;
    public long IOTCVersion;
    public byte Mode;
    public byte NatType;
    public int PID;
    public long RX_count;
    public int RemotePort;
    public long TX_count;
    public int VID;
    public byte isSecure;
    public byte[] UID = new byte[21];
    public byte[] RemoteIP = new byte[17];
}
