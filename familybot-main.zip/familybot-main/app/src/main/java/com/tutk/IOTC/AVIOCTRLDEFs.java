package com.tutk.IOTC;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: classes.dex */
public class AVIOCTRLDEFs {
    public static final int AVIOCTRL_AUTO_PAN_LIMIT = 28;
    public static final int AVIOCTRL_AUTO_PAN_SPEED = 27;
    public static final int AVIOCTRL_AUTO_PAN_START = 29;
    public static final int AVIOCTRL_CLEAR_AUX = 34;
    public static final int AVIOCTRL_ENVIRONMENT_INDOOR_50HZ = 0;
    public static final int AVIOCTRL_ENVIRONMENT_INDOOR_60HZ = 1;
    public static final int AVIOCTRL_ENVIRONMENT_NIGHT = 3;
    public static final int AVIOCTRL_ENVIRONMENT_OUTDOOR = 2;
    public static final int AVIOCTRL_EVENT_ALL = 0;
    public static final int AVIOCTRL_EVENT_EXPT_REBOOT = 16;
    public static final int AVIOCTRL_EVENT_IOALARM = 3;
    public static final int AVIOCTRL_EVENT_IOALARMPASS = 6;
    public static final int AVIOCTRL_EVENT_MOTIONDECT = 1;
    public static final int AVIOCTRL_EVENT_MOTIONPASS = 4;
    public static final int AVIOCTRL_EVENT_SDFAULT = 17;
    public static final int AVIOCTRL_EVENT_VIDEOLOST = 2;
    public static final int AVIOCTRL_EVENT_VIDEORESUME = 5;
    public static final int AVIOCTRL_LENS_APERTURE_CLOSE = 22;
    public static final int AVIOCTRL_LENS_APERTURE_OPEN = 21;
    public static final int AVIOCTRL_LENS_FOCAL_FAR = 26;
    public static final int AVIOCTRL_LENS_FOCAL_NEAR = 25;
    public static final int AVIOCTRL_LENS_ZOOM_IN = 23;
    public static final int AVIOCTRL_LENS_ZOOM_OUT = 24;
    public static final int AVIOCTRL_MOTOR_RESET_POSITION = 35;
    public static final int AVIOCTRL_PATTERN_RUN = 32;
    public static final int AVIOCTRL_PATTERN_START = 30;
    public static final int AVIOCTRL_PATTERN_STOP = 31;
    public static final int AVIOCTRL_PTZ_AUTO = 9;
    public static final int AVIOCTRL_PTZ_CLEAR_POINT = 11;
    public static final int AVIOCTRL_PTZ_DOWN = 2;
    public static final int AVIOCTRL_PTZ_FLIP = 19;
    public static final int AVIOCTRL_PTZ_GOTO_POINT = 12;
    public static final int AVIOCTRL_PTZ_LEFT = 3;
    public static final int AVIOCTRL_PTZ_LEFT_DOWN = 5;
    public static final int AVIOCTRL_PTZ_LEFT_UP = 4;
    public static final int AVIOCTRL_PTZ_MENU_ENTER = 18;
    public static final int AVIOCTRL_PTZ_MENU_EXIT = 17;
    public static final int AVIOCTRL_PTZ_MENU_OPEN = 16;
    public static final int AVIOCTRL_PTZ_MODE_RUN = 15;
    public static final int AVIOCTRL_PTZ_RIGHT = 6;
    public static final int AVIOCTRL_PTZ_RIGHT_DOWN = 8;
    public static final int AVIOCTRL_PTZ_RIGHT_UP = 7;
    public static final int AVIOCTRL_PTZ_SET_MODE_START = 13;
    public static final int AVIOCTRL_PTZ_SET_MODE_STOP = 14;
    public static final int AVIOCTRL_PTZ_SET_POINT = 10;
    public static final int AVIOCTRL_PTZ_START = 20;
    public static final int AVIOCTRL_PTZ_STOP = 0;
    public static final int AVIOCTRL_PTZ_UP = 1;
    public static final int AVIOCTRL_QUALITY_HIGH = 2;
    public static final int AVIOCTRL_QUALITY_LOW = 4;
    public static final int AVIOCTRL_QUALITY_MAX = 1;
    public static final int AVIOCTRL_QUALITY_MIDDLE = 3;
    public static final int AVIOCTRL_QUALITY_MIN = 5;
    public static final int AVIOCTRL_QUALITY_UNKNOWN = 0;
    public static final int AVIOCTRL_RECORD_PLAY_BACKWARD = 5;
    public static final int AVIOCTRL_RECORD_PLAY_END = 7;
    public static final int AVIOCTRL_RECORD_PLAY_FORWARD = 4;
    public static final int AVIOCTRL_RECORD_PLAY_PAUSE = 0;
    public static final int AVIOCTRL_RECORD_PLAY_SEEKTIME = 6;
    public static final int AVIOCTRL_RECORD_PLAY_START = 16;
    public static final int AVIOCTRL_RECORD_PLAY_STEPBACKWARD = 3;
    public static final int AVIOCTRL_RECORD_PLAY_STEPFORWARD = 2;
    public static final int AVIOCTRL_RECORD_PLAY_STOP = 1;
    public static final int AVIOCTRL_SET_AUX = 33;
    public static final int AVIOCTRL_VIDEOMODE_FLIP = 1;
    public static final int AVIOCTRL_VIDEOMODE_FLIP_MIRROR = 3;
    public static final int AVIOCTRL_VIDEOMODE_MIRROR = 2;
    public static final int AVIOCTRL_VIDEOMODE_NORMAL = 0;
    public static final int AVIOTC_RECORDTYPE_ALAM = 2;
    public static final int AVIOTC_RECORDTYPE_FULLTIME = 1;
    public static final int AVIOTC_RECORDTYPE_MANUAL = 3;
    public static final int AVIOTC_RECORDTYPE_OFF = 0;
    public static final int AVIOTC_WIFIAPENC_INVALID = 0;
    public static final int AVIOTC_WIFIAPENC_NONE = 1;
    public static final int AVIOTC_WIFIAPENC_WEP = 2;
    public static final int AVIOTC_WIFIAPENC_WPA2_AES = 6;
    public static final int AVIOTC_WIFIAPENC_WPA2_TKIP = 5;
    public static final int AVIOTC_WIFIAPENC_WPA_AES = 4;
    public static final int AVIOTC_WIFIAPENC_WPA_TKIP = 3;
    public static final int AVIOTC_WIFIAPMODE_ADHOC = 0;
    public static final int AVIOTC_WIFIAPMODE_MANAGED = 1;
    public static final int IOTYPE_USER_IPCAM_AUDIOSTART = 768;
    public static final int IOTYPE_USER_IPCAM_AUDIOSTOP = 769;
    public static final int IOTYPE_USER_IPCAM_CURRENT_FLOWINFO = 914;
    public static final int IOTYPE_USER_IPCAM_DEVINFO_REQ = 816;
    public static final int IOTYPE_USER_IPCAM_DEVINFO_RESP = 817;
    public static final int IOTYPE_USER_IPCAM_EVENT_REPORT = 8191;
    public static final int IOTYPE_USER_IPCAM_FORMATEXTSTORAGE_REQ = 896;
    public static final int IOTYPE_USER_IPCAM_FORMATEXTSTORAGE_RESP = 897;
    public static final int IOTYPE_USER_IPCAM_GETAUDIOOUTFORMAT_REQ = 810;
    public static final int IOTYPE_USER_IPCAM_GETAUDIOOUTFORMAT_RESP = 811;
    public static final int IOTYPE_USER_IPCAM_GETMOTIONDETECT_REQ = 806;
    public static final int IOTYPE_USER_IPCAM_GETMOTIONDETECT_RESP = 807;
    public static final int IOTYPE_USER_IPCAM_GETRCD_DURATION_REQ = 790;
    public static final int IOTYPE_USER_IPCAM_GETRCD_DURATION_RESP = 791;
    public static final int IOTYPE_USER_IPCAM_GETRECORD_REQ = 786;
    public static final int IOTYPE_USER_IPCAM_GETRECORD_RESP = 787;
    public static final int IOTYPE_USER_IPCAM_GETSTREAMCTRL_REQ = 802;
    public static final int IOTYPE_USER_IPCAM_GETSTREAMCTRL_RESP = 803;
    public static final int IOTYPE_USER_IPCAM_GETSUPPORTSTREAM_REQ = 808;
    public static final int IOTYPE_USER_IPCAM_GETSUPPORTSTREAM_RESP = 809;
    public static final int IOTYPE_USER_IPCAM_GETWIFI_REQ = 836;
    public static final int IOTYPE_USER_IPCAM_GETWIFI_RESP = 837;
    public static final int IOTYPE_USER_IPCAM_GET_ENVIRONMENT_REQ = 866;
    public static final int IOTYPE_USER_IPCAM_GET_ENVIRONMENT_RESP = 867;
    public static final int IOTYPE_USER_IPCAM_GET_EVENTCONFIG_REQ = 1024;
    public static final int IOTYPE_USER_IPCAM_GET_EVENTCONFIG_RESP = 1025;
    public static final int IOTYPE_USER_IPCAM_GET_FLOWINFO_REQ = 912;
    public static final int IOTYPE_USER_IPCAM_GET_FLOWINFO_RESP = 913;
    public static final int IOTYPE_USER_IPCAM_GET_VIDEOMODE_REQ = 882;
    public static final int IOTYPE_USER_IPCAM_GET_VIDEOMODE_RESP = 883;
    public static final int IOTYPE_USER_IPCAM_LISTEVENT_REQ = 792;
    public static final int IOTYPE_USER_IPCAM_LISTEVENT_RESP = 793;
    public static final int IOTYPE_USER_IPCAM_LISTWIFIAP_REQ = 832;
    public static final int IOTYPE_USER_IPCAM_LISTWIFIAP_RESP = 833;
    public static final int IOTYPE_USER_IPCAM_PTZ_COMMAND = 4097;
    public static final int IOTYPE_USER_IPCAM_RECEIVE_FIRST_IFRAME = 4098;
    public static final int IOTYPE_USER_IPCAM_RECORD_PLAYCONTROL = 794;
    public static final int IOTYPE_USER_IPCAM_RECORD_PLAYCONTROL_RESP = 795;
    public static final int IOTYPE_USER_IPCAM_SETMOTIONDETECT_REQ = 804;
    public static final int IOTYPE_USER_IPCAM_SETMOTIONDETECT_RESP = 805;
    public static final int IOTYPE_USER_IPCAM_SETPASSWORD_REQ = 818;
    public static final int IOTYPE_USER_IPCAM_SETPASSWORD_RESP = 819;
    public static final int IOTYPE_USER_IPCAM_SETRCD_DURATION_REQ = 788;
    public static final int IOTYPE_USER_IPCAM_SETRCD_DURATION_RESP = 789;
    public static final int IOTYPE_USER_IPCAM_SETRECORD_REQ = 784;
    public static final int IOTYPE_USER_IPCAM_SETRECORD_RESP = 785;
    public static final int IOTYPE_USER_IPCAM_SETSTREAMCTRL_REQ = 800;
    public static final int IOTYPE_USER_IPCAM_SETSTREAMCTRL_RESP = 801;
    public static final int IOTYPE_USER_IPCAM_SETWIFI_REQ = 834;
    public static final int IOTYPE_USER_IPCAM_SETWIFI_RESP = 835;
    public static final int IOTYPE_USER_IPCAM_SET_ENVIRONMENT_REQ = 864;
    public static final int IOTYPE_USER_IPCAM_SET_ENVIRONMENT_RESP = 865;
    public static final int IOTYPE_USER_IPCAM_SET_EVENTCONFIG_REQ = 1026;
    public static final int IOTYPE_USER_IPCAM_SET_EVENTCONFIG_RESP = 1027;
    public static final int IOTYPE_USER_IPCAM_SET_VIDEOMODE_REQ = 880;
    public static final int IOTYPE_USER_IPCAM_SET_VIDEOMODE_RESP = 881;
    public static final int IOTYPE_USER_IPCAM_SPEAKERSTART = 848;
    public static final int IOTYPE_USER_IPCAM_SPEAKERSTOP = 849;
    public static final int IOTYPE_USER_IPCAM_START = 511;
    public static final int IOTYPE_USER_IPCAM_STOP = 767;

    /* loaded from: classes.dex */
    public static class SFrameInfo {
        byte cam_index;
        short codec_id;
        byte flags;
        byte onlineNum;
        byte[] reserved = new byte[3];
        int reserved2;
        int timestamp;

        public static byte[] parseContent(short codec_id, byte flags, byte cam_index, byte online_num, int timestamp) {
            byte[] result = new byte[16];
            byte[] codec = Packet.shortToByteArray_Little(codec_id);
            System.arraycopy(codec, 0, result, 0, 2);
            result[2] = flags;
            result[3] = cam_index;
            result[4] = online_num;
            byte[] time = Packet.intToByteArray_Little(timestamp);
            System.arraycopy(time, 0, result, 12, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetFlowInfoResp {
        public int channel;
        public int collect_interval;

        public static byte[] parseContent(int paramInt1, int paramInt2) {
            byte[] arrayOfByte = new byte[8];
            System.arraycopy(Packet.intToByteArray_Little(paramInt1), 0, arrayOfByte, 0, 4);
            System.arraycopy(Packet.intToByteArray_Little(paramInt2), 0, arrayOfByte, 4, 4);
            return arrayOfByte;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlCurrentFlowInfo {
        public int channel;
        public int elapse_time_ms;
        public int lost_incomplete_frame_count;
        public int total_actual_frame_size;
        public int total_expected_frame_size;
        public int total_frame_count;

        public static byte[] parseContent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
            byte[] arrayOfByte = new byte[32];
            System.arraycopy(Packet.intToByteArray_Little(paramInt1), 0, arrayOfByte, 0, 4);
            System.arraycopy(Packet.intToByteArray_Little(paramInt2), 0, arrayOfByte, 4, 4);
            System.arraycopy(Packet.intToByteArray_Little(paramInt3), 0, arrayOfByte, 8, 4);
            System.arraycopy(Packet.intToByteArray_Little(paramInt4), 0, arrayOfByte, 12, 4);
            System.arraycopy(Packet.intToByteArray_Little(paramInt5), 0, arrayOfByte, 16, 4);
            System.arraycopy(Packet.intToByteArray_Little(paramInt6), 0, arrayOfByte, 20, 4);
            return arrayOfByte;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlAVStream {
        int channel = 0;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }

        public static byte[] parseContent(int channel, int size) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            byte[] bsize = Packet.intToByteArray_Little(size);
            System.arraycopy(bsize, 0, result, 4, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlPtzCmd {
        byte aux;
        byte channel;
        byte control;
        byte limit;
        byte point;
        byte[] reserved = new byte[2];
        byte speed;

        public static byte[] parseContent(byte control, byte speed, byte point, byte limit, byte aux, byte channel) {
            byte[] result = {control, speed, point, limit, aux, channel};
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetStreamCtrlReq {
        int channel;
        byte quality;
        byte[] reserved = new byte[3];

        public static byte[] parseContent(int channel, byte quality) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            result[4] = quality;
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetStreamCtrlResp {
        int channel;
        byte quality;
        byte[] reserved = new byte[3];

        public SMsgAVIoctrlGetStreamCtrlResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetStreamCtrlResp {
        byte[] reserved = new byte[4];
        int result;

        public SMsgAVIoctrlSetStreamCtrlResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetStreamCtrlReq {
        int channel;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetMotionDetectReq {
        int channel;
        int sensitivity;

        public static byte[] parseContent(int channel, int sensitivity) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            byte[] sen = Packet.intToByteArray_Little(sensitivity);
            System.arraycopy(ch, 0, result, 0, 4);
            System.arraycopy(sen, 0, result, 4, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetMotionDetectResp {
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetMotionDetectResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetMotionDetectReq {
        int channel;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlDeviceInfoReq {
        static byte[] reserved = new byte[4];

        public static byte[] parseContent() {
            return reserved;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlDeviceInfoResp {
        int channel;
        int free;
        int total;
        int version;
        byte[] model = new byte[16];
        byte[] vendor = new byte[16];
        byte[] reserved = new byte[8];

        public SMsgAVIoctrlDeviceInfoResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetPasswdReq {
        byte[] oldPasswd = new byte[32];
        byte[] newPasswd = new byte[32];

        public static byte[] parseContent(String oldPwd, String newPwd) {
            byte[] oldpwd = oldPwd.getBytes();
            byte[] newpwd = newPwd.getBytes();
            byte[] result = new byte[64];
            System.arraycopy(oldpwd, 0, result, 0, oldpwd.length);
            System.arraycopy(newpwd, 0, result, 32, newpwd.length);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetPasswdResp {
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetPasswdResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlListWifiApReq {
        static byte[] reserved = new byte[4];

        public static byte[] parseContent() {
            return reserved;
        }
    }

    /* loaded from: classes.dex */
    public static class SWifiAp {
        public byte enctype;
        public byte mode;
        public byte signal;
        public byte[] ssid;
        public byte status;

        public static int getTotalSize() {
            return 36;
        }

        public SWifiAp(byte[] data) {
            this.ssid = new byte[32];
            System.arraycopy(data, 1, this.ssid, 0, data.length);
            this.mode = data[32];
            this.enctype = data[33];
            this.signal = data[34];
            this.status = data[35];
        }

        public SWifiAp(byte[] bytsSSID, byte bytMode, byte bytEnctype, byte bytSignal, byte bytStatus) {
            this.ssid = new byte[32];
            System.arraycopy(bytsSSID, 0, this.ssid, 0, bytsSSID.length);
            this.mode = bytMode;
            this.enctype = bytEnctype;
            this.signal = bytSignal;
            this.status = bytStatus;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetWifiReq {
        byte enctype;
        byte mode;
        byte[] ssid = new byte[32];
        byte[] password = new byte[32];
        byte[] reserved = new byte[10];

        public static byte[] parseContent(byte[] ssid, byte[] password, byte mode, byte enctype) {
            byte[] result = new byte[76];
            System.arraycopy(ssid, 0, result, 0, ssid.length);
            System.arraycopy(password, 0, result, 32, password.length);
            result[64] = mode;
            result[65] = enctype;
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetWifiResp {
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetWifiResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetWifiReq {
        static byte[] reserved = new byte[4];

        public static byte[] parseContent() {
            return reserved;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetWifiResp {
        byte enctype;
        byte mode;
        byte signal;
        byte status;
        byte[] ssid = new byte[32];
        byte[] password = new byte[32];

        public SMsgAVIoctrlGetWifiResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetRecordReq {
        int channel;
        int recordType;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel, int recordType) {
            byte[] result = new byte[12];
            byte[] ch = Packet.intToByteArray_Little(channel);
            byte[] type = Packet.intToByteArray_Little(recordType);
            System.arraycopy(ch, 0, result, 0, 4);
            System.arraycopy(type, 0, result, 4, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetRecordResp {
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetRecordResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetRecordReq {
        int channel;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetRcdDurationResp {
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetRcdDurationResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetRcdDurationReq {
        int channel;
        byte[] reserved = new byte[4];

        public SMsgAVIoctrlGetRcdDurationReq() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class STimeDay {
        public byte day;
        public byte hour;
        private byte[] mBuf = new byte[8];
        public byte minute;
        public byte month;
        public byte second;
        public byte wday;
        public short year;

        public STimeDay(byte[] data) {
            System.arraycopy(data, 0, this.mBuf, 0, 8);
            this.year = Packet.byteArrayToShort_Little(data, 0);
            this.month = data[2];
            this.day = data[3];
            this.wday = data[4];
            this.hour = data[5];
            this.minute = data[6];
            this.second = data[7];
        }

        public long getTimeInMillis() {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("gmt"));
            cal.set(this.year, this.month, this.day, this.hour, this.minute, this.second);
            return cal.getTimeInMillis();
        }

        public String getLocalTime() {
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("gmt"));
            calendar.setTimeInMillis(getTimeInMillis());
            calendar.add(2, -1);
            SimpleDateFormat dateFormat = new SimpleDateFormat();
            dateFormat.setTimeZone(TimeZone.getDefault());
            return dateFormat.format(calendar.getTime());
        }

        public byte[] toByteArray() {
            return this.mBuf;
        }

        public static byte[] parseContent(int year, int month, int day, int wday, int hour, int minute, int second) {
            byte[] y = Packet.shortToByteArray_Little((short) year);

            byte[] result = {0, 0, (byte) month, (byte) day, (byte) wday, (byte) hour, (byte) minute, (byte) second};
            System.arraycopy(y, 0, result, 0, 2);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlListEventReq {
        int channel;
        byte event;
        byte status;
        byte[] startutctime = new byte[8];
        byte[] endutctime = new byte[8];
        byte[] reversed = new byte[2];

        public static byte[] parseConent(int channel, long startutctime, long endutctime, byte event, byte status) {
            Calendar startCal = Calendar.getInstance(TimeZone.getTimeZone("gmt"));
            Calendar stopCal = Calendar.getInstance(TimeZone.getTimeZone("gmt"));
            startCal.setTimeInMillis(startutctime);
            stopCal.setTimeInMillis(endutctime);
            System.out.println("search from " + startCal.get(1) + "/" + startCal.get(2) + "/" + startCal.get(5) + " " + startCal.get(11) + ":" + startCal.get(12) + ":" + startCal.get(13));
            System.out.println("       to   " + stopCal.get(1) + "/" + stopCal.get(2) + "/" + stopCal.get(5) + " " + stopCal.get(11) + ":" + stopCal.get(12) + ":" + stopCal.get(13));
            byte[] result = new byte[24];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            byte[] start = STimeDay.parseContent(startCal.get(1), startCal.get(2) + 1, startCal.get(5), startCal.get(7), startCal.get(11), startCal.get(12), 0);
            System.arraycopy(start, 0, result, 4, 8);
            byte[] stop = STimeDay.parseContent(stopCal.get(1), stopCal.get(2) + 1, stopCal.get(5), stopCal.get(7), stopCal.get(11), stopCal.get(12), 0);
            System.arraycopy(stop, 0, result, 12, 8);
            result[20] = event;
            result[21] = status;
            return result;
        }
    }

    /* loaded from: classes.dex */
    public static class SAvEvent {
        byte event;
        byte status;
        byte[] utctime = new byte[8];
        byte[] reserved = new byte[2];

        public static int getTotalSize() {
            return 12;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlPlayRecord {
        int Param;
        int channel;
        int command;
        byte[] stTimeDay = new byte[8];
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel, int command, int param, long time) {
            byte[] result = new byte[24];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            byte[] cmd = Packet.intToByteArray_Little(command);
            System.arraycopy(cmd, 0, result, 4, 4);
            byte[] p = Packet.intToByteArray_Little(param);
            System.arraycopy(p, 0, result, 8, 4);
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("gmt"));
            cal.setTimeInMillis(time);
            cal.add(5, -1);
            cal.add(5, 1);
            byte[] timedata = STimeDay.parseContent(cal.get(1), cal.get(2), cal.get(5), cal.get(7), cal.get(11), cal.get(12), cal.get(13));
            System.arraycopy(timedata, 0, result, 12, 8);
            return result;
        }

        public static byte[] parseContent(int channel, int command, int param, byte[] time) {
            byte[] result = new byte[24];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            byte[] cmd = Packet.intToByteArray_Little(command);
            System.arraycopy(cmd, 0, result, 4, 4);
            byte[] p = Packet.intToByteArray_Little(param);
            System.arraycopy(p, 0, result, 8, 4);
            System.arraycopy(time, 0, result, 12, 8);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlPlayRecordResp {
        int channel;
        byte[] reserved = new byte[4];
        int result;

        public SMsgAVIoctrlPlayRecordResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlEvent {
        int channel;
        int event;
        byte[] reserved = new byte[4];
        STimeDay stTime;

        public SMsgAVIoctrlEvent() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetVideoModeReq {
        int channel;
        byte mode;
        byte[] reserved = new byte[3];

        public static byte[] parseContent(int channel, byte mode) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            result[4] = mode;
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetVideoModeResp {
        int channel;
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetVideoModeResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetVideoModeReq {
        int channel;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetVideoModeResp {
        int channel;
        byte mode;
        byte[] reserved = new byte[3];

        public SMsgAVIoctrlGetVideoModeResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlSetEnvironmentReq {
        int channel;
        byte mode;
        byte[] reserved = new byte[3];

        public static byte[] parseContent(int channel, byte mode) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            result[4] = mode;
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetEnvironmentResp {
        int channel;
        byte[] reserved = new byte[3];
        byte result;

        public SMsgAVIoctrlSetEnvironmentResp() {
            ////AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetEnvironmentReq {
        int channel;
        byte[] reserved = new byte[4];

        public static byte[] parseContent(int channel) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(channel);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetEnvironmentResp {
        int channel;
        byte mode;
        byte[] reserved = new byte[3];

        public SMsgAVIoctrlGetEnvironmentResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlFormatExtStorageReq {
        byte[] reserved = new byte[4];
        int storage;

        public static byte[] parseContent(int storage) {
            byte[] result = new byte[8];
            byte[] ch = Packet.intToByteArray_Little(storage);
            System.arraycopy(ch, 0, result, 0, 4);
            return result;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlFormatExtStorageResp {
        byte[] reserved = new byte[3];
        byte result;
        int storage;

        public SMsgAVIoctrlFormatExtStorageResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public static class SStreamDef {
        public int channel;
        public int index;

        public SStreamDef(byte[] data) {
            this.index = Packet.byteArrayToShort_Little(data, 0);
            this.channel = Packet.byteArrayToShort_Little(data, 2);
        }

        public String toString() {
            return "CH" + String.valueOf(this.index + 1);
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetSupportStreamReq {
        public static byte[] parseContent() {
            return new byte[4];
        }

        public static int getContentSize() {
            return 4;
        }
    }

    /* loaded from: classes.dex */
    public static class SMsgAVIoctrlGetAudioOutFormatReq {
        public static byte[] parseContent() {
            return new byte[8];
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlEventConfig {
        long channel;
        byte ftp;
        byte localIO;
        byte mail;
        byte p2pPushMsg;

        public SMsgAVIoctrlEventConfig() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetAudioOutFormatResp {
        public int channel;
        public int format;

        public SMsgAVIoctrlGetAudioOutFormatResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetMotionDetectResp {
        int channel;
        int sensitivity;

        public SMsgAVIoctrlGetMotionDetectResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetRcdDurationResp {
        int channel;
        int durasecond;
        int presecond;

        public SMsgAVIoctrlGetRcdDurationResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetRecordResp {
        int channel;
        int recordType;

        public SMsgAVIoctrlGetRecordResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlGetSupportStreamResp {
        public SStreamDef[] mStreamDef;
        public long number;

        public SMsgAVIoctrlGetSupportStreamResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlListEventResp {
        int channel;
        byte count;
        byte endflag;
        byte index;
        byte reserved;
        SAvEvent stEvent;
        int total;

        public SMsgAVIoctrlListEventResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlListWifiApResp {
        int number;
        SWifiAp stWifiAp;

        public SMsgAVIoctrlListWifiApResp() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }

    /* loaded from: classes.dex */
    public class SMsgAVIoctrlSetRcdDurationReq {
        int channel;
        int durasecond;
        int presecond;

        public SMsgAVIoctrlSetRcdDurationReq() {
            //AVIOCTRLDEFs.this = this$0;
        }
    }
}
