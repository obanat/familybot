package com.decoder.util;

/* loaded from: classes.dex */
public class DecMpeg4 {
    public static native int Decode(byte[] bArr, int i, byte[] bArr2, int[] iArr, int[] iArr2, int[] iArr3);

    public static native int InitDecoder(int i, int i2);

    public static native int UninitDecoder();

    static {
        try {
            System.loadLibrary("FFmpeg");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(FFmpeg)," + localUnsatisfiedLinkError.getMessage());
        }
    }
}
