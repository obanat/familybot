package com.decoder.util;

/* loaded from: classes.dex */
public class DecSpeex {
    public static native int Decode(byte[] bArr, int i, short[] sArr);

    public static native int InitDecoder(int i);

    public static native int UninitDecoder();

    static {
        try {
            System.loadLibrary("SpeexAndroid");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(SpeexAndroid)," + localUnsatisfiedLinkError.getMessage());
        }
    }
}
