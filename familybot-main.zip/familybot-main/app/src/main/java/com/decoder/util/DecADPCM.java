package com.decoder.util;

/* loaded from: classes.dex */
public class DecADPCM {
    public static native int Decode(byte[] bArr, int i, byte[] bArr2);

    public static native int ResetDecoder();

    static {
        try {
            System.loadLibrary("ADPCMAndroid");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(ADPCMAndroid)," + localUnsatisfiedLinkError.getMessage());
        }
    }
}
