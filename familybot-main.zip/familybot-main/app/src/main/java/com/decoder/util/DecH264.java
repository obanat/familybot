package com.decoder.util;

/* loaded from: classes.dex */
public class DecH264 {
    public static native int DecoderNal(byte[] bArr, int i, int[] iArr, byte[] bArr2, boolean z);

    public static native int DecoderNalV2(int i, byte[] bArr, int i2, int[] iArr, byte[] bArr2, boolean z);

    public static native int DeinitDecoderV2(int i);

    public static native int InitDecoder();

    public static native int InitDecoderV2(int[] iArr);

    public static native void SetMaxAVCodecCtxNum(int i);

    public static native int UninitDecoder();

    static {
        try {
            System.loadLibrary("H264Android");
        } catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {
            System.out.println("loadLibrary(H264Android)," + localUnsatisfiedLinkError.getMessage());
        }
    }
}
