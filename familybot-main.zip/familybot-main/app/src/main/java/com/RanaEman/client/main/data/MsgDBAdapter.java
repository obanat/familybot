package com.RanaEman.client.main.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* loaded from: classes.dex */
public class MsgDBAdapter {
    public static final String CONTENT = "content";
    private static final String DATABASE_CREATE = "create table tbl_msg (msg_id INTEGER PRIMARY KEY, device_mac TEXT, status INTEGER, flag INTEGER, content TEXT, time TEXT );";
    private static final String DATABASE_NAME = "iGroupSrv_msg.db";
    private static final String DATABASE_TABLE = "tbl_msg";
    private static final int DATABASE_VERSION = 2;
    public static final String DEVICE_MAC = "device_mac";
    public static final String FLAG = "flag";
    public static final String MSG_ID = "msg_id";
    public static final String STATUS = "status";
    public static final String TIME = "time";
    private DatabaseHelper DBHelper;
    private final Context context;
    private SQLiteDatabase db;

    public MsgDBAdapter(Context ctx) {
        this.context = ctx;
        this.DBHelper = new DatabaseHelper(this.context);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context, MsgDBAdapter.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 2);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(MsgDBAdapter.DATABASE_CREATE);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS tbl_msg");
            onCreate(db);
        }
    }

    public SQLiteDatabase open() throws SQLException {
        this.db = this.DBHelper.getWritableDatabase();
        return this.db;
    }

    public void close() {
        this.DBHelper.close();
    }

    public long insert(String mac, int status, int flag, String content, String time) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(DEVICE_MAC, mac);
        initialValues.put("status", Integer.valueOf(status));
        initialValues.put(FLAG, Integer.valueOf(flag));
        initialValues.put("content", content);
        initialValues.put("time", time);
        return this.db.insert(DATABASE_TABLE, null, initialValues);
    }

    public long insert(MsgItem item) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(DEVICE_MAC, item.deviceMac);
        initialValues.put("status", Integer.valueOf(item.status));
        initialValues.put(FLAG, Integer.valueOf(item.flag));
        initialValues.put("content", item.content);
        initialValues.put("time", item.time);
        return this.db.insert(DATABASE_TABLE, null, initialValues);
    }

    public boolean delete(int msgId) {
        return this.db.delete(DATABASE_TABLE, new StringBuilder().append("msg_id=").append(msgId).toString(), null) > 0;
    }

    public boolean deleteAll() {
        return this.db.delete(DATABASE_TABLE, null, null) > 0;
    }

    public boolean update(int msgId, String mac, int status, int flag, String content, String time) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(DEVICE_MAC, mac);
        initialValues.put("status", Integer.valueOf(status));
        initialValues.put(FLAG, Integer.valueOf(flag));
        initialValues.put("content", content);
        initialValues.put("time", time);
        return this.db.update(DATABASE_TABLE, initialValues, new StringBuilder().append("msg_id=").append(msgId).toString(), null) > 0;
    }

    public boolean update(MsgItem item) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(DEVICE_MAC, item.deviceMac);
        initialValues.put("status", Integer.valueOf(item.status));
        initialValues.put(FLAG, Integer.valueOf(item.flag));
        initialValues.put("content", item.content);
        initialValues.put("time", item.time);
        return this.db.update(DATABASE_TABLE, initialValues, new StringBuilder().append("msg_id=").append(item.msg_id).toString(), null) > 0;
    }

    public Cursor getAll() {
        Cursor cur = this.db.query(DATABASE_TABLE, null, null, null, null, null, null);
        return cur;
    }

    public Cursor get(long msgId) throws SQLException {
        Cursor cur = this.db.query(true, DATABASE_TABLE, null, "msg_id=" + msgId, null, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }

    public Cursor getMsgByDeviceId(int device_id) throws SQLException {
        String[] selectionArgs = {String.valueOf(device_id)};
        Cursor cur = this.db.query(true, DATABASE_TABLE, null, "DEVICE_ID=?", selectionArgs, null, null, "MSG_ID desc", null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }
}
