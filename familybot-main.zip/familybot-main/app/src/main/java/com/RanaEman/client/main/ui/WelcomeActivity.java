package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.RanaEman.client.main.MainHelper;
import com.RanaEman.client.main.SigCameraService;
import com.RanaEman.client.main.UpdateManager;
import com.RanaEman.client.main.data.DataCenter;
import com.RanaEman.client.main.lockpwd.LockSetupActivity;
import com.Robot.client.main.R;
import com.tutk.IOTC.AVAPIs;
import com.tutk.IOTC.Camera;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes.dex */
public class WelcomeActivity extends Activity {
    public static final String DEFAULT_UID = "DEFAULT_UID";
    public static final String DEFAULT_UID_STR = "DEFAULT_UID_STR";
    public static final int DOWNERR = 4;
    public static final int INSTALLAPK = 3;
    public static final String LOCK = "lock";
    public static final String LOCK_KEY = "lock_key";
    public static final int SHOWUPDATEDIALOG = 5;
    public static final int TIMER_PROGRESS_ADD = 2;
    public static final int TIMER_SHOW_LOGIN = 1;
    private Timer mainTimer;
    TextView tvVerTextView;
    public static String patternString = null;
    public static int myDeviceAPILevel = 0;
    public static int width = 0;
    public static int height = 0;
    public static float density = 0.0f;
    public static int densityDpi = 0;
    public static int totalWdps = 0;
    public static int totalHdps = 0;
    static int iMyVersionCode = 0;
    public static Intent sigserviceintent = null;
    UpdateManager upm = null;
    private BroadcastReceiver bCRecvUpdateInfo = new BroadcastReceiver() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.3
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context arg0, Intent arg1) {
            String sActionString = arg1.getAction();
            if (sActionString.equals("ACTION_USER_CACEL_UPDATE")) {
                WelcomeActivity.this.startMainTimer(AVAPIs.TIME_SPAN_LOSED);
            } else if (sActionString.equals("ACTION_INSTALL_APK")) {
                Message msg = WelcomeActivity.this.handler.obtainMessage();
                Bundle data = new Bundle();
                data.putString("APKNAME", arg1.getStringExtra("APKNAME"));
                msg.what = 3;
                msg.setData(data);
                WelcomeActivity.this.handler.sendMessage(msg);
            } else if (sActionString.equals("ACTION_DWON_ERR")) {
                WelcomeActivity.this.handler.sendEmptyMessage(4);
            }
        }
    };
    Handler handler = new Handler() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.5
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    WelcomeActivity.this.ShowNext();
                    break;
                case 3:
                    Bundle bundle = msg.getData();
                    WelcomeActivity.this.installApk(bundle.getString("APKNAME"));
                    break;
                case 4:
                    WelcomeActivity.this.ShowMyDialog(WelcomeActivity.this.getString(R.string.txtdwonerr), WelcomeActivity.this.getString(R.string.txtdwonerrmsg));
                    break;
                case 5:
                    WelcomeActivity.this.ShowUpdate();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        MainHelper.context = getApplicationContext();
        myDeviceAPILevel = Build.VERSION.SDK_INT;
        DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);
        width = metric.widthPixels;
        height = metric.heightPixels;
        density = metric.density;
        densityDpi = metric.densityDpi;
        totalWdps = (metric.widthPixels * 160) / densityDpi;
        totalHdps = (metric.heightPixels * 160) / densityDpi;
        this.tvVerTextView = (TextView) findViewById(R.id.textVer);
        this.tvVerTextView.setText(getVersion(this));
        if (!isWifi(this)) {
            this.upm = new UpdateManager(this, iMyVersionCode);
            new Thread(new Runnable() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.1
                @Override // java.lang.Runnable
                public void run() {
                    if (WelcomeActivity.this.upm.checkUpdateInfo()) {
                        WelcomeActivity.this.handler.sendEmptyMessage(5);
                    } else {
                        WelcomeActivity.this.startMainTimer(AVAPIs.TIME_SPAN_LOSED);
                    }
                }
            }).start();
        } else {
            startMainTimer(Camera.RDT_WAIT_TIMEMS);
        }
        String uid = GetDefaultUID();
        String sDBUID = DataCenter.GetAllLocalDVRFromDB(uid);
        if (sDBUID != null) {
            Log.e("Welcom", "sDBUID:" + sDBUID);
        } else {
            Log.e("Welcom", "sDBUID==null");
        }
        SigCameraService.sDefaultUID = sDBUID;
        sigserviceintent = new Intent(this, SigCameraService.class);
        startService(sigserviceintent);
        Log.e("Welcom", "startService(sigserviceintent) end.");
    }

    public void startMainTimer(int iTimeDelay) {
        this.mainTimer = new Timer(true);
        this.mainTimer.schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                Message message = WelcomeActivity.this.handler.obtainMessage();
                message.what = 1;
                WelcomeActivity.this.handler.sendMessage(message);
            }
        }, iTimeDelay);
    }

    public static String getVersion(Context cts) {
        try {
            PackageManager manager = cts.getPackageManager();
            PackageInfo info = manager.getPackageInfo(cts.getPackageName(), 0);
            String version = info.versionName;
            iMyVersionCode = info.versionCode;
            return "V" + version;
        } catch (Exception e) {
            e.printStackTrace();
            return "V1.0";
        }
    }

    @Override // android.app.Activity
    protected void onStart() {
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction("ACTION_USER_CACEL_UPDATE");
        myIntentFilter.addAction("ACTION_INSTALL_APK");
        myIntentFilter.addAction("ACTION_DWON_ERR");
        registerReceiver(this.bCRecvUpdateInfo, myIntentFilter);
        super.onStart();
    }

    @Override // android.app.Activity
    protected void onStop() {
        unregisterReceiver(this.bCRecvUpdateInfo);
        super.onStop();
    }

    public static boolean isAP(Context context) {
        String sss;
        WifiManager wifiManager = (WifiManager) context.getSystemService("wifi");
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        if (wifiInfo == null || (sss = wifiInfo.getSSID()) == null || sss.isEmpty()) {
            return false;
        }
        return sss.equalsIgnoreCase("Family Robot") || sss.equalsIgnoreCase("Bayper") || sss.equalsIgnoreCase("Robotset") || sss.equalsIgnoreCase("Robot");
    }

    public static boolean isWifi(Context context) {
        String sss;
        WifiManager wifiManager = (WifiManager) context.getSystemService("wifi");
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        return (wifiInfo == null || (sss = wifiInfo.getSSID()) == null || sss.isEmpty() || sss.equalsIgnoreCase("Family Robot") || sss.equalsIgnoreCase("Bayper") || sss.equalsIgnoreCase("Robot") || sss.equalsIgnoreCase("Robotset")) ? false : true;
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0) {
            if (resultCode == -1) {
                ShowNext();
            } else {
                finish();
            }
        } else if (requestCode == 2) {
            Log.e("WELCOME", "R:" + resultCode);
            if (resultCode == 0) {
                startMainTimer(AVAPIs.TIME_SPAN_LOSED);
            }
        } else if (requestCode == 3) {
            if (resultCode == -1) {
                ShowEnd();
            } else {
                if (sigserviceintent != null) {
                    stopService(sigserviceintent);
                    sigserviceintent = null;
                    Log.e("WELCOME", "stopService");
                }
                finish();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public String GetDefaultUID() {
        SharedPreferences preferences = getSharedPreferences(DEFAULT_UID, 0);
        return preferences.getString(DEFAULT_UID_STR, null);
    }

    public void ShowEnd() {
        Intent intent;
        if (SigCameraService.sDefaultUID != null) {
            intent = new Intent(this, EmanVideoActivity.class);
            intent.putExtra("fromWhat", 1);
        } else {
            intent = new Intent(this, NewMainActivity.class);
            intent.putExtra("FromWhat", 0);
        }
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void ShowNext() {
        SharedPreferences preferences = getSharedPreferences(LOCK, 0);
        patternString = preferences.getString(LOCK_KEY, null);
        if (patternString != null) {
            if (myDeviceAPILevel < 14) {
                ShowEnd();
                return;
            }
            Intent intent = new Intent(this, LockSetupActivity.class);
            if (patternString == null) {
                intent.putExtra("MODE", "setup");
            } else {
                intent.putExtra("MODE", "verity");
                intent.putExtra("PWD", patternString);
            }
            startActivityForResult(intent, 3);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            return;
        }
        ShowEnd();
    }

    public void startMainTimer() {
        this.mainTimer = new Timer(true);
        this.mainTimer.schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.4
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                Message message = WelcomeActivity.this.handler.obtainMessage();
                message.what = 1;
                WelcomeActivity.this.handler.sendMessage(message);
            }
        }, 2000L);
    }

    public void installApk(String saveFileName) {
        if (sigserviceintent != null) {
            stopService(sigserviceintent);
            sigserviceintent = null;
            Log.e("WELCOME", "stopService");
        }
        File apkfile = new File(saveFileName);
        if (apkfile.exists()) {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setDataAndType(Uri.parse("file://" + apkfile.toString()), "application/vnd.android.package-archive");
            i.setFlags(268435456);
            Process.killProcess(Process.myPid());
            startActivity(i);
        }
    }

    void ShowMyDialog(String title, String Msg) {
        final Dialog inputPwdDialog = new Dialog(this, R.style.Tips);
        inputPwdDialog.setContentView(R.layout.myprogress_dialog);
        TextView txtTitleTextView = (TextView) inputPwdDialog.findViewById(R.id.txtDialogTitle);
        txtTitleTextView.setText(title);
        TextView txtMyProgerssMsg = (TextView) inputPwdDialog.findViewById(R.id.txtMessage);
        txtMyProgerssMsg.setText(Msg);
        RelativeLayout pbdialogBar = (RelativeLayout) inputPwdDialog.findViewById(R.id.rlDialogPb);
        pbdialogBar.setVisibility(8);
        Button btnokk = (Button) inputPwdDialog.findViewById(R.id.btnSure);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                inputPwdDialog.dismiss();
                WelcomeActivity.this.startMainTimer(AVAPIs.TIME_SPAN_LOSED);
            }
        });
        inputPwdDialog.setCancelable(true);
        inputPwdDialog.show();
    }

    void ShowUpdate() {
        final Dialog dialog = new Dialog(this, R.style.Tips);
        dialog.setContentView(R.layout.mydialog);
        TextView tView = (TextView) dialog.findViewById(R.id.txtDialogMessage);
        tView.setText(getString(R.string.txtfoundnewversion));
        Button btnButton = (Button) dialog.findViewById(R.id.dialog_button_ok);
        btnButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (WelcomeActivity.this.upm != null) {
                    WelcomeActivity.this.upm.StartDownApk();
                }
                dialog.dismiss();
            }
        });
        Button btnButtonc = (Button) dialog.findViewById(R.id.dialog_button_cancel);
        btnButtonc.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.WelcomeActivity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                WelcomeActivity.this.startMainTimer(AVAPIs.TIME_SPAN_LOSED);
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
