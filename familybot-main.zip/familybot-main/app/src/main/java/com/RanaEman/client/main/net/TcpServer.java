package com.RanaEman.client.main.net;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ServerSocket;

/* loaded from: classes.dex */
public class TcpServer extends Thread {
    public static final int DEFAULT_SOCKET_TIMEOUT = 5000;
    static int socket_backlog = 50;
    long alive_time;
    boolean is_running;
    TcpServerListener listener;
    ServerSocket server_socket;
    int socket_timeout;
    boolean stop;

    public TcpServer(int port, TcpServerListener listener) throws IOException {
        init(port, null, 0L, listener);
        start();
    }

    public TcpServer(int port, IpAddress bind_ipaddr, TcpServerListener listener) throws IOException {
        init(port, bind_ipaddr, 0L, listener);
        start();
    }

    public TcpServer(int port, IpAddress bind_ipaddr, long alive_time, TcpServerListener listener) throws IOException {
        init(port, bind_ipaddr, alive_time, listener);
        start();
    }

    private void init(int port, IpAddress bind_ipaddr, long alive_time, TcpServerListener listener) throws IOException {
        this.listener = listener;
        if (bind_ipaddr == null) {
            this.server_socket = new ServerSocket(port);
        } else {
            this.server_socket = new ServerSocket(port, socket_backlog, bind_ipaddr.getInetAddress());
        }
        this.socket_timeout = DEFAULT_SOCKET_TIMEOUT;
        this.alive_time = alive_time;
        this.stop = false;
        this.is_running = true;
    }

    public int getPort() {
        return this.server_socket.getLocalPort();
    }

    public boolean isRunning() {
        return this.is_running;
    }

    public void halt() {
        this.stop = true;
        try {
            this.server_socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Exception error = null;
        long expire = 0;
        try {
            if (this.alive_time > 0) {
                expire = System.currentTimeMillis() + this.alive_time;
            }
            while (!this.stop) {
                try {
                    TcpSocket socket = new TcpSocket(this.server_socket.accept());
                    if (this.listener != null) {
                        this.listener.onIncomingConnection(this, socket);
                    }
                    if (this.alive_time > 0) {
                        expire = System.currentTimeMillis() + this.alive_time;
                    }
                } catch (InterruptedIOException e) {
                    if (this.alive_time > 0 && System.currentTimeMillis() > expire) {
                        halt();
                    }
                }
            }
        } catch (Exception e2) {
            error = e2;
            this.stop = true;
        }
        this.is_running = false;
        try {
            this.server_socket.close();
        } catch (IOException e3) {
        }
        this.server_socket = null;
        if (this.listener != null) {
            this.listener.onServerTerminated(this, error);
        }
        this.listener = null;
    }

    @Override // java.lang.Thread
    public String toString() {
        return "tcp:";
    }
}
