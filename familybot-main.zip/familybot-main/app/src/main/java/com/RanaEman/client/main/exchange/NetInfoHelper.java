package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class NetInfoHelper {
    public static String converInt2IpStr(int ip) {
        return (ip & 255) + "." + ((ip >> 8) & 255) + "." + ((ip >> 16) & 255) + "." + ((ip >> 24) & 255);
    }
}
