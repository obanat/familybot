package com.RanaEman.client.main.net;

/* loaded from: classes.dex */
public class SocketAddress {
    IpAddress ipaddr;
    int port;

    public SocketAddress(IpAddress ipaddr, int port) {
        init(ipaddr, port);
    }

    public SocketAddress(String addr, int port) {
        init(new IpAddress(addr), port);
    }

    public SocketAddress(String soaddr) {
        String addr;
        int port = -1;
        int colon = soaddr.indexOf(58);
        if (colon < 0) {
            addr = soaddr;
        } else {
            addr = soaddr.substring(0, colon);
            try {
                port = Integer.parseInt(soaddr.substring(colon + 1));
            } catch (Exception e) {
            }
        }
        init(new IpAddress(addr), port);
    }

    public SocketAddress(SocketAddress soaddr) {
        init(soaddr.ipaddr, soaddr.port);
    }

    private void init(IpAddress ipaddr, int port) {
        this.ipaddr = ipaddr;
        this.port = port;
    }

    public IpAddress getAddress() {
        return this.ipaddr;
    }

    public int getPort() {
        return this.port;
    }

    public Object clone() {
        return new SocketAddress(this);
    }

    public boolean equals(Object obj) {
        try {
            SocketAddress saddr = (SocketAddress) obj;
            if (this.port != saddr.port) {
                return false;
            }
            return this.ipaddr.equals(saddr.ipaddr);
        } catch (Exception e) {
            return false;
        }
    }

    public String toString() {
        return this.ipaddr.toString() + ":" + this.port;
    }
}
