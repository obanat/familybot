package com.RanaEman.client.main.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.RanaEman.client.main.data.ExprissionItem;
import com.Robot.client.main.R;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class ExprissionListAdapter extends BaseAdapter {
    public static String PWD;
    public static String UID;
    public static String UIDNAME;
    private List<ExprissionItem> items;
    Context mContext;
    private LayoutInflater mLayoutInflater;
    ProgressBar pbShow;
    int selectedPosition = -1;
    TextView tvStatus;

    public ProgressBar getCurPB() {
        return this.pbShow;
    }

    public TextView getCurTV() {
        return this.tvStatus;
    }

    void setSelectedPosition(int i) {
        this.selectedPosition = i;
    }

    public ExprissionListAdapter(Context context, List<ExprissionItem> datas) {
        this.items = new ArrayList();
        this.mLayoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.items.clear();
        this.items = datas;
        this.mContext = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.items.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        if (this.items.size() > position) {
            return this.items.get(position);
        }
        return null;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = this.mLayoutInflater.inflate(R.layout.exprission_list_item, (ViewGroup) null);
        }
        ExprissionItem item = (ExprissionItem) getItem(position);
        CheckBox chkDefault = (CheckBox) convertView.findViewById(R.id.checkBox1);
        chkDefault.setChecked(item.IsDefault);
        TextView t = (TextView) convertView.findViewById(R.id.txtUID);
        t.setText(item.sExpCHName);
        ProgressBar pbShowtemp = (ProgressBar) convertView.findViewById(R.id.progressBar1);
        TextView tvStatustemp = (TextView) convertView.findViewById(R.id.txtdvrip);
        if (item.IsShow) {
            pbShowtemp.setVisibility(0);
            tvStatustemp.setVisibility(0);
            this.pbShow = pbShowtemp;
            this.tvStatus = tvStatustemp;
            this.pbShow.setMax(100);
            if (item.IsNeedDwon) {
                this.tvStatus.setText(this.mContext.getString(R.string.txtDownExp));
            } else {
                this.tvStatus.setText(this.mContext.getString(R.string.txtDown2Device));
            }
        } else {
            pbShowtemp.setVisibility(8);
            tvStatustemp.setVisibility(8);
        }
        return convertView;
    }

    @Override // android.widget.Adapter
    public long getItemId(int arg0) {
        return 0L;
    }
}
