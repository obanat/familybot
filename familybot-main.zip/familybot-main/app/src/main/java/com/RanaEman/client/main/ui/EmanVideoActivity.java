package com.RanaEman.client.main.ui;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.RanaEman.client.main.SigCameraService;
import com.RanaEman.client.main.data.DataCenter;
import com.RanaEman.client.main.data.LocalDvrDBAdapter;
import com.RanaEman.client.main.lockpwd.LockSetupActivity;
import com.Robot.client.main.R;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;
import com.seuic.singlerocker.AppSingleRocker;
import com.tutk.IOTC.AVAPIs;
import com.tutk.IOTC.AVFrame;
import com.tutk.IOTC.AVIOCTRLDEFs;
import com.tutk.IOTC.Camera;
import com.tutk.IOTC.IRegisterIOTCListener;
import com.tutk.IOTC.Packet;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes.dex */
public class EmanVideoActivity extends SlidingFragmentActivity implements View.OnClickListener, IRegisterIOTCListener {
    public static final int HIDERECDISPLAY = 22;
    public static final int RECVCHOK = 11;
    public static final int RECVFILERET = 18;
    public static final int RECVMICAMP = 1;
    public static final int RECV_DATA_ABOUT = 20;
    public static final int RECV_DATA_SETPWDACK = 21;
    public static final int RECV_INFO = 7;
    public static final int SENDFILERET = 17;
    public static final int SESSIONINFORECV = 3;
    public static final int UPDATELIGHTBRESS = 23;
    public static boolean blnAudioOn = true;
    public static boolean blnLandBoolean = false;
    public static boolean isShowing = false;
    private static final String tag = "eManVideoActivity";
    String aboutString;
    AppSingleRocker appSingleRocker;
    bgForConnect bgConnect;
    Button btnAudioOff;
    Button btnExpression;
    Button btnLandOrPort;
    Button btnRecRed;
    ImageView btnRecharge;
    Button btnRecord;
    Button btnSay;
    Button btnSetMenu;
    Button btn_flash;
    ImageButton btn_grandm;
    ImageButton btn_grandp;
    ImageButton btn_orig;
    ImageButton btn_tom;
    Button btnplay;
    Button btnshot;
    long endVoiceTime;
    int iNewBat;
    int iPwdResult;
    ImageView imageViewMic;
    ImageView imgRecharge;
    ImageButton imgbtnPride;
    ImageButton imgbtnSad;
    ImageButton imgbtnShy;
    ImageButton imgbtnSmile;
    ImageButton imgbtnSpin;
    ImageButton imgbtnUp;
    ImageButton imgbtndwon;
    LinearLayout llyt_btns_land;
    LinearLayout llyt_expression;
    RelativeLayout llyt_rightbtns;
    private int mConnStatus;
    SurfaceView monitor;
    PopupWindow popShowAudio;
    RelativeLayout rl_light;
    RelativeLayout rltRockerLayout;
    RelativeLayout rltupdown;
    RelativeLayout rtRecDisplay;
    SampleListFragment sFragment;
    SoundPool sPool;
    SeekBar seekBar;
    String seth0_macaddr;
    String smodel;
    String sproduced_date;
    String sra0_macaddr;
    String sserial;
    long startVoiceTime;
    String sversion;
    Timer timerGetinfo;
    Timer tmShowProgressbar;
    TextView txtAutoCharge;
    TextView txtDisplay;
    TextView txttitle;
    Dialog m_dialog = null;
    Dialog inputPwdDialog = null;
    int isoundID = -1;
    boolean IsUp = false;
    volatile boolean blnIsAudioRecording = false;
    RelativeLayout ryipc = null;
    Chronometer mChronometerRecVideo = null;
    int iProgress = 0;
    int iCurrentMode = 0;
    int iMicAmp = 0;
    ListView lvMenu = null;
    int iAudioLike = 0;
    boolean blnRealyExit = false;
    Boolean blnNeedFast = false;
    View.OnClickListener popAudioSeListener = new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.1
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (view == EmanVideoActivity.this.btn_tom) {
                EmanVideoActivity.this.iAudioLike = 3;
                EmanVideoActivity.this.btnSay.setBackground(EmanVideoActivity.this.getResources().getDrawable(R.drawable.btn_tom_style));
            } else if (view == EmanVideoActivity.this.btn_grandm) {
                EmanVideoActivity.this.iAudioLike = 1;
                EmanVideoActivity.this.btnSay.setBackground(EmanVideoActivity.this.getResources().getDrawable(R.drawable.btn_grandm_style));
            } else if (view == EmanVideoActivity.this.btn_grandp) {
                EmanVideoActivity.this.iAudioLike = 2;
                EmanVideoActivity.this.btnSay.setBackground(EmanVideoActivity.this.getResources().getDrawable(R.drawable.btn_grandp_style));
            } else if (view == EmanVideoActivity.this.btn_orig) {
                EmanVideoActivity.this.iAudioLike = 0;
                EmanVideoActivity.this.btnSay.setBackground(EmanVideoActivity.this.getResources().getDrawable(R.drawable.btn_say_style));
            }
            EmanVideoActivity.this.popShowAudio.dismiss();
        }
    };
    Runnable runnableSendUpDown = new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.3
        @Override // java.lang.Runnable
        public void run() {
            if (SigCameraService.MainCamera != null) {
                if (EmanVideoActivity.this.IsUp) {
                    SigCameraService.MainCamera.sendIOCtrl(0, 12353, Packet.intToByteArray_Little(0));
                } else {
                    SigCameraService.MainCamera.sendIOCtrl(0, 12354, Packet.intToByteArray_Little(0));
                }
                EmanVideoActivity.this.handler.postDelayed(EmanVideoActivity.this.runnableSendUpDown, 700L);
            }
        }
    };
    View.OnTouchListener updowntouchListener = new View.OnTouchListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.4
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View arg0, MotionEvent arg1) {
            switch (arg1.getAction()) {
                case 0:
                    if (arg0 == EmanVideoActivity.this.imgbtnUp) {
                        EmanVideoActivity.this.IsUp = true;
                        if (SigCameraService.MainCamera != null) {
                            SigCameraService.MainCamera.sendIOCtrl(0, 12353, Packet.intToByteArray_Little(0));
                        }
                    } else {
                        EmanVideoActivity.this.IsUp = false;
                        if (SigCameraService.MainCamera != null) {
                            SigCameraService.MainCamera.sendIOCtrl(0, 12354, Packet.intToByteArray_Little(0));
                        }
                    }
                    EmanVideoActivity.this.handler.postDelayed(EmanVideoActivity.this.runnableSendUpDown, 700L);
                    EmanVideoActivity.this.handler.removeCallbacks(EmanVideoActivity.this.runnableHideupdwon);
                    Log.e(EmanVideoActivity.tag, "MotionEvent.ACTION_DOWN");
                    break;
                case 1:
                case 3:
                case 4:
                    EmanVideoActivity.this.handler.postDelayed(EmanVideoActivity.this.runnableHideupdwon, 4000L);
                    EmanVideoActivity.this.handler.removeCallbacks(EmanVideoActivity.this.runnableSendUpDown);
                    Log.e(EmanVideoActivity.tag, "MotionEvent:" + arg1.getAction());
                    break;
                case 2:
                    Log.e(EmanVideoActivity.tag, "MotionEvent.ACTION_MOVE_X:" + arg1.getX() + " Y:" + arg0.getY());
                    break;
            }
            return false;
        }
    };
    Runnable runablelRecording = new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.13
        @Override // java.lang.Runnable
        public void run() {
            EmanVideoActivity.this.blnIsAudioRecording = true;
            Log.e(EmanVideoActivity.tag, "rblRecording running....");
            if (!EmanVideoActivity.blnLandBoolean) {
                EmanVideoActivity.this.appSingleRocker.setVisibility(4);
            }
            EmanVideoActivity.this.imageViewMic.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.rocker_show));
            EmanVideoActivity.this.imageViewMic.setVisibility(0);
            if (SigCameraService.MainCamera != null) {
                SigCameraService.MainCamera.StopPlayQueueG711();
                SigCameraService.MainCamera.startRecordingG711(0, EmanVideoActivity.this.iAudioLike);
                SigCameraService.MainCamera.setMicAmpListenerListener(new Camera.MicAmpListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.13.1
                    @Override // com.tutk.IOTC.Camera.MicAmpListener
                    public void onRecvMicAmp(int MicAmp) {
                        EmanVideoActivity.this.iMicAmp = MicAmp;
                        EmanVideoActivity.this.handler.sendEmptyMessage(1);
                    }
                });
            }
        }
    };
    Handler handler = new Handler() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.15
        @Override // android.os.Handler
        @SuppressLint({"NewApi"})
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    if (EmanVideoActivity.this.imageViewMic.getVisibility() == 0) {
                        EmanVideoActivity.this.imageViewMic.setImageLevel(EmanVideoActivity.this.iMicAmp);
                        break;
                    }
                    break;
                case 3:
                    EmanVideoActivity.this.sessionInfoRecvProgeress();
                    break;
                case 7:
                    EmanVideoActivity.this.updateRecvInfo(msg.getData().getString("NewName"), msg.getData().getInt("Mode"), msg.getData().getInt("LED"));
                    break;
                case 11:
                    EmanVideoActivity.this.HideModeText(1500);
                    break;
                case 18:
                    EmanVideoActivity.this.saveFile(msg.getData().getString("PhotoName"));
                    break;
                case 20:
                    EmanVideoActivity.this.ShowAboutDialog();
                    break;
                case 21:
                    if (EmanVideoActivity.this.iPwdResult == 0) {
                        EmanVideoActivity.this.showdialog(EmanVideoActivity.this.getString(R.string.txtsettingsucess), EmanVideoActivity.this.getString(R.string.tips_modify_security_code_ok));
                        break;
                    } else if (EmanVideoActivity.this.iPwdResult == 1) {
                        EmanVideoActivity.this.showdialog(EmanVideoActivity.this.getString(R.string.txtsettingfailed), EmanVideoActivity.this.getString(R.string.tips_old_password_is_wrong));
                        break;
                    } else {
                        EmanVideoActivity.this.showdialog(EmanVideoActivity.this.getString(R.string.txtsettingfailed), EmanVideoActivity.this.getString(R.string.tips_internal_error));
                        break;
                    }
                case 22:
                    EmanVideoActivity.this.rtRecDisplay.setVisibility(4);
                    break;
                case 23:
                    EmanVideoActivity.this.seekBar.setProgress(EmanVideoActivity.this.iProgress);
                    break;
            }
            super.handleMessage(msg);
        }
    };
    Runnable runnablehideFace = new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.21
        @Override // java.lang.Runnable
        public void run() {
            if (EmanVideoActivity.this.llyt_expression.getVisibility() == 0) {
                EmanVideoActivity.this.llyt_expression.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.dialog_exit_down));
                EmanVideoActivity.this.llyt_expression.setVisibility(4);
                EmanVideoActivity.this.btnExpression.setBackgroundResource(R.drawable.face);
            }
        }
    };
    Runnable runnablehideAudioLike = new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.22
        @Override // java.lang.Runnable
        public void run() {
            if (EmanVideoActivity.this.popShowAudio.isShowing()) {
                EmanVideoActivity.this.popShowAudio.dismiss();
            }
        }
    };
    Runnable runnableHideupdwon = new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.23
        @Override // java.lang.Runnable
        public void run() {
            if (EmanVideoActivity.blnLandBoolean) {
                EmanVideoActivity.this.HideBtns();
                if (SigCameraService.MainCamera.GetRecording()) {
                    EmanVideoActivity.this.rtRecDisplay.setVisibility(0);
                }
            } else {
                EmanVideoActivity.this.llyt_rightbtns.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.slide_out_right));
                EmanVideoActivity.this.llyt_rightbtns.setVisibility(4);
                EmanVideoActivity.this.rltupdown.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.slide_out_left));
                EmanVideoActivity.this.rltupdown.setVisibility(4);
            }
            EmanVideoActivity.this.rl_light.setVisibility(4);
        }
    };
    private BroadcastReceiver oBroadcastReceiver = new BroadcastReceiver() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.24
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String sActionString = intent.getAction();
            Log.e(EmanVideoActivity.tag, "onReceive:" + sActionString);
            if (sActionString.equals(SigCameraService.ACTION_RESENDRECORD_G726FILE)) {
                SigCameraService.MainCamera.startRDT_SendFile(0, 11);
            } else if (sActionString.equals(SigCameraService.ACTION_NEWUIDOK)) {
                Log.e(EmanVideoActivity.tag, "onReceive:" + SigCameraService.ACTION_NEWUIDOK);
                EmanVideoActivity.this.iniCamera();
            } else if (sActionString.equals(SigCameraService.ACTION_NET_OFFLINE)) {
                Log.e(EmanVideoActivity.tag, "onReceive:" + SigCameraService.ACTION_NET_OFFLINE);
                EmanVideoActivity.this.closeCamera();
                EmanVideoActivity.this.showNetOffline();
            }
        }
    };

    public void Showpopmenu(View parent, int x, int y, int postion) {
        if (this.popShowAudio == null) {
            LayoutInflater inflater = (LayoutInflater) getSystemService("layout_inflater");
            View popView = inflater.inflate(R.layout.menu_audio, (ViewGroup) null);
            this.popShowAudio = new PopupWindow(popView, -2, -2);
            this.popShowAudio.setOnDismissListener(new PopupWindow.OnDismissListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.2
                @Override // android.widget.PopupWindow.OnDismissListener
                public void onDismiss() {
                    EmanVideoActivity.this.handler.removeCallbacks(EmanVideoActivity.this.runnablehideAudioLike);
                }
            });
            this.popShowAudio.setBackgroundDrawable(new ColorDrawable(0));
            this.popShowAudio.setAnimationStyle(R.style.PopupAnimation);
            this.btn_tom = (ImageButton) popView.findViewById(R.id.ImageButton08);
            this.btn_grandp = (ImageButton) popView.findViewById(R.id.ImageButton05);
            this.btn_grandm = (ImageButton) popView.findViewById(R.id.ImageButton06);
            this.btn_orig = (ImageButton) popView.findViewById(R.id.ImageButton09);
            this.btn_tom.setOnClickListener(this.popAudioSeListener);
            this.btn_grandp.setOnClickListener(this.popAudioSeListener);
            this.btn_grandm.setOnClickListener(this.popAudioSeListener);
            this.btn_orig.setOnClickListener(this.popAudioSeListener);
        }
        if (this.popShowAudio.isShowing()) {
            this.handler.removeCallbacks(this.runnablehideAudioLike);
            this.popShowAudio.dismiss();
            return;
        }
        this.btn_tom.setVisibility(0);
        this.btn_grandm.setVisibility(0);
        this.btn_grandp.setVisibility(0);
        this.btn_orig.setVisibility(0);
        if (this.iAudioLike == 3) {
            this.btn_tom.setVisibility(8);
        } else if (this.iAudioLike == 1) {
            this.btn_grandm.setVisibility(8);
        } else if (this.iAudioLike == 2) {
            this.btn_grandp.setVisibility(8);
        } else if (this.iAudioLike == 0) {
            this.btn_orig.setVisibility(8);
        }
        if (blnLandBoolean) {
            this.popShowAudio.showAtLocation(parent, 0, x, (int) (y - (160.0f * WelcomeActivity.density)));
        } else {
            this.popShowAudio.showAtLocation(parent, 0, x, (int) (y - (150.0f * WelcomeActivity.density)));
        }
        this.popShowAudio.setFocusable(true);
        this.popShowAudio.setOutsideTouchable(true);
        this.popShowAudio.update();
    }

    private void initSlidingMenu() {
        setBehindContentView(R.layout.menu_frame);
        this.sFragment = new SampleListFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.menu_frame, this.sFragment).commit();
        SlidingMenu sm = getSlidingMenu();
        sm.setShadowWidthRes(R.dimen.shadow_width);
        sm.setShadowDrawable(R.drawable.shadow);
        sm.setBehindOffsetRes(R.dimen.slidingmenu_offset);
        sm.setFadeEnabled(false);
        sm.setTouchModeAbove(0);
        sm.setBehindScrollScale(2.0f);
    }

    @Override // com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getResources().getConfiguration().orientation == 1) {
            blnLandBoolean = false;
        } else {
            blnLandBoolean = true;
        }
        setContentView(R.layout.activity_eman_video2);
        this.imgRecharge = (ImageView) findViewById(R.id.imageView3);
        this.imgRecharge.setVisibility(0);
        this.imgRecharge.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.5
            @Override // android.view.ViewTreeObserver.OnPreDrawListener
            public boolean onPreDraw() {
                RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) EmanVideoActivity.this.txtDisplay.getLayoutParams();
                lp.bottomMargin = (int) (EmanVideoActivity.this.imgRecharge.getMeasuredHeight() * 0.32f);
                EmanVideoActivity.this.txtDisplay.setLayoutParams(lp);
                EmanVideoActivity.this.imgRecharge.getViewTreeObserver().removeOnPreDrawListener(this);
                return true;
            }
        });
        this.rl_light = (RelativeLayout) findViewById(R.id.llt_light);
        this.seekBar = (SeekBar) findViewById(R.id.seekBar2);
        this.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.6
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.e("progress", "progress:" + seekBar.getProgress());
                if (SigCameraService.MainCamera != null) {
                    SigCameraService.MainCamera.sendIOCtrl(0, 12405, Packet.intToByteArray_Little(seekBar.getProgress()));
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }
        });
        initSlidingMenu();
        this.btnLandOrPort = (Button) findViewById(R.id.btn_toland);
        this.btnLandOrPort.setOnClickListener(this);
        this.imageViewMic = (ImageView) findViewById(R.id.imageView1);
        this.imageViewMic.setVisibility(4);
        this.rltRockerLayout = (RelativeLayout) findViewById(R.id.relativeLayout2);
        this.txtAutoCharge = (TextView) findViewById(R.id.txtShowAutoCharge);
        this.txtAutoCharge.setVisibility(4);
        this.btnAudioOff = (Button) findViewById(R.id.btn_aoff);
        this.btnAudioOff.setOnClickListener(this);
        this.imgbtnUp = (ImageButton) findViewById(R.id.imageButton1);
        this.imgbtnUp.setOnTouchListener(this.updowntouchListener);
        this.imgbtndwon = (ImageButton) findViewById(R.id.ImageButton05);
        this.imgbtndwon.setOnTouchListener(this.updowntouchListener);
        this.btnRecharge = (ImageView) findViewById(R.id.btn_batShow);
        this.btnRecharge.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                EmanVideoActivity.this.handler.removeCallbacks(EmanVideoActivity.this.runnableHideupdwon);
                EmanVideoActivity.this.handler.postDelayed(EmanVideoActivity.this.runnableHideupdwon, 4000L);
                EmanVideoActivity.this.txtAutoCharge.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.autocharge_enter));
                EmanVideoActivity.this.txtAutoCharge.setVisibility(0);
                if (SigCameraService.MainCamera != null) {
                    SigCameraService.MainCamera.sendIOCtrl(0, 12371, Packet.intToByteArray_Little(0));
                }
                EmanVideoActivity.this.handler.postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.7.1
                    @Override // java.lang.Runnable
                    public void run() {
                        EmanVideoActivity.this.txtAutoCharge.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.autocharge_exit));
                        EmanVideoActivity.this.txtAutoCharge.setVisibility(4);
                    }
                }, 1500L);
            }
        });
        this.appSingleRocker = (AppSingleRocker) findViewById(R.id.surfaceView2);
        this.appSingleRocker.setSingleRudderListener(new AppSingleRocker.SingleRudderListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.8
            @Override // com.seuic.singlerocker.AppSingleRocker.SingleRudderListener
            public void onSteeringWheelChanged(int action, int angle) {
                if (SigCameraService.MainCamera != null) {
                    Log.e(EmanVideoActivity.tag, "onSteeringWheelChanged:" + angle);
                    SigCameraService.MainCamera.sendIOCtrl(0, 12288, Packet.intToByteArray_Little(angle));
                }
            }
        });
        this.mChronometerRecVideo = (Chronometer) findViewById(R.id.Chronometer01);
        isShowing = true;
        this.btnExpression = (Button) findViewById(R.id.btnexpression);
        this.btnExpression.setOnClickListener(this);
        this.btnSetMenu = (Button) findViewById(R.id.btn_set_Menu);
        this.btnSetMenu.setOnClickListener(this);
        this.llyt_expression = (LinearLayout) findViewById(R.id.llyt_expression);
        this.llyt_expression.setVisibility(4);
        if (!blnLandBoolean) {
            this.llyt_rightbtns = (RelativeLayout) findViewById(R.id.rllt_btns);
        }
        this.rltupdown = (RelativeLayout) findViewById(R.id.rlUpDown);
        this.rtRecDisplay = (RelativeLayout) findViewById(R.id.rtRecDisplay);
        this.rtRecDisplay.setVisibility(4);
        this.txttitle = (TextView) findViewById(R.id.txtUID);
        this.txtDisplay = (TextView) findViewById(R.id.txtDisplay);
        this.bgConnect = (bgForConnect) findViewById(R.id.bg_forconn);
        this.imgbtnSpin = (ImageButton) findViewById(R.id.ImageButton00);
        this.imgbtnSmile = (ImageButton) findViewById(R.id.ImageButton01);
        this.imgbtnPride = (ImageButton) findViewById(R.id.ImageButton02);
        this.imgbtnSad = (ImageButton) findViewById(R.id.ImageButton03);
        this.imgbtnShy = (ImageButton) findViewById(R.id.ImageButton04);
        this.sPool = new SoundPool(1, 3, 0);
        this.isoundID = this.sPool.load(this, R.raw.shot_click, 1);
        this.btnRecRed = (Button) findViewById(R.id.Button02);
        Animation animation2 = new AlphaAnimation(1.0f, 0.0f);
        animation2.setDuration(500L);
        animation2.setInterpolator(new LinearInterpolator());
        animation2.setRepeatCount(-1);
        animation2.setRepeatMode(2);
        this.btnRecRed.setAnimation(animation2);
        this.btnSay = (Button) findViewById(R.id.buttonSpeak);
        this.btnSay.setOnTouchListener(new View.OnTouchListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.9
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View arg0, MotionEvent arg1) {
                switch (arg1.getAction()) {
                    case 0:
                        EmanVideoActivity.this.startVoiceTime = System.currentTimeMillis();
                        EmanVideoActivity.this.handler.postDelayed(EmanVideoActivity.this.runablelRecording, 400L);
                        break;
                    case 1:
                        EmanVideoActivity.this.endVoiceTime = System.currentTimeMillis();
                        long interval = EmanVideoActivity.this.endVoiceTime - EmanVideoActivity.this.startVoiceTime;
                        if (!EmanVideoActivity.this.blnIsAudioRecording) {
                            EmanVideoActivity.this.handler.removeCallbacks(EmanVideoActivity.this.runablelRecording);
                            int[] arrayOfInt = new int[2];
                            arg0.getLocationOnScreen(arrayOfInt);
                            int x = arrayOfInt[0];
                            int y = arrayOfInt[1];
                            EmanVideoActivity.this.Showpopmenu(arg0, x, y, 0);
                            EmanVideoActivity.this.handler.postDelayed(EmanVideoActivity.this.runnablehideAudioLike, 4000L);
                            break;
                        } else {
                            if (SigCameraService.MainCamera != null) {
                                SigCameraService.MainCamera.unRigAmpListenerListener();
                                if (interval > 800) {
                                    SigCameraService.MainCamera.stopRecordingG711(0, true);
                                } else {
                                    SigCameraService.MainCamera.stopRecordingG711(0, false);
                                }
                                if (EmanVideoActivity.blnAudioOn) {
                                    SigCameraService.MainCamera.startPlayQueueG711(0);
                                }
                            }
                            EmanVideoActivity.this.imageViewMic.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.rocker_hide));
                            EmanVideoActivity.this.imageViewMic.setVisibility(4);
                            if (!EmanVideoActivity.blnLandBoolean) {
                                EmanVideoActivity.this.appSingleRocker.setVisibility(0);
                            }
                            EmanVideoActivity.this.blnIsAudioRecording = false;
                            break;
                        }
                }
                return false;
            }
        });
        this.btnshot = (Button) findViewById(R.id.btn_shot);
        this.btnshot.setOnClickListener(this);
        DeleteAllAudioFile();
        this.monitor = (SurfaceView) findViewById(R.id.surfaceView1);
        Log.e(tag, "onCreate surface width:" + this.monitor.getWidth());
        Log.e(tag, "avAPIS.ver:" + getAVAPis());
        if (WelcomeActivity.totalHdps < 590) {
            this.ryipc = (RelativeLayout) findViewById(R.id.rl_status);
            ViewGroup.LayoutParams lp2 = this.ryipc.getLayoutParams();
            lp2.height = (int) (230.0f * WelcomeActivity.density);
            this.ryipc.setLayoutParams(lp2);
        }
        this.btnplay = (Button) findViewById(R.id.Button01);
        this.btnplay.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(EmanVideoActivity.this, ShowIMGActivity.class);
                EmanVideoActivity.this.startActivity(intent);
                EmanVideoActivity.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
        this.btnRecord = (Button) findViewById(R.id.button1);
        this.btnRecord.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                if (EmanVideoActivity.this.rtRecDisplay.getVisibility() == 4) {
                    EmanVideoActivity.this.btnRecord.setBackgroundResource(R.drawable.record_p);
                    EmanVideoActivity.this.rtRecDisplay.setVisibility(0);
                    EmanVideoActivity.this.mChronometerRecVideo.setBase(SystemClock.elapsedRealtime());
                    EmanVideoActivity.this.mChronometerRecVideo.start();
                    if (EmanVideoActivity.blnLandBoolean && EmanVideoActivity.this.rl_light.getVisibility() == 0) {
                        EmanVideoActivity.this.rl_light.setVisibility(4);
                    }
                    if (SigCameraService.MainCamera != null) {
                        SigCameraService.MainCamera.SetRecording(true);
                        return;
                    }
                    return;
                }
                EmanVideoActivity.this.btnRecord.setBackgroundResource(R.drawable.record_nor);
                EmanVideoActivity.this.handler.sendEmptyMessage(22);
                EmanVideoActivity.this.mChronometerRecVideo.stop();
                if (SigCameraService.MainCamera != null) {
                    SigCameraService.MainCamera.SetRecording(false);
                }
            }
        });
        this.btn_flash = (Button) findViewById(R.id.btn_flash);
        this.btn_flash.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (SigCameraService.MainCamera != null) {
                    SigCameraService.MainCamera.sendIOCtrl(0, 12419, Packet.intToByteArray_Little(0));
                }
            }
        });
        Log.e(tag, "onCreateEnd");
        HideAllControls();

        //SigCameraService.MainCamera.registerIOTCListener(this);//zhangxin add
    }

    void playShotSound() {
        this.sPool.play(this.isoundID, 1.0f, 1.0f, 1, 0, 1.0f);
    }

    private String getAVAPis() {
        int i = AVAPIs.avGetAVApiVer();
        StringBuffer localStringBuffer = new StringBuffer();
        byte[] arrayOfByte = {(byte) (i >>> 24), (byte) (i >>> 16), (byte) (i >>> 8), (byte) i};
        localStringBuffer.append(arrayOfByte[0] & AVFrame.FRM_STATE_UNKOWN);
        localStringBuffer.append('.');
        localStringBuffer.append(arrayOfByte[1] & AVFrame.FRM_STATE_UNKOWN);
        localStringBuffer.append('.');
        localStringBuffer.append(arrayOfByte[2] & AVFrame.FRM_STATE_UNKOWN);
        localStringBuffer.append('.');
        localStringBuffer.append(arrayOfByte[3] & AVFrame.FRM_STATE_UNKOWN);
        return localStringBuffer.toString();
    }

    void SetBatbtn(int ibat) {
        if (ibat >= 90) {
            this.btnRecharge.setBackgroundResource(R.drawable.electric7);
        } else if (ibat >= 80) {
            this.btnRecharge.setBackgroundResource(R.drawable.electric6);
        } else if (ibat >= 60) {
            this.btnRecharge.setBackgroundResource(R.drawable.electric5);
        } else if (ibat >= 40) {
            this.btnRecharge.setBackgroundResource(R.drawable.electric4);
        } else if (ibat >= 30) {
            this.btnRecharge.setBackgroundResource(R.drawable.electric3);
        } else if (ibat >= 15) {
            this.btnRecharge.setBackgroundResource(R.drawable.electric2);
        } else {
            this.btnRecharge.setBackgroundResource(R.drawable.electric1);
        }
    }

    private void createReadInfoTimer(int iTime) {
        if (this.timerGetinfo != null) {
            this.timerGetinfo.cancel();
            this.timerGetinfo.purge();
            this.timerGetinfo = null;
        }
        this.timerGetinfo = new Timer();
        this.timerGetinfo.schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.14
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                if (SigCameraService.MainCamera != null) {
                    Log.e(EmanVideoActivity.tag, "sendIOCtrl(0, 0x460");
                    SigCameraService.MainCamera.sendIOCtrl(0, 1120, Packet.intToByteArray_Little(9));
                }
            }
        }, iTime, 120000L);
    }

    void sendBroadcast_ADDUID() {
        Intent intent = new Intent();
        intent.setAction(SigCameraService.ACTION_ADDUID);
        intent.putExtra("UID", SigCameraService.MainCamera.getUID());
        sendBroadcast(intent);
    }

    void sessionInfoRecvProgeress() {
        Log.e(tag, "SESSIONINFORECV：" + this.mConnStatus);
        if (this.mConnStatus == -1) {
            //if (TextUtils.isEmpty(SigCameraService.sDefaultUID) ) {
                sendBroadcast_ADDUID();
            //}
        } else if (this.mConnStatus == 4 || this.mConnStatus == 6) {
            ShowModeText(getString(R.string.connstus_time_out), true);
            if (SigCameraService.MainCamera != null && SigCameraService.MainCamera.iAP > 3) {
                ShowSetWifi();
            }
        } else if (this.mConnStatus == 1) {
            if (this.bgConnect.getProgress() > 260) {
                ShowProgressbar(0);
            } else {
                ShowProgressbar(1);
            }
            ShowModeText(getString(R.string.connstus_connecting), true);
        } else if (this.mConnStatus == 9) {
            createReadInfoTimer(10);
        } else if (this.mConnStatus == 3) {
            ShowModeText(getString(R.string.connstus_connchannel), true);
        } else if (this.mConnStatus == 5) {
            ShowModeText(getString(R.string.connstus_wrong_password), true);
            ShowInputPwd();
        } else if (this.mConnStatus == 8 || this.mConnStatus == 7) {
            ShowModeText(getString(R.string.connstus_network_err), true);
            if (SigCameraService.MainCamera != null && SigCameraService.MainCamera.iAP > 3) {
                ShowSetWifi();
            }
        } else if (this.mConnStatus == 2) {
            ShowModeText(getString(R.string.connstus_connected), true);
        } else {
            this.txtDisplay.setText(getString(R.string.connmode_none));
        }
    }

    void updateRecvInfo(String sNewNameString, int iMode, int iRecharing) {
        if (!sNewNameString.equals(this.txttitle.getText().toString()) && SigCameraService.MainCamera != null) {
            this.txttitle.setText(SigCameraService.MainCamera.getName());
            this.sFragment.setName(SigCameraService.MainCamera.getName());
        }
        if ((iMode == 99 || iMode == 88) && !SigCameraService.MainCamera.isUserNeedAP().booleanValue()) {
            StartAPSet();
            return;
        }
        if (iRecharing == 0) {
            if (this.iCurrentMode != 1) {
                SigCameraService.MainCamera.stopShowHD(0);
                this.monitor.setVisibility(4);
                this.appSingleRocker.setBitmap_bg(0);
                HideModeText(10);
                this.iCurrentMode = 1;
            } else if (this.txtDisplay.getVisibility() == 0) {
                HideModeText(10);
            }
        } else if (this.iCurrentMode != 2) {
            if (this.timerGetinfo == null) {
                createReadInfoTimer(120000);
            }
            this.imgRecharge.setImageLevel(0);
            ShowProgressbar(0);
            this.appSingleRocker.setBitmap_bg(1);
            this.monitor.setVisibility(0);
            //SigCameraService.MainCamera.startShowHD(0, this.monitor.getHolder().getSurface());
            //SigCameraService.MainCamera.sendIOCtrl(0, 12407, Packet.intToByteArray_Little(0));
            if (blnAudioOn) {
                SigCameraService.MainCamera.sendIOCtrl(0, 12345, Packet.intToByteArray_Little(1));
                SigCameraService.MainCamera.startPlayQueueG711(0);
                this.btnAudioOff.setBackgroundResource(R.drawable.audio_off);
            } else {
                this.btnAudioOff.setBackgroundResource(R.drawable.audio_off_p);
            }
            this.iCurrentMode = 2;
        }
        this.btnRecharge.setImageLevel(this.iNewBat);
    }

    void saveFile(String sName) {
        File file = new File(Environment.getExternalStorageDirectory() + "/eMan/Shot/" + sName);
        Intent localIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file));
        sendBroadcast(localIntent);
        Intent intent = new Intent("android.intent.action.VIEW");
        Log.e(tag, file.getName());
        intent.setDataAndType(Uri.fromFile(file), "image/*");
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void showdialog(String stitle, String msg) {
        if (this.m_dialog != null) {
            this.m_dialog.dismiss();
            this.m_dialog = null;
        }
        this.m_dialog = new Dialog(this, R.style.Tips);
        this.m_dialog.setContentView(R.layout.myprogress_dialog);
        TextView txtTitleTextView = (TextView) this.m_dialog.findViewById(R.id.txtDialogTitle);
        txtTitleTextView.setText(stitle);
        TextView txtMyProgerssMsg = (TextView) this.m_dialog.findViewById(R.id.txtMessage);
        txtMyProgerssMsg.setText(msg);
        RelativeLayout pbdialogBar = (RelativeLayout) this.m_dialog.findViewById(R.id.rlDialogPb);
        pbdialogBar.setVisibility(8);
        Button btnokk = (Button) this.m_dialog.findViewById(R.id.btnSure);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.16
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                EmanVideoActivity.this.m_dialog.dismiss();
            }
        });
        this.m_dialog.setCancelable(true);
        this.m_dialog.show();
    }

    public void iniCamera() {
        if (SigCameraService.MainCamera != null) {
            this.txttitle.setText(SigCameraService.MainCamera.getName());
            this.sFragment.setName(this.txttitle.getText().toString());
            SigCameraService.MainCamera.registerIOTCListener(this);
        }
        if (SigCameraService.iLastNetStatus > 0) {
            ShowModeText(getString(R.string.connstus_connecting), true);
            ShowProgressbar(0);
            this.imgRecharge.setImageLevel(0);
            if (SigCameraService.MainCamera != null) {
                if (SigCameraService.MainCamera.iStatus == 5) {
                    this.handler.postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.17
                        @Override // java.lang.Runnable
                        public void run() {
                            EmanVideoActivity.this.ShowInputPwd();
                        }
                    }, 1500L);
                }
                Log.e(tag, "iniCamera sendIOCtrl(0, 0x460");
                if (SigCameraService.MainCamera.iStatus == 9) {
                    SigCameraService.MainCamera.sendIOCtrl(0, 1120, Packet.intToByteArray_Little(2));
                }
                SigCameraService.MainCamera.SetCamIndex(0);
            }
        } else {
            ShowModeText(getString(R.string.status_nonetwork), false);
            this.imgRecharge.setImageLevel(5);
        }
        this.imgRecharge.setVisibility(0);
    }

    private void HideAllControls() {
        if (blnLandBoolean) {
            HideBtns();
        } else {
            this.llyt_rightbtns.setVisibility(4);
            this.rltupdown.setVisibility(4);
        }
        this.rl_light.setVisibility(4);
    }


    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onResume() {
        registerBroadcastReceiver();
        getWindow().addFlags(128);
        if (getSlidingMenu().isMenuShowing()) {
            toggle();
        }
        if (SigCameraService.MainCamera != null) {
            iniCamera();
            Log.e(tag, "iniCamera");
        }
        if (this.lvMenu == null) {
            iniSlidMenuAction();
        }
        Log.e(tag, "onResume");
        super.onResume();
    }

    void StartAPSet() {
        Intent intent = new Intent(this, Eman_APSet.class);
        intent.putExtra("UIDNAME", SigCameraService.MainCamera.getName());
        intent.putExtra("UID", SigCameraService.MainCamera.getUID());
        intent.putExtra("PWD", SigCameraService.MainCamera.getPassword());
        intent.putExtra("fromWhat", 1);
        intent.putExtra("SetKind", 1);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    void iniSlidMenuAction() {
        this.lvMenu = this.sFragment.getListView();
        this.lvMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.18
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterview, View view, int i, long l) {
                Log.e("menu", "int:" + i + " Long:" + l);
                Log.e("menu", "top:" + view.getTop() + " left:" + view.getLeft());
                if (i == 0) {
                    if (SigCameraService.iLastNetStatus <= 0) {
                        EmanVideoActivity.this.toggle();
                    } else if (SigCameraService.MainCamera != null) {
                        EmanVideoActivity.this.StartAPSet();
                    }
                } else if (i == 1) {
                    Intent intent = new Intent(EmanVideoActivity.this, NewMainActivity.class);
                    intent.putExtra("FromWhat", 1);
                    EmanVideoActivity.this.startActivityForResult(intent, 1);
                    EmanVideoActivity.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (i == 2) {
                    Intent intent2 = new Intent(EmanVideoActivity.this, LockSetupActivity.class);
                    intent2.putExtra("MODE", "setup");
                    EmanVideoActivity.this.startActivity(intent2);
                    EmanVideoActivity.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (i == 3) {
                    if (SigCameraService.iLastNetStatus <= 0) {
                        EmanVideoActivity.this.toggle();
                    } else {
                        EmanVideoActivity.this.ShowModiPwdDialog();
                    }
                } else if (i == 4) {
                    if (SigCameraService.iLastNetStatus <= 0) {
                        EmanVideoActivity.this.toggle();
                    } else if (SigCameraService.MainCamera != null) {
                        SigCameraService.MainCamera.sendIOCtrl(0, 1394, Packet.intToByteArray_Little(0));
                    }
                }
            }
        });
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onPause() {
        unRegisterBroadcastReceiver();
        if (this.tmShowProgressbar != null) {
            this.tmShowProgressbar.cancel();
            this.tmShowProgressbar.purge();
            this.tmShowProgressbar = null;
        }
        Log.e(tag, "onPause");
        this.handler.removeCallbacks(this.runnableSendUpDown);
        this.handler.removeCallbacks(this.runablelRecording);
        this.handler.removeCallbacks(this.runnablehideAudioLike);
        this.handler.removeCallbacks(this.runnablehideFace);
        this.handler.removeCallbacks(this.runnableHideupdwon);
        hideAllbtns();
        super.onPause();
        closeCamera();
        Log.e(tag, "onPause end");
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        if (this.blnRealyExit) {
            if (SigCameraService.MainCamera != null) {
                Log.e(tag, "onDestroy  ");
                SigCameraService.MainCamera.unregisterIOTCListener(this);
                SigCameraService.MainCamera.disconnect();
                isShowing = false;
                this.sPool.release();
                Log.e(tag, "onDestroy end");
            }
            if (WelcomeActivity.sigserviceintent != null) {
                stopService(WelcomeActivity.sigserviceintent);
                WelcomeActivity.sigserviceintent = null;
            }
        }
        super.onDestroy();
    }

    void ShowInputPwd() {
        if (this.inputPwdDialog != null) {
            if (!this.inputPwdDialog.isShowing()) {
                this.inputPwdDialog.dismiss();
                this.inputPwdDialog = null;
            } else {
                return;
            }
        }
        this.inputPwdDialog = new Dialog(this, R.style.Tips);
        this.inputPwdDialog.setContentView(R.layout.dialog_input_pwd);
        TextView tvtitleTextView = (TextView) this.inputPwdDialog.findViewById(R.id.textView1);
        tvtitleTextView.setText(getString(R.string.connstus_wrong_password));
        Button btnokk = (Button) this.inputPwdDialog.findViewById(R.id.btn_Ok);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.19
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                TextView txtPwdNew = (TextView) EmanVideoActivity.this.inputPwdDialog.findViewById(R.id.txtDvrPwd);
                String sPwdNew = txtPwdNew.getText().toString();
                if (sPwdNew.isEmpty()) {
                    Toast.makeText(EmanVideoActivity.this, EmanVideoActivity.this.getString(R.string.txtpwdnotempty), 1).show();
                    return;
                }
                if (DataCenter.UpdatelocalDvrFromDB(LocalDvrDBAdapter.DVR_PWD, sPwdNew, SigCameraService.MainCamera.getUID())) {
                }
                SigCameraService.MainCamera.SetPassword(sPwdNew);
                SigCameraService.MainCamera.start(0, "admin", SigCameraService.MainCamera.getPassword());
                EmanVideoActivity.this.inputPwdDialog.dismiss();
                EmanVideoActivity.this.inputPwdDialog = null;
            }
        });
        this.inputPwdDialog.setCancelable(true);
        this.inputPwdDialog.show();
    }

    void ShowModeText(String txtMsg, boolean blnDisProgess) {
        if (blnDisProgess) {
            this.bgConnect.setVisibility(0);
        } else {
            if (this.tmShowProgressbar != null) {
                this.tmShowProgressbar.cancel();
                this.tmShowProgressbar.purge();
                this.tmShowProgressbar = null;
            }
            this.bgConnect.setVisibility(4);
        }
        this.txtDisplay.setVisibility(0);
        if (this.monitor.getVisibility() == 0) {
            this.monitor.setVisibility(4);
        }
        this.txtDisplay.setText(txtMsg);
    }

    void HideModeText(int iTime) {
        this.txtDisplay.setVisibility(4);
        this.txtDisplay.setText(BuildConfig.FLAVOR);
        this.blnNeedFast = true;
        this.handler.postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.20
            @Override // java.lang.Runnable
            public void run() {
                if (EmanVideoActivity.this.tmShowProgressbar != null) {
                    EmanVideoActivity.this.tmShowProgressbar.cancel();
                    EmanVideoActivity.this.tmShowProgressbar.purge();
                    EmanVideoActivity.this.tmShowProgressbar = null;
                }
                EmanVideoActivity.this.bgConnect.setVisibility(4);
                if (!SigCameraService.MainCamera.isRecharge().booleanValue()) {
                    EmanVideoActivity.this.imgRecharge.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.rocker_hide));
                    EmanVideoActivity.this.imgRecharge.setVisibility(4);
                    return;
                }
                EmanVideoActivity.this.imgRecharge.setImageLevel(EmanVideoActivity.this.iNewBat);
                EmanVideoActivity.this.imgRecharge.setAnimation(AnimationUtils.loadAnimation(EmanVideoActivity.this, R.anim.rocker_show));
                EmanVideoActivity.this.imgRecharge.setVisibility(0);
            }
        }, iTime);
    }

    private int SetChargeLevel_BG(int ibat) {
        if (ibat > 80) {
            return 5;
        }
        if (ibat > 60) {
            return 4;
        }
        if (ibat > 40) {
            return 3;
        }
        if (ibat > 20) {
            return 2;
        }
        return 1;
    }

    public void onExpressionClick(View v) {
        int ikind = -1;
        if (v == this.imgbtnSpin) {
            ikind = 0;
        } else if (v == this.imgbtnSmile) {
            ikind = 1;
        } else if (v == this.imgbtnPride) {
            ikind = 2;
        } else if (v == this.imgbtnSad) {
            ikind = 3;
        } else if (v == this.imgbtnShy) {
            ikind = 4;
        }
        if (ikind >= 0) {
            SigCameraService.MainCamera.sendIOCtrl(0, 12293, Packet.intToByteArray_Little(ikind));
        }
        this.handler.removeCallbacks(this.runnablehideFace);
        runOnUiThread(this.runnablehideFace);
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0 && resultCode == -1 && SigCameraService.MainCamera != null) {
            Bundle bud = data.getExtras();
            byte[] bytepwds = new byte[40];
            String tempstrString = bud.getString("OLDPWD");
            System.arraycopy(tempstrString.getBytes(), 0, bytepwds, 0, tempstrString.length());
            String tempstrString2 = bud.getString("NEWPWD");
            if (!tempstrString2.isEmpty()) {
                System.arraycopy(tempstrString2.getBytes(), 0, bytepwds, 20, tempstrString2.length());
                SigCameraService.MainCamera.sendIOCtrl(0, AVIOCTRLDEFs.IOTYPE_USER_IPCAM_SETPASSWORD_REQ, bytepwds);
            }
        }
        if (requestCode == 1 && resultCode == -1) {
            this.blnRealyExit = true;
            finish();
            Process.killProcess(Process.myPid());
            System.exit(0);
            Log.e(tag, "onActivityResult -->finish()");
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override // android.view.View.OnClickListener
    @SuppressLint({"NewApi"})
    public void onClick(View v) {
        if (v == this.btnLandOrPort) {
            if (blnLandBoolean) {
                setRequestedOrientation(1);
            } else {
                setRequestedOrientation(0);
            }
        } else if (this.btnAudioOff == v) {
            if (blnAudioOn) {
                blnAudioOn = false;
                this.btnAudioOff.setBackgroundResource(R.drawable.audio_off_p);
                SigCameraService.MainCamera.sendIOCtrl(0, 12355, Packet.intToByteArray_Little(1));
                SigCameraService.MainCamera.StopPlayQueueG711();
            } else {
                blnAudioOn = true;
                this.btnAudioOff.setBackgroundResource(R.drawable.audio_off);
                SigCameraService.MainCamera.sendIOCtrl(0, 12345, Packet.intToByteArray_Little(1));
                SigCameraService.MainCamera.startPlayQueueG711(0);
            }
            this.handler.removeCallbacks(this.runnableHideupdwon);
            this.handler.postDelayed(this.runnableHideupdwon, 4000L);
        } else if (this.btnSetMenu == v) {
            toggle();
        } else if (this.btnExpression == v) {
            if (this.llyt_expression.getVisibility() == 4) {
                this.btnExpression.setBackgroundResource(R.drawable.face_p);
                this.llyt_expression.setAnimation(AnimationUtils.loadAnimation(this, R.anim.dialog_enter_up));
                this.llyt_expression.setVisibility(0);
                this.handler.postDelayed(this.runnablehideFace, 4000L);
                return;
            }
            this.handler.removeCallbacks(this.runnablehideFace);
            runOnUiThread(this.runnablehideFace);
        } else if (this.btnshot == v) {
            playShotSound();
            SigCameraService.MainCamera.sendIOCtrl(0, 12387, Packet.intToByteArray_Little(0));
        }
    }

    void netWorkChangedProgress() {
        if (SigCameraService.iLastNetStatus <= 0) {
            ShowModeText(getString(R.string.status_nonetwork), false);
            this.imgRecharge.setImageLevel(5);
            this.imgRecharge.setVisibility(0);
        }
    }

    void showNetOffline() {
        ShowModeText(getString(R.string.status_nonetwork), false);
        this.imgRecharge.setImageLevel(5);
        this.imgRecharge.setVisibility(0);
        if (this.tmShowProgressbar != null) {
            this.tmShowProgressbar.cancel();
            this.tmShowProgressbar.purge();
            this.tmShowProgressbar = null;
        }
        this.bgConnect.setVisibility(4);
    }

    void closeCamera() {
        this.iCurrentMode = 0;
        if (SigCameraService.MainCamera != null) {
            if (this.rtRecDisplay.getVisibility() == 0) {
                this.btnRecord.setBackgroundResource(R.drawable.record_nor);
                this.handler.sendEmptyMessage(22);
                SigCameraService.MainCamera.SetRecording(false);
            }
            SigCameraService.MainCamera.sendIOCtrl(0, 12355, Packet.intToByteArray_Little(1));
            SigCameraService.MainCamera.StopPlayQueueG711();
            SigCameraService.MainCamera.stopShowHD(0);
            SigCameraService.MainCamera.unregisterIOTCListener(this);
        }
        if (this.timerGetinfo != null) {
            this.timerGetinfo.cancel();
            this.timerGetinfo.purge();
            this.timerGetinfo = null;
        }
    }

    public void registerBroadcastReceiver() {
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction(SigCameraService.ACTION_RESENDRECORD_G726FILE);
        myIntentFilter.addAction(SigCameraService.ACTION_NEWUIDOK);
        myIntentFilter.addAction(SigCameraService.ACTION_NET_OFFLINE);
        registerReceiver(this.oBroadcastReceiver, myIntentFilter);
    }

    public void unRegisterBroadcastReceiver() {
        unregisterReceiver(this.oBroadcastReceiver);
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveChannelInfo(Camera paramCamera, int paramInt1, int paramInt2) {
        Log.e(tag, "receiveChannelInfo paramInt2:" + paramInt2);
        if (SigCameraService.MainCamera == paramCamera) {
            this.mConnStatus = paramInt2;
            this.handler.sendEmptyMessage(3);
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveFrameInfo(Camera paramCamera, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    @SuppressLint({"NewApi"})
    public void receiveIOCtrlData(Camera paramCamera, int paramInt1, int paramInt2, byte[] paramArrayOfByte) {
        Log.e(tag, "receiveIOCtrlData paramInt2:" + paramInt2);
        if (SigCameraService.MainCamera != paramCamera) {
            Log.e(tag, "SigCameraService.MainCamera != paramCamera");
        } else if (paramInt2 == 770) {
            this.handler.sendEmptyMessage(11);
        } else if (paramInt2 == 819) {
            this.iPwdResult = paramArrayOfByte[0];
            this.handler.sendEmptyMessage(21);
        } else if (paramInt2 == 12406) {
            int iPt = Packet.byteArrayToInt_Little(paramArrayOfByte, 0);
            if (iPt != 0) {
                this.iProgress = iPt;
            } else {
                this.iProgress = this.seekBar.getProgress();
            }
            this.handler.sendEmptyMessage(23);
        } else if (paramInt2 == 12408) {
            int iPt2 = Packet.byteArrayToInt_Little(paramArrayOfByte, 0);
            if (iPt2 >= 0 && iPt2 <= 0) {
                this.iProgress = iPt2;
                this.handler.sendEmptyMessage(23);
            }
        } else if (paramInt2 == 1395) {
            String sAll = new String(paramArrayOfByte);
            this.smodel = sAll.substring(0, 20);
            this.smodel = this.smodel.substring(0, this.smodel.indexOf(0));
            this.sversion = sAll.substring(20, 40);
            this.sversion = this.sversion.substring(0, this.sversion.indexOf(0));
            this.sproduced_date = sAll.substring(40, 60);
            this.sproduced_date = this.sproduced_date.substring(0, this.sproduced_date.indexOf(0));
            this.sserial = sAll.substring(60, 80);
            this.sserial = this.sserial.substring(0, this.sserial.indexOf(0));
            this.sra0_macaddr = sAll.substring(80, 100);
            this.sra0_macaddr = this.sra0_macaddr.substring(0, this.sra0_macaddr.indexOf(0));
            if (paramArrayOfByte.length > 140) {
                this.seth0_macaddr = sAll.substring(120, AVFrame.MEDIA_CODEC_AUDIO_PCM);
            } else {
                this.seth0_macaddr = sAll.substring(100, 120);
            }
            this.aboutString = getString(R.string.txtSerialnumber) + this.sserial + "\n\n" + getString(R.string.txtVersion) + WelcomeActivity.getVersion(this).replace("V", BuildConfig.FLAVOR);
            this.handler.sendEmptyMessage(20);
        } else if (paramInt2 == 1121) {
            String sNewName = new String(paramArrayOfByte, 16, 36).trim();
            int iLed = Packet.byteArrayToInt_Little(paramArrayOfByte, 4);
            int iBat = Packet.byteArrayToInt_Little(paramArrayOfByte, 8);
            int iMode = Packet.byteArrayToInt_Little(paramArrayOfByte, AVIOCTRLDEFs.IOTYPE_USER_IPCAM_AUDIOSTART);
            int iBat_New = Packet.byteArrayToInt_Little(paramArrayOfByte, 740);
            if (iBat_New == 0) {
                iBat_New = getBatF(iBat);
            }
            this.iNewBat = iBat_New;
            Message msgMessage = this.handler.obtainMessage();
            Bundle data = new Bundle();
            data.putInt("Bat", iBat);
            data.putInt("Bat_New", iBat_New);
            data.putInt("LED", iLed);
            data.putInt("Mode", iMode);
            data.putString("NewName", sNewName);
            msgMessage.what = 7;
            msgMessage.setData(data);
            this.handler.sendMessage(msgMessage);
        } else if (paramInt2 == 12388) {
            SigCameraService.MainCamera.startRecvPhoto_file(0, 1);
            Log.e(tag, "recv_photo");
        }
    }

    private int getBatF(int iBat) {
        float fbat;
        float fbat2;
        float fbat3 = 4.0f - (iBat * 0.0064f);
        if (fbat3 > 0.0f) {
            if (fbat3 < 0.5f) {
                fbat = (1.0f - (fbat3 / 0.5f)) * 100.0f;
            } else {
                fbat = 1.0f;
            }
        } else {
            fbat = 100.0f;
        }
        Log.e(tag, "bat:" + fbat);
        if (fbat >= 90.0f) {
            fbat2 = 4.0f;
        } else if (fbat >= 65.0f) {
            fbat2 = 3.0f;
        } else if (fbat >= 30.0f) {
            fbat2 = 2.0f;
        } else {
            fbat2 = 1.0f;
        }
        Log.e(tag, "bat#i:" + fbat2);
        return (int) fbat2;
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveSessionInfo(Camera paramCamera, int paramInt) {
        Log.e(tag, " receiveSessionInfo paramInt1:" + paramInt);
        if (SigCameraService.MainCamera == paramCamera) {
            this.mConnStatus = paramInt;
            this.handler.sendEmptyMessage(3);
        }
    }

    void ShowModiPwdDialog() {
        final Dialog ModiPwdDialog = new Dialog(this, R.style.Tips);
        ModiPwdDialog.setContentView(R.layout.dialog_modi_pwd);
        Button cancle = (Button) ModiPwdDialog.findViewById(R.id.btn_cancelconn);
        cancle.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.25
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ModiPwdDialog.dismiss();
            }
        });
        Button btnokk = (Button) ModiPwdDialog.findViewById(R.id.btn_ModiPwd);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.26
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                TextView txtoldpwd = (TextView) ModiPwdDialog.findViewById(R.id.txtoldPwd);
                TextView txtnewpwd = (TextView) ModiPwdDialog.findViewById(R.id.txtnewpwd1);
                TextView txtnewpws2 = (TextView) ModiPwdDialog.findViewById(R.id.txtnewpwd2);
                TextView txtdis = (TextView) ModiPwdDialog.findViewById(R.id.textView3);
                if (SigCameraService.MainCamera != null && txtoldpwd.getText().toString().equals(BuildConfig.FLAVOR) && txtnewpwd.getText().toString().equals("test") && !txtnewpws2.getText().toString().equals(BuildConfig.FLAVOR)) {
                    int iCommd = Integer.parseInt(txtnewpws2.getText().toString(), 16);
                    SigCameraService.MainCamera.sendIOCtrl(0, iCommd, Packet.intToByteArray_Little(0));
                    Toast.makeText(EmanVideoActivity.this, "Send Command OK.", 0).show();
                } else if (txtnewpwd.getText().toString().equals(txtoldpwd.getText().toString())) {
                    txtdis.setText(EmanVideoActivity.this.getString(R.string.txt_pwdnotsas));
                    txtdis.setVisibility(0);
                } else if (!txtnewpwd.getText().toString().equals(txtnewpws2.getText().toString())) {
                    txtdis.setText(EmanVideoActivity.this.getString(R.string.tips_new_passwords_do_not_match));
                    txtdis.setVisibility(0);
                } else if (txtnewpwd.getText().toString().isEmpty() || txtoldpwd.getText().toString().isEmpty()) {
                    txtdis.setText(EmanVideoActivity.this.getString(R.string.txtpwdnotempty));
                    txtdis.setVisibility(0);
                } else if (txtnewpwd.getText().toString().length() > 20 || txtoldpwd.getText().toString().length() > 20) {
                    txtdis.setText(EmanVideoActivity.this.getString(R.string.txt_pwdtoolong));
                    txtdis.setVisibility(0);
                } else {
                    if (SigCameraService.MainCamera != null) {
                        byte[] bytepwds = new byte[40];
                        String tempstrString = txtoldpwd.getText().toString();
                        System.arraycopy(tempstrString.getBytes(), 0, bytepwds, 0, tempstrString.length());
                        String tempstrString2 = txtnewpwd.getText().toString();
                        if (!tempstrString2.isEmpty()) {
                            System.arraycopy(tempstrString2.getBytes(), 0, bytepwds, 20, tempstrString2.length());
                            SigCameraService.MainCamera.sendIOCtrl(0, AVIOCTRLDEFs.IOTYPE_USER_IPCAM_SETPASSWORD_REQ, bytepwds);
                        }
                    }
                    ModiPwdDialog.dismiss();
                }
            }
        });
        ModiPwdDialog.setCancelable(true);
        ModiPwdDialog.show();
    }

    void ShowAboutDialog() {
        final Dialog AboutDialog = new Dialog(this, R.style.Tips);
        AboutDialog.setContentView(R.layout.activity_about);
        TextView txtTitleTextView = (TextView) AboutDialog.findViewById(R.id.textView2);
        txtTitleTextView.setText(this.aboutString);
        Button btnokk = (Button) AboutDialog.findViewById(R.id.btnSure);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.27
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                AboutDialog.dismiss();
            }
        });
        AboutDialog.setCancelable(true);
        AboutDialog.show();
    }

    void ShowSetMode() {
        if (this.m_dialog != null) {
            this.m_dialog.dismiss();
            this.m_dialog = null;
        }
        this.m_dialog = new Dialog(this, R.style.Tips);
        this.m_dialog.setContentView(R.layout.mydialog);
        ((TextView) this.m_dialog.findViewById(R.id.txtDialogMessage)).setText(R.string.txtInSetMode);
        Button btnButton = (Button) this.m_dialog.findViewById(R.id.dialog_button_ok);
        btnButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.28
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                EmanVideoActivity.this.m_dialog.dismiss();
                EmanVideoActivity.this.StartAPSet();
            }
        });
        Button btnButtonc = (Button) this.m_dialog.findViewById(R.id.dialog_button_cancel);
        btnButtonc.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.29
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                SigCameraService.MainCamera.setUserNeedAP(true);
                EmanVideoActivity.this.m_dialog.dismiss();
            }
        });
        this.m_dialog.setCancelable(true);
        this.m_dialog.show();
    }

    void ShowSetWifi() {
        if (this.m_dialog == null || !this.m_dialog.isShowing()) {
            this.m_dialog = new Dialog(this, R.style.Tips);
            this.m_dialog.setContentView(R.layout.myprogress_dialog);
            TextView txtTitleTextView = (TextView) this.m_dialog.findViewById(R.id.txtDialogTitle);
            txtTitleTextView.setText(getString(R.string.txttips));
            TextView txtMyProgerssMsg = (TextView) this.m_dialog.findViewById(R.id.txtMessage);
            txtMyProgerssMsg.setText(getString(R.string.txtlastModeIsAp));
            RelativeLayout pbdialogBar = (RelativeLayout) this.m_dialog.findViewById(R.id.rlDialogPb);
            pbdialogBar.setVisibility(8);
            Button btnokk = (Button) this.m_dialog.findViewById(R.id.btnSure);
            btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.30
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    EmanVideoActivity.this.m_dialog.dismiss();
                    EmanVideoActivity.this.startActivity(new Intent("android.settings.WIFI_SETTINGS"));
                    EmanVideoActivity.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                }
            });
            this.m_dialog.setCancelable(true);
            this.m_dialog.show();
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveRDTSendFileResult(Camera paramCamera, int iFileKind, int Result, String sfileName, int ikind) {
        if (iFileKind == 0) {
            if (ikind == 8) {
                File file = new File(sfileName);
                Intent localIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file));
                sendBroadcast(localIntent);
            }
        } else if (iFileKind == 11) {
            if (Result > 0) {
                this.handler.sendEmptyMessage(17);
            } else {
                this.handler.sendEmptyMessage(17);
            }
        } else if (iFileKind == 20 && ikind == 6) {
            Bundle localBundle = new Bundle();
            localBundle.putString("PhotoName", sfileName);
            Message localMessage = this.handler.obtainMessage();
            localMessage.what = 18;
            localMessage.setData(localBundle);
            this.handler.sendMessage(localMessage);
        }
    }

    public void DeleteAllAudioFile() {
        File[] files = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/RecvAudio/").listFiles();
        for (File f : files) {
            if (f.isFile()) {
                f.delete();
            }
        }
    }

    private Bitmap addBigFrame(Bitmap bm, int res) {
        Bitmap bitmap = decodeBitmap(res);
        Bitmap b = resizeBitmap(bitmap, bm.getWidth(), bm.getHeight());
        Drawable[] array = {new BitmapDrawable(getResources(), bm), new BitmapDrawable(getResources(), b)};
        LayerDrawable layer = new LayerDrawable(array);
        return drawableToBitmap(layer);
    }

    public static Bitmap resizeBitmap(Bitmap bm, int w, int h) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = w / width;
        float scaleHeight = h / height;
        Matrix matrix = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);
        return Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
    }

    private Bitmap drawableToBitmap(Drawable drawable) {
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), drawable.getOpacity() != -1 ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    private Bitmap decodeBitmap(int res) {
        return BitmapFactory.decodeResource(getResources(), res);
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4 && !getSlidingMenu().isMenuShowing()) {
            if (this.m_dialog != null) {
                this.m_dialog.dismiss();
                this.m_dialog = null;
            }
            this.m_dialog = new Dialog(this, R.style.Tips);
            this.m_dialog.setContentView(R.layout.mydialog);
            Button btnButton = (Button) this.m_dialog.findViewById(R.id.dialog_button_ok);
            btnButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.31
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    EmanVideoActivity.this.m_dialog.dismiss();
                    EmanVideoActivity.this.blnRealyExit = true;
                    EmanVideoActivity.this.finish();
                }
            });
            Button btnButtonc = (Button) this.m_dialog.findViewById(R.id.dialog_button_cancel);
            btnButtonc.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.32
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    EmanVideoActivity.this.m_dialog.dismiss();
                }
            });
            this.m_dialog.show();
        }
        return super.onKeyDown(keyCode, event);
    }

    private void ShowProgressbarNotClear() {
        if (this.tmShowProgressbar != null) {
            this.tmShowProgressbar.cancel();
            this.tmShowProgressbar.purge();
            this.tmShowProgressbar = null;
        }
        this.tmShowProgressbar = new Timer();
        this.tmShowProgressbar.schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.33
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                EmanVideoActivity.this.runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.33.1
                    @Override // java.lang.Runnable
                    public void run() {
                        EmanVideoActivity.this.bgConnect.setProgress(-1);
                    }
                });
            }
        }, 10L, 10L);
    }

    private void ShowProgressbarFast() {
        if (this.tmShowProgressbar != null) {
            this.tmShowProgressbar.cancel();
            this.tmShowProgressbar.purge();
            this.tmShowProgressbar = null;
        }
        this.tmShowProgressbar = new Timer();
        this.tmShowProgressbar.schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.34
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                if (EmanVideoActivity.this.bgConnect.getProgress() == 360) {
                    EmanVideoActivity.this.tmShowProgressbar.cancel();
                    EmanVideoActivity.this.tmShowProgressbar.purge();
                    EmanVideoActivity.this.tmShowProgressbar = null;
                    return;
                }
                EmanVideoActivity.this.runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.34.1
                    @Override // java.lang.Runnable
                    public void run() {
                        EmanVideoActivity.this.bgConnect.setProgress(EmanVideoActivity.this.bgConnect.getProgress() + 1);
                    }
                });
            }
        }, 5L, 5L);
    }

    private void ShowProgressbar(int i) {
        this.bgConnect.setVisibility(0);
        if (this.tmShowProgressbar != null) {
            this.tmShowProgressbar.cancel();
            this.tmShowProgressbar.purge();
            this.tmShowProgressbar = null;
        }
        if (i == 0) {
            this.bgConnect.setProgress(0);
        }
        this.blnNeedFast = false;
        this.tmShowProgressbar = new Timer();
        this.tmShowProgressbar.schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.35
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                if (EmanVideoActivity.this.bgConnect.getProgress() == 270 || EmanVideoActivity.this.bgConnect.getProgress() == 360) {
                    EmanVideoActivity.this.tmShowProgressbar.cancel();
                    EmanVideoActivity.this.tmShowProgressbar.purge();
                    EmanVideoActivity.this.tmShowProgressbar = null;
                    return;
                }
                EmanVideoActivity.this.runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanVideoActivity.35.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (EmanVideoActivity.this.blnNeedFast.booleanValue()) {
                            if (EmanVideoActivity.this.bgConnect.getProgress() == 271) {
                                EmanVideoActivity.this.bgConnect.setProgress(360);
                                return;
                            } else {
                                EmanVideoActivity.this.bgConnect.setProgress(271);
                                return;
                            }
                        }
                        EmanVideoActivity.this.bgConnect.setProgress(EmanVideoActivity.this.bgConnect.getProgress() + 1);
                    }
                });
            }
        }, 100L, 166L);
    }

    public void HideBtns() {
        this.btnLandOrPort.setVisibility(4);
        this.btnRecharge.setVisibility(4);
        this.btnAudioOff.setVisibility(4);
        this.btnplay.setVisibility(4);
        this.btn_flash.setVisibility(4);
    }

    private void ShowBtns() {
        this.btnLandOrPort.setVisibility(0);
        this.btnRecharge.setVisibility(0);
        this.btnAudioOff.setVisibility(0);
        this.btnplay.setVisibility(0);
        this.btn_flash.setVisibility(0);
    }

    private void hideAllbtns() {
        this.llyt_expression.setVisibility(4);
        this.btnExpression.setBackgroundResource(R.drawable.face);
        this.rl_light.setVisibility(4);
        if (blnLandBoolean) {
            HideBtns();
            return;
        }
        this.llyt_rightbtns.setVisibility(4);
        this.rltupdown.setVisibility(4);
        this.rltupdown.setVisibility(4);
    }

    public void onHideDisplayUpDown(View v) {
        if (this.bgConnect.getVisibility() != 0) {
            if (this.llyt_expression.getVisibility() == 0) {
                this.handler.removeCallbacks(this.runnablehideFace);
                runOnUiThread(this.runnablehideFace);
                Log.e(tag, "llyt_expression.getVisibility()==View.VISIBLE");
                return;
            }
            this.handler.removeCallbacks(this.runnableHideupdwon);
            if (this.rl_light.getVisibility() == 4) {
                this.rl_light.setVisibility(0);
            } else {
                this.rl_light.setVisibility(4);
            }
            if (blnLandBoolean) {
                if (this.btnAudioOff.getVisibility() == 4) {
                    ShowBtns();
                    this.handler.postDelayed(this.runnableHideupdwon, 4000L);
                } else {
                    HideBtns();
                }
                if (SigCameraService.MainCamera.GetRecording()) {
                    if (this.rl_light.getVisibility() == 4) {
                        this.rtRecDisplay.setVisibility(0);
                    } else {
                        this.rtRecDisplay.setVisibility(4);
                    }
                }
            } else if (this.llyt_rightbtns.getVisibility() == 4) {
                this.llyt_rightbtns.setAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_in_right2));
                this.llyt_rightbtns.setVisibility(0);
                this.rltupdown.setAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_in_left2));
                this.rltupdown.setVisibility(0);
                this.handler.postDelayed(this.runnableHideupdwon, 4000L);
            } else {
                this.llyt_rightbtns.setAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_out_right2));
                this.llyt_rightbtns.setVisibility(4);
                this.rltupdown.setAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_out_left2));
                this.rltupdown.setVisibility(4);
            }
        }
    }
}
