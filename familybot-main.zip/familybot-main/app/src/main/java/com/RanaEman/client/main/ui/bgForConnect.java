package com.RanaEman.client.main.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import com.Robot.client.main.R;

/* loaded from: classes.dex */
public class bgForConnect extends View {
    int iDegree;
    int iProgerss;

    public bgForConnect(Context context) {
        super(context);
        this.iProgerss = 0;
        this.iDegree = 0;
    }

    public bgForConnect(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
        this.iProgerss = 0;
        this.iDegree = 0;
    }

    public bgForConnect(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.iProgerss = 0;
        this.iDegree = 0;
    }

    @Override // android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(getResources().getColor(R.color.bg_color));
        paint.setStrokeWidth(8.0f);
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setStyle(Paint.Style.STROKE);
        float offset = WelcomeActivity.density * 20.0f;
        float ss = getHeight() < getWidth() ? getHeight() : getWidth();
        RectF oval1 = new RectF(((getWidth() - ss) / 2.0f) + offset, offset, ((getWidth() + ss) / 2.0f) - offset, ss - offset);
        canvas.drawArc(oval1, -90.0f, 360.0f, false, paint);
        paint.setStrokeWidth(9.0f);
        paint.setColor(getResources().getColor(R.color.progress_pos));
        if (this.iProgerss == -1) {
            canvas.drawArc(oval1, this.iDegree - 90, 270.0f, false, paint);
            this.iDegree++;
            if (this.iDegree > 360) {
                this.iDegree = 0;
                return;
            }
            return;
        }
        canvas.drawArc(oval1, -90.0f, this.iProgerss, false, paint);
    }

    public void setProgress(int i) {
        this.iProgerss = i;
        invalidate();
    }

    public int getProgress() {
        return this.iProgerss;
    }
}
