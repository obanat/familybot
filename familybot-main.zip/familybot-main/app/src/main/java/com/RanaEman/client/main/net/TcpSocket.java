package com.RanaEman.client.main.net;

import com.tutk.IOTC.AVAPIs;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;

/* loaded from: classes.dex */
public class TcpSocket {
    static boolean lock;
    Socket socket;

    TcpSocket() {
        this.socket = null;
    }

    public TcpSocket(Socket sock) {
        this.socket = sock;
    }

    public TcpSocket(IpAddress ipaddr, int port) throws IOException {
        this.socket = new Socket();
        if (lock) {
            throw new IOException();
        }
        lock = true;
        try {
            this.socket.connect(new InetSocketAddress(ipaddr.toString(), port), Thread.currentThread().getName().equals("main") ? AVAPIs.TIME_SPAN_LOSED : 10000);
            lock = false;
        } catch (IOException e) {
            lock = false;
            throw e;
        }
    }

    public void close() throws IOException {
        this.socket.close();
    }

    public IpAddress getAddress() {
        return new IpAddress(this.socket.getInetAddress());
    }

    public InputStream getInputStream() throws IOException {
        return this.socket.getInputStream();
    }

    public IpAddress getLocalAddress() {
        return new IpAddress(this.socket.getLocalAddress());
    }

    public int getLocalPort() {
        return this.socket.getLocalPort();
    }

    public OutputStream getOutputStream() throws IOException {
        return this.socket.getOutputStream();
    }

    public int getPort() {
        return this.socket.getPort();
    }

    public int getSoTimeout() throws SocketException {
        return this.socket.getSoTimeout();
    }

    public void setSoTimeout(int timeout) throws SocketException {
        this.socket.setSoTimeout(timeout);
    }

    public String toString() {
        return this.socket.toString();
    }
}
