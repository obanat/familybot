package com.RanaEman.client.main.exchange;

import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;

/* loaded from: classes.dex */
public class DvrIniPacket extends BasePacket {
    public DvrIniPacket() {
        this.nLen = 772;
        this.packet = new byte[this.nLen];
    }

    public DvrIniPacket(int iLen) {
        this.nLen = iLen;
        this.packet = new byte[this.nLen];
    }

    public void setPacketHead(byte[] header, int ilength) {
        System.arraycopy(header, 0, this.packet, 4, ilength);
    }

    public String GetDvrName() {
        byte[] name = new byte[36];
        System.arraycopy(this.packet, 16, name, 0, 36);
        if (name[0] == 0 && name[1] == 0) {
            return BuildConfig.FLAVOR;
        }
        String nameString = new String(name);
        return nameString.trim();
    }

    public void setDvrName(String dvrNaem) {
        byte[] sname = dvrNaem.getBytes();
        int iLen = sname.length;
        if (iLen > 36) {
            iLen = 36;
        }
        System.arraycopy(sname, 0, this.packet, 16, iLen);
    }

    public void setCharStr(byte[] chars, int istr) {
        System.arraycopy(chars, 0, this.packet, istr, chars.length);
    }

    public void setCharStr(byte[] chars, int istr, int ilen) {
        System.arraycopy(chars, 0, this.packet, istr, ilen);
    }

    public void setTaskID(int iTaskID) {
        setInt(iTaskID, this.packet, 0, 4);
    }
}
