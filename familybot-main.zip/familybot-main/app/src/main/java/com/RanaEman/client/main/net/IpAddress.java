package com.RanaEman.client.main.net;

import java.net.InetAddress;
import java.net.UnknownHostException;

/* loaded from: classes.dex */
public class IpAddress {
    public static String localIpAddress = "127.0.0.1";
    String address;
    InetAddress inet_address;

    public IpAddress(InetAddress iaddress) {
        init(null, iaddress);
    }

    private void init(String address, InetAddress iaddress) {
        this.address = address;
        this.inet_address = iaddress;
    }

    public InetAddress getInetAddress() {
        if (this.inet_address == null) {
            try {
                this.inet_address = InetAddress.getByName(this.address);
            } catch (UnknownHostException e) {
                this.inet_address = null;
            }
        }
        return this.inet_address;
    }

    public IpAddress(String address) {
        init(address, null);
    }

    public IpAddress(IpAddress ipaddr) {
        init(ipaddr.address, ipaddr.inet_address);
    }

    public Object clone() {
        return new IpAddress(this);
    }

    public boolean equals(Object obj) {
        try {
            IpAddress ipaddr = (IpAddress) obj;
            return toString().equals(ipaddr.toString());
        } catch (Exception e) {
            return false;
        }
    }

    public String toString() {
        if (this.address == null && this.inet_address != null) {
            this.address = this.inet_address.getHostAddress();
        }
        return this.address;
    }

    public static IpAddress getByName(String host_addr) throws UnknownHostException {
        InetAddress iaddr = InetAddress.getByName(host_addr);
        return new IpAddress(iaddr);
    }

    public static void setLocalIpAddress() {
        localIpAddress = "127.0.0.1";
    }
}
