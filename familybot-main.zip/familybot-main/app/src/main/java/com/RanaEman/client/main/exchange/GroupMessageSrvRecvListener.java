package com.RanaEman.client.main.exchange;

import java.util.Map;

/* loaded from: classes.dex */
public interface GroupMessageSrvRecvListener {
    void OnConnectionTerminated(String str, int i, String str2);

    void OnGroupMessageRecv(String str, Map<String, Object> map);

    void OnSrvDown();
}
