package com.RanaEman.client.main.data;

/* loaded from: classes.dex */
public class OnlineData {
    public String ip;
    public long lastCmdTime;
    public String mac;
    public String port;
    public String proto;
}
