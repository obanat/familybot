package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class DvrSetPacket extends BasePacket {
    public DvrSetPacket() {
        this.nLen = 368;
        this.packet = new byte[this.nLen];
    }

    public void setDvrName(String dvrNaem) {
        byte[] sname = dvrNaem.getBytes();
        System.arraycopy(sname, 0, this.packet, 0, sname.length);
    }

    public void setCharStr(byte[] chars, int istr, int ilength) {
        System.arraycopy(chars, 0, this.packet, istr, ilength);
    }
}
