package com.RanaEman.client.main.data;

/* loaded from: classes.dex */
public class localDvrItem implements Comparable<localDvrItem> {
    public int always_veritypwd;
    public int device_type;
    public String dvr_id;
    public String dvr_mac;
    public String dvr_name;
    public int dvr_no;
    public String dvr_pwd;
    public String dvr_username;
    public int iBat;
    public int last_activetime;
    public int status;

    public Integer getOrder() {
        return Integer.valueOf(this.status);
    }

    public String toString() {
        return this.dvr_name;
    }

    @Override // java.lang.Comparable
    public int compareTo(localDvrItem arg0) {
        return -getOrder().compareTo(arg0.getOrder());
    }
}
