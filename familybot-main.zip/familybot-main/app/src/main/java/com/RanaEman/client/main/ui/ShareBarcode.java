package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.Robot.client.main.R;

/* loaded from: classes.dex */
public class ShareBarcode extends Activity {
    Button btnCloseButton;
    private ImageView qrImgImageView;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_barcode);
        this.qrImgImageView = (ImageView) findViewById(R.id.iv_qr_image);
        this.btnCloseButton = (Button) findViewById(R.id.btnClose);
        this.btnCloseButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.ShareBarcode.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ShareBarcode.this.finish();
            }
        });
    }
}
