package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class CmdParam {
    public static final String FormatJson = "FormatJson";
    public static final String FormatNormal = "FormatNormal";
    public static final String cmd = "cmd";
    public static final String cmdFormat = "cmdFormat";
    public static final String content = "content";
    public static final String deviceIp = "deviceIp";
    public static final String deviceList = "deviceList";
    public static final String deviceMac = "deviceMac";
    public static final String deviceName = "deviceName";
    public static final String devicePort = "devicePort";
    public static final String deviceType = "deviceType";
    public static final String deviceType_android = "2";
    public static final String deviceType_dvr = "1";
    public static final String deviceType_host = "9";
    public static final String deviceType_ipc = "0";
    public static final String deviceType_iphone = "3";
    public static final String ip = "ip";
    public static final String ipcip = "ipcip";
    public static final String ipcmac = "ipcmac";
    public static final String isResp = "isResp";
    public static final String mac = "mac";
    public static final String onlineStatus = "onlineStatus";
    public static final String opDoorPwd = "opDoorPwd";
    public static final String phoneNumber = "phoneNumber";
    public static final String port = "port";
    public static final String proto = "proto";
    public static final String reason = "reason";
    public static final String reasonCode = "reasonCode";
    public static final String recvData = "recvData";
    public static final String resultCode = "resultCode";
    public static final String sndResultType = "sndResultType";
    public static final String taskId = "taskId";
    public static final String tcp = "tcp";
    public static final String tcpPort = "tcpPort";
    public static final String time = "time";
    public static final String udp = "udp";
    public static final String workStatus = "workStatus";
}
