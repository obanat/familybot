package com.RanaEman.client.main.net;

import java.io.IOException;
import java.io.InterruptedIOException;

/* loaded from: classes.dex */
public class UdpProvider extends Thread {
    public static final int BUFFER_SIZE = 65535;
    public static final int DEFAULT_SOCKET_TIMEOUT = 2000;
    long alive_time;
    boolean is_running;
    UdpProviderListener listener;
    int minimum_length;
    UdpSocket socket;
    int socket_timeout;
    boolean stop;

    public UdpProvider(UdpSocket socket, UdpProviderListener listener) {
        init(socket, 0L, listener);
        start();
    }

    public UdpProvider(UdpSocket socket, long alive_time, UdpProviderListener listener) {
        init(socket, alive_time, listener);
        start();
    }

    private void init(UdpSocket socket, long alive_time, UdpProviderListener listener) {
        this.listener = listener;
        this.socket = socket;
        this.socket_timeout = 2000;
        this.alive_time = alive_time;
        this.minimum_length = 0;
        this.stop = false;
        this.is_running = true;
    }

    public UdpSocket getUdpSocket() {
        return this.socket;
    }

    public boolean isRunning() {
        return this.is_running;
    }

    public void setSoTimeout(int timeout) {
        this.socket_timeout = timeout;
    }

    public int getSoTimeout() {
        return this.socket_timeout;
    }

    public void setMinimumReceivedDataLength(int len) {
        this.minimum_length = len;
    }

    public int getMinimumReceivedDataLength() {
        return this.minimum_length;
    }

    public void send(UdpPacket packet) throws IOException {
        if (!this.stop) {
            this.socket.send(packet);
        }
    }

    public void halt() {
        this.stop = true;
        this.socket.close();
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        byte[] buf = new byte[65535];
        UdpPacket packet = new UdpPacket(buf, buf.length);
        Exception error = null;
        long expire = 0;
        if (this.alive_time > 0) {
            expire = System.currentTimeMillis() + this.alive_time;
        }
        while (!this.stop) {
            try {
                try {
                    this.socket.receive(packet);
                    if (packet.getLength() >= this.minimum_length) {
                        if (this.listener != null) {
                            this.listener.onReceivedPacket(this, packet);
                        }
                        if (this.alive_time > 0) {
                            expire = System.currentTimeMillis() + this.alive_time;
                        }
                    }
                    packet = new UdpPacket(buf, buf.length);
                } catch (InterruptedIOException e) {
                    if (this.alive_time > 0 && System.currentTimeMillis() > expire) {
                        halt();
                    }
                }
            } catch (Exception e2) {
                error = e2;
                this.stop = true;
            }
        }
        this.is_running = false;
        if (this.listener != null) {
            this.listener.onServiceTerminated(this, error);
        }
        this.listener = null;
    }

    @Override // java.lang.Thread
    public String toString() {
        return "udp:" + this.socket.getLocalAddress() + ":" + this.socket.getLocalPort();
    }
}
