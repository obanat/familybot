package com.RanaEman.client.main.net;

/* loaded from: classes.dex */
public interface TcpConnectionListener {
    void onConnectionTerminated(TcpConnection tcpConnection, Exception exc);

    void onReceivedData(TcpConnection tcpConnection, byte[] bArr, int i);
}
