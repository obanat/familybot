package com.RanaEman.client.main.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.Robot.client.main.R;

/* loaded from: classes.dex */
public class Dialog_modiPwd extends Activity {
    Button btnOK;
    Button btncancle;
    EditText txtnewpwd;
    EditText txtnewpws2;
    EditText txtoldpwd;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_modi_pwd);
        this.txtoldpwd = (EditText) findViewById(R.id.txtoldPwd);
        this.txtnewpwd = (EditText) findViewById(R.id.txtnewpwd1);
        this.txtnewpws2 = (EditText) findViewById(R.id.txtnewpwd2);
        this.btncancle = (Button) findViewById(R.id.btn_cancelconn);
        this.btncancle.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Dialog_modiPwd.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Dialog_modiPwd.this.finish();
            }
        });
        this.btnOK = (Button) findViewById(R.id.btn_ModiPwd);
        this.btnOK.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Dialog_modiPwd.2
            @Override // android.view.View.OnClickListener
            @SuppressLint({"NewApi"})
            public void onClick(View v) {
                AlertDialog.Builder bldBuilder = new AlertDialog.Builder(Dialog_modiPwd.this);
                bldBuilder.setPositiveButton(Dialog_modiPwd.this.getString(R.string.confirm), new DialogInterface.OnClickListener() { // from class: com.RanaEman.client.main.ui.Dialog_modiPwd.2.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                if (Dialog_modiPwd.this.txtnewpwd.getText().toString().equals(Dialog_modiPwd.this.txtoldpwd.getText().toString())) {
                    bldBuilder.setTitle(Dialog_modiPwd.this.getString(R.string.txttips));
                    bldBuilder.setMessage(Dialog_modiPwd.this.getString(R.string.txt_pwdnotsas));
                    bldBuilder.show();
                } else if (!Dialog_modiPwd.this.txtnewpwd.getText().toString().equals(Dialog_modiPwd.this.txtnewpws2.getText().toString())) {
                    bldBuilder.setTitle(Dialog_modiPwd.this.getString(R.string.txttips));
                    bldBuilder.setMessage(Dialog_modiPwd.this.getString(R.string.tips_new_passwords_do_not_match));
                    bldBuilder.show();
                } else if (Dialog_modiPwd.this.txtnewpwd.getText().toString().isEmpty() || Dialog_modiPwd.this.txtoldpwd.getText().toString().isEmpty()) {
                    bldBuilder.setTitle(Dialog_modiPwd.this.getString(R.string.txttips));
                    bldBuilder.setMessage(Dialog_modiPwd.this.getString(R.string.txtpwdnotempty));
                    bldBuilder.show();
                } else if (Dialog_modiPwd.this.txtnewpwd.getText().toString().length() > 20 || Dialog_modiPwd.this.txtoldpwd.getText().toString().length() > 20) {
                    bldBuilder.setTitle(Dialog_modiPwd.this.getString(R.string.txttips));
                    bldBuilder.setMessage(Dialog_modiPwd.this.getString(R.string.txt_pwdtoolong));
                    bldBuilder.show();
                } else {
                    Intent resultIntent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putString("OLDPWD", Dialog_modiPwd.this.txtoldpwd.getText().toString());
                    bundle.putString("NEWPWD", Dialog_modiPwd.this.txtnewpwd.getText().toString());
                    resultIntent.putExtras(bundle);
                    Dialog_modiPwd.this.setResult(-1, resultIntent);
                    Dialog_modiPwd.this.finish();
                }
            }
        });
    }
}
