package com.RanaEman.client.main.data;

/* loaded from: classes.dex */
public class DeviceItem {
    public int device_id;
    public int device_type;
    public String mac;
    public String name;
    public String phone_number;
    public int status;

    public String toString() {
        return this.name;
    }
}
