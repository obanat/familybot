package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.RanaEman.client.main.SigCameraService;
import com.RanaEman.client.main.data.DataCenter;
import com.RanaEman.client.main.data.localDvrItem;
import com.RanaEman.client.main.exchange.CmdParam;
import com.Robot.client.main.R;
import com.google.zxing.client.androidlegacy.CaptureActivity;
import com.google.zxing.client.androidlegacy.Intents;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import com.tutk.IOTC.AVAPIs;
import com.tutk.IOTC.AVIOCTRLDEFs;
import com.tutk.IOTC.Camera;
import com.tutk.IOTC.st_LanSearchInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes.dex */
public class EmanWizzard extends Activity {
    Button btn2DBarcode;
    Button btnBack;
    Button btnResearch;
    List<WifiConfiguration> configurations;
    ImageView imgNoEmain;
    LinearLayout llybtns;
    ProgressBar pbMain;
    List<ScanResult> results;
    TextView tvMain;
    TextView tvStatus;
    boolean IsResearching = false;
    boolean blnFindDvr = false;
    boolean blnIsRegedWifiBC = false;
    boolean blnDvrconning = false;
    private List<SearchResult> listLanSearch = new ArrayList();
    WifiManager wifiManager = null;
    int icurNetWorkID = -1;
    int ipreWifiNetworkID = -1;
    String preWifiMac = null;
    String radgogMac = null;
    int iFromWhat = 0;
    Boolean blnFindNew = false;
    Handler handler = new Handler() { // from class: com.RanaEman.client.main.ui.EmanWizzard.5
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    EmanWizzard.this.imgNoEmain.setVisibility(0);
                    EmanWizzard.this.tvMain.setText(EmanWizzard.this.getResources().getString(R.string.txtnodevicefound2));
                    EmanWizzard.this.tvStatus.setVisibility(4);
                    EmanWizzard.this.pbMain.setVisibility(4);
                    EmanWizzard.this.llybtns.setVisibility(0);
                    if (EmanWizzard.this.blnFindNew.booleanValue() && EmanWizzard.this.iFromWhat != 0) {
                        EmanWizzard.this.finish();
                        EmanWizzard.this.overridePendingTransition(17432578, 17432579);
                        break;
                    }
                    break;
                case 1:
                    int iSize = EmanWizzard.this.listLanSearch.size();
                    String sFirstUID = EmanWizzard.this.GetDefaultUID();
                    if (iSize > 0) {
                        for (int i = 0; i < iSize; i++) {
                            localDvrItem itemp = new localDvrItem();
                            itemp.always_veritypwd = 1;
                            itemp.device_type = 0;
                            itemp.dvr_id = ((SearchResult) EmanWizzard.this.listLanSearch.get(i)).UID;
                            itemp.dvr_mac = CmdParam.deviceType_ipc;
                            if (DataCenter.localdvritems.size() == 0) {
                                itemp.dvr_name = "Robot";
                            } else {
                                itemp.dvr_name = "Robot" + (DataCenter.localdvritems.size() + 1);
                            }
                            itemp.dvr_pwd = "123456789";
                            itemp.dvr_username = "Admin";
                            DataCenter.adddvrItem2DB(itemp);
                            EmanWizzard.this.blnFindNew = true;
                            sFirstUID = itemp.dvr_id;
                        }
                        if (EmanWizzard.this.blnFindNew.booleanValue()) {
                            String sDBUID = DataCenter.GetAllLocalDVRFromDB(sFirstUID);
                            if (sDBUID != null) {
                                Intent intent = new Intent();
                                intent.setAction(SigCameraService.ACTION_ADDUID);
                                intent.putExtra("UID", sDBUID);
                                EmanWizzard.this.sendBroadcast(intent);
                            }
                            EmanWizzard.this.finishedDelay(AVAPIs.TIME_DELAY_MAX);
                            break;
                        }
                    } else {
                        EmanWizzard.this.handler.sendEmptyMessage(0);
                        break;
                    }
                    break;
                case 2:
                    Bundle dataBundle = msg.getData();
                    EmanWizzard.this.tvMain.setText(dataBundle.getString("MsgTxt"));
                    EmanWizzard.this.tvStatus.setVisibility(4);
                    break;
                case 3:
                    String sThisUIDString = msg.getData().getString("UID");
                    String sDBUID2 = DataCenter.GetAllLocalDVRFromDB(sThisUIDString);
                    if (sDBUID2 != null) {
                        Intent intent2 = new Intent();
                        intent2.setAction(SigCameraService.ACTION_ADDUID);
                        intent2.putExtra("UID", sDBUID2);
                        EmanWizzard.this.sendBroadcast(intent2);
                    }
                    EmanWizzard.this.finishedDelay(AVAPIs.TIME_DELAY_MAX);
                    break;
                case 4:
                    EmanWizzard.this.tvMain.setText(EmanWizzard.this.getResources().getString(R.string.txtfounddevice));
                    EmanWizzard.this.tvStatus.setText(EmanWizzard.this.getResources().getString(R.string.connstus_connecting));
                    break;
                case 5:
                    EmanWizzard.this.tvMain.setText(EmanWizzard.this.getResources().getString(R.string.txtresearchInAP));
                    EmanWizzard.this.tvStatus.setText(EmanWizzard.this.getResources().getString(R.string.txtResearch));
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private BroadcastReceiver ConnDVR_Receiver = new BroadcastReceiver() { // from class: com.RanaEman.client.main.ui.EmanWizzard.7
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String stext;
            if (intent.getAction().equals("android.net.wifi.STATE_CHANGE")) {
                Parcelable parcelableExtra = intent.getParcelableExtra("networkInfo");
                NetworkInfo networkInfo = (NetworkInfo) parcelableExtra;
                NetworkInfo.DetailedState istateDetailedState = networkInfo.getDetailedState();
                Log.e("Test", "NETWORK_STATE_CHANGED_ACTION。广播");
                if (networkInfo.isConnected()) {
                    Log.e("Test", "NETWORK_STATE_CHANGED_ACTION。已经连接");
                    WifiInfo curInfo = EmanWizzard.this.wifiManager.getConnectionInfo();
                    String curssid = curInfo.getSSID();
                    String curMac = curInfo.getBSSID();
                    if (curssid != null) {
                        EmanWizzard.this.icurNetWorkID = -1;
                        Intent DvrIniSetintent = new Intent(EmanWizzard.this, Eman_APSet.class);
                        DvrIniSetintent.putExtra("mac", curMac);
                        EmanWizzard.this.startActivityForResult(DvrIniSetintent, 0);
                        EmanWizzard.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        EmanWizzard.this.unReg_BC_Rec_ConnDvr();
                        Log.e("Test", "注销广播");
                        Log.e("Test", "通过NETWORK_STATE_CHANGED_ACTION进入");
                        return;
                    }
                }
                switch (AnonymousClass11.$SwitchMap$android$net$NetworkInfo$DetailedState[istateDetailedState.ordinal()]) {
                    case 1:
                        stext = "网络连接已建立，开始身份认证。";
                        break;
                    case 2:
                        stext = "Access to this network is blocked。";
                        break;
                    case 3:
                        stext = "Checking if network is a captive portal。";
                        break;
                    case 4:
                        stext = "IP数据流可用。";
                        break;
                    case 5:
                        stext = "开始创建数据连接。";
                        break;
                    case 6:
                        stext = "IP数据流不可用。";
                        break;
                    case 7:
                        stext = "开始拆除数据连接。";
                        break;
                    case 8:
                        stext = "尝试连接失败。";
                        break;
                    case 9:
                        stext = "数据连接设置完成。";
                        break;
                    case 10:
                        stext = "等待DHCP服务器的响应，以分配IP地址信息。";
                        break;
                    case 11:
                        stext = "正在寻找可用的接入点。";
                        break;
                    case 12:
                        stext = "IP数据流被挂起。";
                        break;
                    case 13:
                        stext = "Link has poor connectivity。";
                        break;
                    default:
                        stext = "未知状态。";
                        break;
                }
                Log.e("Test", stext);
            } else if (intent.getAction().equals("android.net.wifi.SCAN_RESULTS")) {
                Log.e("Test", "wifi扫描结果");
                if (EmanWizzard.this.icurNetWorkID >= 0) {
                    Log.e("Test", "正在设置。。。");
                    return;
                }
                EmanWizzard.this.results = EmanWizzard.this.wifiManager.getScanResults();
                String ssidString = BuildConfig.FLAVOR;
                EmanWizzard.this.blnFindDvr = false;
                for (int i = 0; i < EmanWizzard.this.results.size(); i++) {
                    ssidString = EmanWizzard.this.results.get(i).SSID;
                    if (ssidString.equalsIgnoreCase("Bayper") || ssidString.equalsIgnoreCase("Robot") || ssidString.equalsIgnoreCase("Robotset") || ssidString.equalsIgnoreCase("Family Robot")) {
                        EmanWizzard.this.blnFindDvr = true;
                        EmanWizzard.this.radgogMac = EmanWizzard.this.results.get(i).BSSID.toString();
                        Log.e("Test", "找到radog");
                        break;
                    }
                }
                WifiInfo curInfo2 = EmanWizzard.this.wifiManager.getConnectionInfo();
                curInfo2.getSSID();
                String curMac2 = curInfo2.getBSSID();
                if (curMac2 != null && curMac2.equals(EmanWizzard.this.radgogMac)) {
                    EmanWizzard.this.icurNetWorkID = -1;
                    Intent DvrIniSetintent2 = new Intent(EmanWizzard.this, Eman_APSet.class);
                    DvrIniSetintent2.putExtra("mac", curMac2);
                    EmanWizzard.this.startActivityForResult(DvrIniSetintent2, 0);
                    EmanWizzard.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    EmanWizzard.this.unReg_BC_Rec_ConnDvr();
                    Log.e("Test", "注销广播");
                    Log.e("Test", "通过SCAN_RESULTS_AVAILABLE_ACTION进入");
                } else if (EmanWizzard.this.blnFindDvr) {
                    EmanWizzard.this.handler.sendEmptyMessage(4);
                    if (WelcomeActivity.myDeviceAPILevel < 11) {
                        EmanWizzard.this.SetIP_Static(true);
                    }
                    EmanWizzard.this.configurations = EmanWizzard.this.wifiManager.getConfiguredNetworks();
                    int networkId = -1;
                    Log.e("Test", "已经搜索到RaDog，正在尝试连接RaDog");
                    for (int i2 = EmanWizzard.this.configurations.size() - 1; i2 >= 0; i2--) {
                        WifiConfiguration config = EmanWizzard.this.configurations.get(i2);
                        if (config.SSID.equalsIgnoreCase("Bayper") || config.SSID.equalsIgnoreCase("Robot") || config.SSID.equalsIgnoreCase("Robotset") || config.SSID.equalsIgnoreCase("Family Robot")) {
                            networkId = config.networkId;
                            EmanWizzard.this.wifiManager.removeNetwork(networkId);
                            Log.e("Test", "存在已经保存的RADOGAP设置。");
                            break;
                        }
                    }
                    if (0 == 0) {
                        WifiConfiguration radogConfiguration = new WifiConfiguration();
                        radogConfiguration.SSID = "\"" + ssidString + "\"";
                        radogConfiguration.preSharedKey = "\"12345678\"";
                        radogConfiguration.hiddenSSID = false;
                        radogConfiguration.priority = 30;
                        radogConfiguration.status = 2;
                        radogConfiguration.allowedAuthAlgorithms.set(0);
                        radogConfiguration.allowedGroupCiphers.set(3);
                        radogConfiguration.allowedGroupCiphers.set(2);
                        radogConfiguration.allowedGroupCiphers.set(1);
                        radogConfiguration.allowedGroupCiphers.set(0);
                        radogConfiguration.allowedPairwiseCiphers.set(1);
                        radogConfiguration.allowedPairwiseCiphers.set(2);
                        radogConfiguration.allowedPairwiseCiphers.set(0);
                        radogConfiguration.allowedProtocols.set(0);
                        radogConfiguration.allowedProtocols.set(1);
                        networkId = EmanWizzard.this.wifiManager.addNetwork(radogConfiguration);
                        Log.e("Test", "没有保存的RADOGAP设置。");
                        if (networkId != -1) {
                            EmanWizzard.this.wifiManager.saveConfiguration();
                            Log.e("Test", "保存RADOGAP设置成功。");
                        }
                    }
                    if (networkId != -1) {
                        if (!EmanWizzard.this.blnDvrconning) {
                            EmanWizzard.this.wifiManager.disconnect();
                            EmanWizzard.this.wifiManager.enableNetwork(networkId, true);
                            EmanWizzard.this.icurNetWorkID = networkId;
                            EmanWizzard.this.blnDvrconning = true;
                            Log.e("Test", "断开网络，连接radog。");
                            return;
                        }
                        Log.e("Test", "正在连接radog，无需再次连接。");
                    }
                } else {
                    EmanWizzard.this.blnFindDvr = false;
                    EmanWizzard.this.blnDvrconning = false;
                    EmanWizzard.this.handler.sendEmptyMessage(0);
                    Log.e("Test", "没有找到任何RaDog全景摄像机。");
                    EmanWizzard.this.unReg_BC_Rec_ConnDvr();
                    Log.e("Test", "注销广播。");
                }
            }
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eman_wizzard);
        this.iFromWhat = getIntent().getIntExtra("FromWhat", 1);
        this.imgNoEmain = (ImageView) findViewById(R.id.imageView1);
        this.imgNoEmain.setVisibility(View.INVISIBLE);
        this.tvMain = (TextView) findViewById(R.id.textView1);
        this.tvStatus = (TextView) findViewById(R.id.textView2);
        this.btn2DBarcode = (Button) findViewById(R.id.button1);
        this.btnBack = (Button) findViewById(R.id.btncancel);
        if (this.iFromWhat == 0) {
            this.btnBack.setVisibility(View.INVISIBLE);
        }
        this.btnBack.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanWizzard.1
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                EmanWizzard.this.finish();
                EmanWizzard.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
        this.btn2DBarcode.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanWizzard.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intents.Scan.ACTION);
                intent.putExtra(Intents.Scan.WIDTH, AVIOCTRLDEFs.IOTYPE_USER_IPCAM_SETSTREAMCTRL_REQ);
                intent.putExtra(Intents.Scan.HEIGHT, 600);
                intent.setClass(EmanWizzard.this, CaptureActivity.class);
                EmanWizzard.this.startActivityForResult(intent, 1);
                EmanWizzard.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
        this.llybtns = (LinearLayout) findViewById(R.id.llybtns);
        this.llybtns.setVisibility(4);
        this.btnResearch = (Button) findViewById(R.id.button2);
        this.btnResearch.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanWizzard.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                EmanWizzard.this.imgNoEmain.setVisibility(4);
                EmanWizzard.this.tvMain.setText(EmanWizzard.this.getResources().getString(R.string.txtResearchlong));
                EmanWizzard.this.tvStatus.setVisibility(0);
                EmanWizzard.this.pbMain.setVisibility(0);
                EmanWizzard.this.llybtns.setVisibility(4);
                EmanWizzard.this.ResearchRadog();
            }
        });
        this.pbMain = (ProgressBar) findViewById(R.id.progressBar1);
        this.handler.postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanWizzard.4
            @Override // java.lang.Runnable
            public void run() {

                EmanWizzard.this.ResearchRadog();
            }
        }, 500L);
    }

    public String GetDefaultUID() {
        SharedPreferences preferences = getSharedPreferences(WelcomeActivity.DEFAULT_UID, 0);
        return preferences.getString(WelcomeActivity.DEFAULT_UID_STR, null);
    }

    public void finishedDelay(int iDelayTime) {
        new Handler().postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.EmanWizzard.6
            @Override // java.lang.Runnable
            public void run() {
                if (EmanWizzard.this.iFromWhat == 0) {
                    Intent intentStartVideo = new Intent(EmanWizzard.this, EmanVideoActivity.class);
                    EmanWizzard.this.startActivity(intentStartVideo);
                }
                EmanWizzard.this.setResult(-1);
                EmanWizzard.this.finish();
                EmanWizzard.this.overridePendingTransition(17432578, 17432579);
            }
        }, iDelayTime);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.iFromWhat == 0) {
                ShowQuitDialog();
            } else {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void reg_BC_Rec_ConnDvr() {
        if (!this.blnIsRegedWifiBC) {
            IntentFilter myIntentFilter = new IntentFilter();
            myIntentFilter.addAction("android.net.wifi.SCAN_RESULTS");
            myIntentFilter.addAction("android.net.wifi.STATE_CHANGE");
            registerReceiver(this.ConnDVR_Receiver, myIntentFilter);
            this.blnIsRegedWifiBC = true;
        }
    }

    /* renamed from: com.RanaEman.client.main.ui.EmanWizzard$11 */
    /* loaded from: classes.dex */
    static /* synthetic */ class AnonymousClass11 {
        static final /* synthetic */ int[] $SwitchMap$android$net$NetworkInfo$DetailedState = new int[NetworkInfo.DetailedState.values().length];

        static {
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.AUTHENTICATING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.BLOCKED.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.CAPTIVE_PORTAL_CHECK.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.CONNECTED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.CONNECTING.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.DISCONNECTED.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.DISCONNECTING.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.FAILED.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.IDLE.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.OBTAINING_IPADDR.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.SCANNING.ordinal()] = 11;
            } catch (NoSuchFieldError e11) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.SUSPENDED.ordinal()] = 12;
            } catch (NoSuchFieldError e12) {
            }
            try {
                $SwitchMap$android$net$NetworkInfo$DetailedState[NetworkInfo.DetailedState.VERIFYING_POOR_LINK.ordinal()] = 13;
            } catch (NoSuchFieldError e13) {
            }
        }
    }

    public void unReg_BC_Rec_ConnDvr() {
        if (this.blnIsRegedWifiBC) {
            unregisterReceiver(this.ConnDVR_Receiver);
            this.blnIsRegedWifiBC = false;
        }
    }

    void SetIP_Static(Boolean blnEnable) {
        if (blnEnable.booleanValue()) {
            Settings.System.putString(getContentResolver(), "wifi_use_static_ip", CmdParam.deviceType_dvr);
            Settings.System.putString(getContentResolver(), "wifi_static_dns1", "192.168.100.1");
            Settings.System.putString(getContentResolver(), "wifi_static_gateway", "192.168.100.1");
            Settings.System.putString(getContentResolver(), "wifi_static_netmask", "255.255.255.0");
            Settings.System.putString(getContentResolver(), "wifi_static_ip", "192.168.100.125");
            return;
        }
        Settings.System.putString(getContentResolver(), "wifi_use_static_ip", CmdParam.deviceType_ipc);
        Settings.System.putString(getContentResolver(), "wifi_static_dns1", BuildConfig.FLAVOR);
        Settings.System.putString(getContentResolver(), "wifi_static_gateway", BuildConfig.FLAVOR);
        Settings.System.putString(getContentResolver(), "wifi_static_netmask", BuildConfig.FLAVOR);
        Settings.System.putString(getContentResolver(), "wifi_static_ip", BuildConfig.FLAVOR);
    }

    public void ResearchRadog() {
        if (!this.IsResearching) {
            this.IsResearching = true;
            new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.EmanWizzard.8
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    st_LanSearchInfo[] arrayOfSt_LanSearchResp = Camera.SearchLAN();
                    if (arrayOfSt_LanSearchResp != null && arrayOfSt_LanSearchResp.length > 0) {
                        EmanWizzard.this.listLanSearch.clear();
                        int i = arrayOfSt_LanSearchResp.length;
                        for (st_LanSearchInfo localSt_LanSearchResp : arrayOfSt_LanSearchResp) {
                            if (!DataCenter.localdvritems.containsKey(new String(localSt_LanSearchResp.UID).trim())) {
                                EmanWizzard.this.listLanSearch.add(new SearchResult(new String(localSt_LanSearchResp.UID).trim(), new String(localSt_LanSearchResp.IP).trim(), localSt_LanSearchResp.port));
                            }
                        }
                        Log.e("Search", "count:" + i);
                    } else {
                        Log.e("Search", "NULL:");
                    }
                    EmanWizzard.this.handler.sendEmptyMessage(1);
                    EmanWizzard.this.IsResearching = false;
                }
            }, 200L);
        }
    }

    /* loaded from: classes.dex */
    public class SearchResult {
        public String IP;
        public String UID;

        public SearchResult(String paramString1, String paramString2, int paramInt) {
            //EmanWizzard.this = this$0;
            this.UID = paramString1;
            this.IP = paramString2;
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0) {
            if (WelcomeActivity.myDeviceAPILevel < 11) {
                SetIP_Static(false);
            }
            WifiInfo wifiInfo = this.wifiManager.getConnectionInfo();
            int icur = wifiInfo.getNetworkId();
            if (this.ipreWifiNetworkID == icur) {
                Log.e("Test", "当前网络和之前网络相同无需恢复。");
            } else if (this.ipreWifiNetworkID == -1) {
                Log.e("Test", "设置网络禁止");
                this.wifiManager.setWifiEnabled(false);
            } else {
                Log.e("Test", "恢复网络ID：" + this.ipreWifiNetworkID);
                this.wifiManager.disconnect();
                this.wifiManager.enableNetwork(this.ipreWifiNetworkID, true);
            }
            if (resultCode == -1) {
                int iap = data.getIntExtra("AP", 0);
                Log.e("ap", "AP:" + iap);
                String sUIDString = data.getStringExtra("NewUID");
                if (DataCenter.localdvritems.containsKey(sUIDString)) {
                    if (DataCenter.UpdatelocalDvrFromDB("device_type", String.valueOf(iap), sUIDString)) {
                    }
                    this.handler.sendEmptyMessage(0);
                } else {
                    localDvrItem NewDvrItem = new localDvrItem();
                    NewDvrItem.device_type = iap;
                    NewDvrItem.dvr_mac = CmdParam.deviceType_ipc;
                    NewDvrItem.dvr_id = sUIDString;
                    Log.e("onActivityResult", "GetUID:" + NewDvrItem.dvr_id);
                    NewDvrItem.dvr_name = data.getStringExtra("NewName");
                    if (NewDvrItem.dvr_name.isEmpty()) {
                        NewDvrItem.dvr_name = "Robot" + DataCenter.GetMaxNoFromDB();
                    }
                    NewDvrItem.dvr_pwd = "123456789";
                    NewDvrItem.dvr_username = "Admin";
                    NewDvrItem.last_activetime = 0;
                    NewDvrItem.status = 1;
                    NewDvrItem.always_veritypwd = 1;
                    Log.e("onActivityResult", "准备插入数据库。");
                    Message msgMessage = this.handler.obtainMessage();
                    msgMessage.what = 3;
                    Bundle dataBundle = new Bundle();
                    dataBundle.putString("UID", NewDvrItem.dvr_id);
                    msgMessage.setData(dataBundle);
                    if (DataCenter.adddvrItem2DB(NewDvrItem) == 0) {
                        DataCenter.DelUIDFromDB(NewDvrItem.dvr_id);
                        if (DataCenter.adddvrItem2DB(NewDvrItem) > 0) {
                            this.handler.sendMessage(msgMessage);
                        }
                    } else {
                        this.handler.sendMessage(msgMessage);
                    }
                }
            }
        } else if (requestCode == 1) {
            if (resultCode == -1) {
                String sResult = data.getStringExtra(Intents.Scan.RESULT);
                Message msgMessage2 = this.handler.obtainMessage();
                if (sResult == null) {
                    Bundle dataBundle2 = new Bundle();
                    dataBundle2.putString("MsgTitle", getString(R.string.txtaddfail));
                    dataBundle2.putString("MsgTxt", getString(R.string.txtaddfailmsg));
                    msgMessage2.setData(dataBundle2);
                    this.handler.sendMessage(msgMessage2);
                    return;
                } else if (sResult.length() != 20) {
                    msgMessage2.what = 2;
                    Bundle dataBundle3 = new Bundle();
                    dataBundle3.putString("MsgTitle", getString(R.string.txtaddfail));
                    dataBundle3.putString("MsgTxt", getString(R.string.txtaddfailmsg));
                    msgMessage2.setData(dataBundle3);
                    this.handler.sendMessage(msgMessage2);
                    return;
                } else {
                    localDvrItem NewDvrItem2 = new localDvrItem();
                    NewDvrItem2.device_type = 0;
                    NewDvrItem2.dvr_mac = CmdParam.deviceType_ipc;
                    NewDvrItem2.dvr_id = sResult;
                    Log.e("onActivityResult", "GetUID:" + NewDvrItem2.dvr_id);
                    NewDvrItem2.dvr_name = "Robot" + DataCenter.GetMaxNoFromDB();
                    NewDvrItem2.dvr_pwd = "123456789";
                    NewDvrItem2.dvr_username = "Admin";
                    NewDvrItem2.last_activetime = 0;
                    NewDvrItem2.status = 1;
                    NewDvrItem2.always_veritypwd = 1;
                    Log.e("onActivityResult", "准备插入数据库。");
                    if (DataCenter.adddvrItem2DB(NewDvrItem2) <= 0) {
                        msgMessage2.what = 2;
                        Bundle dataBundle4 = new Bundle();
                        dataBundle4.putString("MsgTitle", getString(R.string.txtaddfail));
                        dataBundle4.putString("MsgTxt", getString(R.string.txtaddfailmsg));
                        msgMessage2.setData(dataBundle4);
                        this.handler.sendMessage(msgMessage2);
                    } else {
                        msgMessage2.what = 3;
                        Bundle dataBundle5 = new Bundle();
                        dataBundle5.putString("UID", NewDvrItem2.dvr_id);
                        msgMessage2.setData(dataBundle5);
                        this.handler.sendMessage(msgMessage2);
                    }
                }
            } else if (522 == resultCode) {
                Log.e("Test", "DIALOG cancel：" + resultCode);
                this.handler.sendEmptyMessage(2);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void ShowQuitDialog() {
        final Dialog dialog = new Dialog(this, R.style.Tips);
        dialog.setContentView(R.layout.mydialog);
        Button btnButton = (Button) dialog.findViewById(R.id.dialog_button_ok);
        btnButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanWizzard.9
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                dialog.dismiss();
                EmanWizzard.this.setResult(-1);
                EmanWizzard.this.finish();
            }
        });
        Button btnButtonc = (Button) dialog.findViewById(R.id.dialog_button_cancel);
        btnButtonc.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.EmanWizzard.10
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
