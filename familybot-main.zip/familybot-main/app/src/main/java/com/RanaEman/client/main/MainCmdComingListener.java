package com.RanaEman.client.main;

import java.util.Map;

/* loaded from: classes.dex */
public interface MainCmdComingListener {
    void onCmdComing(Map<String, Object> map);
}
