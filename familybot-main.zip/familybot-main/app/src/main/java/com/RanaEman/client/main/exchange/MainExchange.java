package com.RanaEman.client.main.exchange;

import android.util.Log;
import com.RanaEman.client.main.net.IpAddress;
import com.RanaEman.client.main.net.TcpServer;
import com.RanaEman.client.main.net.TcpServerListener;
import com.RanaEman.client.main.net.TcpSocket;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/* loaded from: classes.dex */
public class MainExchange implements TcpServerListener, OnExchangeRecvListener {
    private GroupMessageSrvRecvListener messageListener;
    private TcpServer tcpServer;
    public static String EXCHANGE_PROTOCOL_UDP = CmdParam.udp;
    public static String EXCHANGE_PROTOCOL_TCP = CmdParam.tcp;
    private Boolean useUdp = true;
    private Boolean useTcp = true;
    private UdpExchange udpExchange = null;
    private int tcpListenPort = 12903;
    private Hashtable<ExchangeIdentifier, TcpExchange> connections = new Hashtable<>(20);

    public void setMessageSrvRecvListener(GroupMessageSrvRecvListener messageListener) {
        this.messageListener = messageListener;
    }

    public int getTcpListenPort() {
        return this.tcpListenPort;
    }

    public void setUseUdp(Boolean b) {
        this.useUdp = b;
    }

    public void setUseTcp(Boolean b) {
        this.useTcp = b;
    }

    public Boolean startSrv() {
        if (this.useUdp.booleanValue()) {
            if (!startUdpServer().booleanValue()) {
                Log.e("MainExchange", "startUdpServer failed in startSrv");
                return false;
            }
            Log.v("MainExchange", "startUdpServer succeed in startSrv");
        }
        if (this.useTcp.booleanValue()) {
            if (!startTcpServer().booleanValue()) {
                Log.e("MainExchange", "startTcpServer failed in startSrv");
                return false;
            }
            Log.v("MainExchange", "startTcpServer succeed in startSrv");
        }
        return true;
    }

    public Boolean startTcpServer() {
        try {
            this.tcpServer = new TcpServer(this.tcpListenPort, this);
            this.tcpListenPort = this.tcpServer.getPort();
            Log.v("MainExchangeServer", "startTcpServer succeed, host port is :" + String.valueOf(this.tcpListenPort));
            return true;
        } catch (IOException e) {
            Log.v("startTcpServer", "IOException, " + e.getMessage());
            return false;
        }
    }

    public Boolean startUdpServer() {
        this.udpExchange = new UdpExchange();
        this.udpExchange.setOnExchangeRecvListener(this);
        return this.udpExchange.start();
    }

    @Override // com.RanaEman.client.main.exchange.OnExchangeRecvListener
    public void OnExchangeRecv(String rowMessage, String fromIp, String fromPort, String proto) {
        Map<String, Object> mapData = new HashMap<>();
        mapData.put(CmdParam.ip, fromIp);
        mapData.put(CmdParam.port, fromPort);
        mapData.put(CmdParam.proto, proto);
        if (GroupMessageSrvCodec.baseDecode(rowMessage, mapData).booleanValue()) {
            String cmd = (String) mapData.get(CmdParam.cmd);
            if (this.messageListener != null) {
                this.messageListener.OnGroupMessageRecv(cmd, mapData);
                Log.v("MainExchangeServer", "OnExchangeRecv call the OnGroupMessageRecv");
                return;
            }
            Log.v("MainExchangeServer", "OnExchangeRecv but the OnGroupMessageRecv is null");
        }
    }

    public synchronized Boolean sendMessage(ExchangeMessage msg) {
        boolean z;
        if (msg == null) {
            Log.e("MainExchange|sendMessage", "null");
            z = false;
        } else if (!msg.containsKey(CmdParam.ip).booleanValue() || !msg.containsKey(CmdParam.port).booleanValue() || !msg.containsKey(CmdParam.proto).booleanValue()) {
            Log.e("MainExchange|sendMessage", "缺少必要参数1001");
            z = false;
        } else {
            String proto = (String) msg.get(CmdParam.proto);
            IpAddress dest_ipaddr = new IpAddress((String) msg.get(CmdParam.ip));
            String port = (String) msg.get(CmdParam.port);
            int dest_port = Integer.valueOf(port).intValue();
            String textMsg = msg.getTextMessage2Send();
            if (textMsg.length() == 0) {
                Log.e("MainExchange|sendMessage", "getTextMessage2Send failed");
                z = false;
            } else if (proto.equalsIgnoreCase(EXCHANGE_PROTOCOL_UDP)) {
                Log.v("MainExchange|sendMessage", "sendMessage via udp protocol begin");
                if (this.udpExchange == null) {
                    startUdpServer();
                    if (!startUdpServer().booleanValue()) {
                        Log.v("MainExchange|sendMessage", "startUdpServer failed");
                        z = false;
                    }
                }
                z = this.udpExchange.sendMessage(dest_ipaddr, dest_port, textMsg);
            } else {
                ExchangeIdentifier conn_id = new ExchangeIdentifier(proto, dest_ipaddr, dest_port);
                if (this.connections == null || !this.connections.containsKey(conn_id)) {
                    try {
                        TcpExchange tcpExchanger = new TcpExchange(dest_ipaddr, dest_port, this);
                        addConnection(tcpExchanger);
                    } catch (IOException e) {
                        Log.e("MainExchange|sendMessage", "new TcpExchange failed to " + dest_ipaddr.toString());
                        z = false;
                    }
                }
                TcpExchange conn = this.connections.get(conn_id);
                if (conn == null) {
                    Log.v("MainExchange|sendMessage", "TcpExchange is null 3");
                    z = false;
                } else if (!conn.isValid().booleanValue()) {
                    Log.v("MainExchange|sendMessage", "TcpExchange is not valid 2");
                    z = false;
                } else {
                    z = conn.sendMessage(textMsg);
                }
            }
        }
        return z;
    }

    @Override // com.RanaEman.client.main.net.TcpServerListener
    public void onIncomingConnection(TcpServer tcp_server, TcpSocket socket) {
        Log.v("MainExchangeServer", "onIncomingConnectionincoming connection from " + socket.getAddress() + ":" + socket.getPort());
        TcpExchange conn = new TcpExchange(socket, this);
        addConnection(conn);
    }

    @Override // com.RanaEman.client.main.net.TcpServerListener
    public void onServerTerminated(TcpServer tcp_server, Exception error) {
        Log.e("MainExchangeServer", "onServerTerminated");
        if (this.messageListener != null) {
            this.messageListener.OnSrvDown();
            Log.v("MainExchangeServer", "OnExchangeRecv call the OnGroupMessageRecv");
        }
    }

    private void addConnection(TcpExchange conn) {
        ExchangeIdentifier conn_id = new ExchangeIdentifier(conn);
        if (this.connections.containsKey(conn_id)) {
            TcpExchange old_conn = this.connections.get(conn_id);
            old_conn.halt();
            this.connections.remove(conn_id);
        }
        this.connections.put(conn_id, conn);
    }

    private void removeConnection(TcpExchange conn) {
        ExchangeIdentifier conn_id = new ExchangeIdentifier(conn);
        removeConnection(conn_id);
    }

    private void removeConnection(ExchangeIdentifier conn_id) {
        if (this.connections != null && this.connections.containsKey(conn_id)) {
            TcpExchange conn = this.connections.get(conn_id);
            if (conn != null) {
                conn.halt();
            }
            this.connections.remove(conn_id);
        }
    }

    @Override // com.RanaEman.client.main.exchange.OnExchangeRecvListener
    public void OnExchangeConnectionTerminated(TcpExchange tcp, Exception error) {
        if (this.messageListener != null) {
            this.messageListener.OnConnectionTerminated(tcp.getRemoteAddress().toString(), tcp.getRemotePort(), tcp.getProtocol());
            Log.v("MainExchangeServer", "OnConnectionTerminated call the OnGroupMessageRecv");
        } else {
            Log.v("MainExchangeServer", "OnConnectionTerminated but the OnGroupMessageRecv is null");
        }
        removeConnection(tcp);
        Log.e("MainExchangeServer", "OnExchangeConnectionTerminated");
    }
}
