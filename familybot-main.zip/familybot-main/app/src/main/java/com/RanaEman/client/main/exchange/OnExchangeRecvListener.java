package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public interface OnExchangeRecvListener {
    public static final int PROTOCAL_TYPE_TCP = 1;
    public static final int PROTOCAL_TYPE_UDP = 0;

    void OnExchangeConnectionTerminated(TcpExchange tcpExchange, Exception exc);

    void OnExchangeRecv(String str, String str2, String str3, String str4);
}
