package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import com.RanaEman.client.main.SigCameraService;
import com.RanaEman.client.main.data.DataCenter;
import com.RanaEman.client.main.data.localDvrItem;
import com.RanaEman.client.main.exchange.CmdParam;
import com.Robot.client.main.R;
import com.google.zxing.client.androidlegacy.CaptureActivity;
import com.google.zxing.client.androidlegacy.Intents;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import com.tutk.IOTC.AVIOCTRLDEFs;
import java.util.List;

/* loaded from: classes.dex */
public class NewMainActivity extends Activity implements AdapterView.OnItemClickListener, View.OnClickListener, AdapterView.OnItemLongClickListener {
    boolean blnIsTest = false;
    Button btnAdd_device;
    Button btnBarcode;
    DeviceListAdapter dvripcAdapter;
    ListView dvripcListView;
    public List<localDvrItem> dvripcitems;
    int iFromWhat;
    ProgressDialog pd1;
    PopupWindow popShowAudio;
    int positionDVRSEL;
    TextView tvNoDevice;

    /* loaded from: classes.dex */
    public class SearchResult {
        public String IP;
        public String UID;

        public SearchResult(String paramString1, String paramString2, int paramInt) {
            //NewMainActivity.this = this$0;
            this.UID = paramString1;
            this.IP = paramString2;
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_main);
        this.btnAdd_device = (Button) findViewById(R.id.btnConnAP);
        this.btnAdd_device.setOnClickListener(this);
        this.tvNoDevice = (TextView) findViewById(R.id.textView3);
        this.tvNoDevice.setVisibility(4);
        this.iFromWhat = getIntent().getIntExtra("FromWhat", 1);
        initipcdvrListView();
        this.btnBarcode = (Button) findViewById(R.id.btncancel);
        this.btnBarcode.setOnClickListener(this);
        //this.blnIsTest = IsTestVersion();
        Log.e("NewMainActivity", "blnIsTest:" + this.blnIsTest);
    }

    private boolean IsTestVersion() {
        ApplicationInfo appInfo = null;
        try {
            appInfo = getPackageManager().getApplicationInfo(getPackageName(), 128);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String msg = BuildConfig.FLAVOR;
        if (appInfo != null) {
            msg = appInfo.metaData.getString("entry", "ok");
        }
        if (msg.equals("test_version")) {
            return true;
        }
        return false;
    }

    void initipcdvrListView() {
        this.dvripcListView = (ListView) findViewById(R.id.lvDvrIpcNew);
        this.dvripcListView.setOnItemClickListener(this);
        this.dvripcListView.setOnItemLongClickListener(this);
    }

    private List<localDvrItem> getdvripcList(String sNeedOrder) {
        DataCenter.GetAllLocalDVRFromDB(sNeedOrder);
        this.dvripcitems = DataCenter.getLocalDvrIpcList();
        return this.dvripcitems;
    }

    public void refreshdvripcList(String sNeedOrder) {
        Log.e("MainActivity", "call refreshdvripcList().");
        this.dvripcAdapter = new DeviceListAdapter(this, getdvripcList(sNeedOrder));
        this.dvripcListView.setAdapter((ListAdapter) this.dvripcAdapter);
        if (this.dvripcitems.size() > 0) {
            this.tvNoDevice.setVisibility(4);
            this.btnBarcode.setVisibility(0);
            return;
        }
        this.tvNoDevice.setVisibility(0);
        this.btnBarcode.setVisibility(4);
    }

    @Override // android.widget.AdapterView.OnItemLongClickListener
    public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        this.positionDVRSEL = arg2;
        Showpopmenu(arg1);
        return true;
    }

    private void Showpopmenu(View parent) {
        if (this.popShowAudio == null) {
            LayoutInflater inflater = (LayoutInflater) getSystemService("layout_inflater");
            View popView = inflater.inflate(R.layout.dialog_dvr_menu, (ViewGroup) null);
            this.popShowAudio = new PopupWindow(popView, -2, -2);
            this.popShowAudio.setBackgroundDrawable(new ColorDrawable(0));
            this.popShowAudio.setAnimationStyle(R.style.PopupAnimationDown);
            Button btn_tom = (Button) popView.findViewById(R.id.btn_Ok);
            btn_tom.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.NewMainActivity.1
                @Override // android.view.View.OnClickListener
                public void onClick(View arg0) {
                    String del_UIDString = NewMainActivity.this.dvripcitems.get(NewMainActivity.this.positionDVRSEL).dvr_id;
                    String del_UIDName = NewMainActivity.this.dvripcitems.get(NewMainActivity.this.positionDVRSEL).dvr_name;
                    int iDefault = NewMainActivity.this.dvripcitems.get(NewMainActivity.this.positionDVRSEL).last_activetime;
                    if (DataCenter.DelUIDFromDB(del_UIDString)) {
                        Toast.makeText(NewMainActivity.this, NewMainActivity.this.getString(R.string.txtdeldevice) + del_UIDName, 0).show();
                        if (iDefault == 1) {
                            NewMainActivity.this.refreshdvripcList(BuildConfig.FLAVOR);
                            Intent intent = new Intent();
                            intent.setAction(SigCameraService.ACTION_DELUID);
                            intent.putExtra("UID", del_UIDString);
                            NewMainActivity.this.sendBroadcast(intent);
                            if (NewMainActivity.this.dvripcitems.size() > 0) {
                                Intent intent2 = new Intent();
                                intent2.setAction(SigCameraService.ACTION_ADDUID);
                                intent2.putExtra("UID", NewMainActivity.this.GetDefaultUID());
                                NewMainActivity.this.sendBroadcast(intent2);
                            }
                        } else {
                            NewMainActivity.this.refreshdvripcList(NewMainActivity.this.GetDefaultUID());
                        }
                    }
                    NewMainActivity.this.popShowAudio.dismiss();
                }
            });
        }
        this.popShowAudio.showAsDropDown(parent);
        this.popShowAudio.setFocusable(true);
        this.popShowAudio.setOutsideTouchable(true);
        this.popShowAudio.update();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        Log.e("newMain", "id:" + arg0.getId());
        if (arg0 == this.btnAdd_device) {
            if (this.blnIsTest) {
                Intent intent = new Intent();
                intent.setAction(Intents.Scan.ACTION);
                intent.putExtra(Intents.Scan.WIDTH, AVIOCTRLDEFs.IOTYPE_USER_IPCAM_SETSTREAMCTRL_REQ);
                intent.putExtra(Intents.Scan.HEIGHT, 600);
                intent.setClass(this, CaptureActivity.class);
                startActivityForResult(intent, 1);
            } else {
                Intent tIntent = new Intent(this, EmanWizzard.class);
                if (this.iFromWhat == 0) {
                    finish();
                }
                tIntent.putExtra("FromWhat", this.iFromWhat);
                startActivityForResult(tIntent, 0);
            }
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else if (arg0 == this.btnBarcode) {
            if (this.dvripcitems.size() == 0) {
                ShowQuitDialog();
                return;
            }
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0) {
            if (resultCode == -1) {
                ShowBusyProgress();
            }
        } else if (requestCode == 1) {
            if (resultCode == -1) {
                String sResult = data.getStringExtra(Intents.Scan.RESULT);
                if (sResult == null) {
                    runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.NewMainActivity.2
                        @Override // java.lang.Runnable
                        public void run() {
                            Toast.makeText(NewMainActivity.this, "扫码结果为空。", 1).show();
                        }
                    });
                    return;
                } else if (sResult.length() != 20) {
                    runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.NewMainActivity.3
                        @Override // java.lang.Runnable
                        public void run() {
                            Toast.makeText(NewMainActivity.this, "扫码结果长度错误。", 1).show();
                        }
                    });
                    return;
                } else {
                    localDvrItem NewDvrItem = new localDvrItem();
                    NewDvrItem.device_type = 0;
                    NewDvrItem.dvr_mac = CmdParam.deviceType_ipc;
                    NewDvrItem.dvr_id = sResult;
                    Log.e("onActivityResult", "GetUID:" + NewDvrItem.dvr_id);
                    NewDvrItem.dvr_name = "Robot" + DataCenter.GetMaxNoFromDB();
                    NewDvrItem.dvr_pwd = "123456789";
                    NewDvrItem.dvr_username = "Admin";
                    NewDvrItem.last_activetime = 0;
                    NewDvrItem.status = 1;
                    NewDvrItem.always_veritypwd = 1;
                    Log.e("onActivityResult", "准备插入数据库。");
                    if (DataCenter.adddvrItem2DB(NewDvrItem) <= 0) {
                        runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.NewMainActivity.4
                            @Override // java.lang.Runnable
                            public void run() {
                                Toast.makeText(NewMainActivity.this, "二维码重复。", 1).show();
                            }
                        });
                    } else {
                        String sDBUID = NewDvrItem.dvr_id;
                        refreshdvripcList(sDBUID);
                        Intent intent = new Intent();
                        intent.setAction(SigCameraService.ACTION_ADDUID);
                        intent.putExtra("UID", sDBUID);
                        sendBroadcast(intent);
                        ShowBusyProgress();
                    }
                }
            } else if (522 == resultCode) {
                runOnUiThread(new Runnable() { // from class: com.RanaEman.client.main.ui.NewMainActivity.5
                    @Override // java.lang.Runnable
                    public void run() {
                        Toast.makeText(NewMainActivity.this, "二维码扫码错误。", 1).show();
                    }
                });
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.dvripcitems.size() == 0) {
                ShowQuitDialog();
            } else {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void ShowQuitDialog() {
        final Dialog dialog = new Dialog(this, R.style.Tips);
        dialog.setContentView(R.layout.mydialog);
        Button btnButton = (Button) dialog.findViewById(R.id.dialog_button_ok);
        btnButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.NewMainActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                dialog.dismiss();
                NewMainActivity.this.setResult(-1);
                NewMainActivity.this.finish();
            }
        });
        Button btnButtonc = (Button) dialog.findViewById(R.id.dialog_button_cancel);
        btnButtonc.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.NewMainActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        if (arg0.getAdapter() == this.dvripcAdapter) {
            String sUIDString = this.dvripcitems.get(arg2).dvr_id;
            if (!sUIDString.equals(SigCameraService.sDefaultUID)) {
                refreshdvripcList(sUIDString);
                Intent intent = new Intent();
                intent.setAction(SigCameraService.ACTION_ADDUID);
                intent.putExtra("UID", sUIDString);
                sendBroadcast(intent);
                ShowBusyProgress();
            }
        }
    }

    public String GetDefaultUID() {
        SharedPreferences sPreferences = getApplicationContext().getSharedPreferences(WelcomeActivity.DEFAULT_UID, 0);
        return sPreferences.getString(WelcomeActivity.DEFAULT_UID_STR, null);
    }

    @Override // android.app.Activity
    protected void onResume() {
        refreshdvripcList(GetDefaultUID());
        Log.e("mainactivity", "onResume()");
        if (SigCameraService.MainCamera == null) {
            Intent intent2 = new Intent();
            intent2.setAction(SigCameraService.ACTION_ADDUID);
            intent2.putExtra("UID", GetDefaultUID());
            sendBroadcast(intent2);
        }
        super.onResume();
    }

    private void ShowBusyProgress() {
        this.pd1 = new ProgressDialog(this, 3);
        this.pd1.setProgressStyle(0);
        this.pd1.setMessage(getString(R.string.connstus_connecting));
        this.pd1.setIndeterminate(false);
        this.pd1.setCancelable(false);
        this.pd1.show();
        new Handler().postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.NewMainActivity.8
            @Override // java.lang.Runnable
            public void run() {
                if (NewMainActivity.this.pd1 != null && NewMainActivity.this.pd1.isShowing()) {
                    NewMainActivity.this.pd1.dismiss();
                    NewMainActivity.this.pd1 = null;
                    if (NewMainActivity.this.iFromWhat == 0) {
                        Intent intentStartVideo = new Intent(NewMainActivity.this, EmanVideoActivity.class);
                        NewMainActivity.this.startActivity(intentStartVideo);
                    }
                    NewMainActivity.this.finish();
                    NewMainActivity.this.overridePendingTransition(17432578, 17432579);
                }
            }
        }, 2500L);
    }

    @Override // android.app.Activity
    protected void onPause() {
        if (this.popShowAudio != null) {
            this.popShowAudio.dismiss();
        }
        super.onPause();
    }
}
