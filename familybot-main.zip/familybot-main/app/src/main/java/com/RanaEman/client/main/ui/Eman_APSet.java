package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.Time;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.RanaEman.client.main.SigCameraService;
import com.RanaEman.client.main.exchange.DvrIniPacket;
import com.Robot.client.main.R;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import com.tutk.IOTC.AVAPIs;
import com.tutk.IOTC.Camera;
import com.tutk.IOTC.IRegisterIOTCListener;
import com.tutk.IOTC.MyCamera;
import com.tutk.IOTC.Packet;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes.dex */
public class Eman_APSet extends Activity implements IRegisterIOTCListener {
    public static String APMAINADD = "192.168.100.2";
    Button btnTest;
    Button btnquitButton;
    ImageView ivEman;
    LinearLayout lltMain;
    Dialog m_prpgressDialog;
    private Button mybtnApply;
    String sOld_pwd;
    String sOld_ssid;
    private Spinner spSSID;
    ArrayAdapter<String> ssidAdapter;
    private EditText txtDvrName;
    TextView txtMyProgerssMsg;
    private EditText txtSSIDPwd;
    TextView txtTitleTextView;
    WifiManager wifiManager;
    List<ScanResult> wifiscanResults;
    Socket tcpSocketclientSocket = null;
    String sUID = BuildConfig.FLAVOR;
    String sRadogName = BuildConfig.FLAVOR;
    ProgressBar m_pbMain = null;
    ProgressBar pbDialogBar = null;
    DvrIniPacket pRecvPacket = new DvrIniPacket();
    public MyCamera cameraset = null;
    int iSetKind = 0;
    String tag = "APSET";
    boolean blnSetOutTime = false;
    int iAP = 0;
    private TextWatcher mTextWatcher = new TextWatcher() { // from class: com.RanaEman.client.main.ui.Eman_APSet.1
        private int editEnd;
        private int editStart;

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable s) {
            this.editStart = Eman_APSet.this.txtDvrName.getSelectionStart();
            this.editEnd = Eman_APSet.this.txtDvrName.getSelectionEnd();
            Eman_APSet.this.txtDvrName.removeTextChangedListener(Eman_APSet.this.mTextWatcher);
            while (Eman_APSet.this.txtDvrName.getText().toString().getBytes().length > 36) {
                s.delete(this.editStart - 1, this.editEnd);
                this.editStart--;
                this.editEnd--;
            }
            Eman_APSet.this.txtDvrName.setSelection(this.editStart);
            Eman_APSet.this.txtDvrName.addTextChangedListener(Eman_APSet.this.mTextWatcher);
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };
    Handler handler = new Handler() { // from class: com.RanaEman.client.main.ui.Eman_APSet.6
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    Eman_APSet.this.pbDialogBar.setVisibility(8);
                    Eman_APSet.this.txtTitleTextView.setText(Eman_APSet.this.getString(R.string.txtsettingfailed).toString());
                    Eman_APSet.this.txtMyProgerssMsg.setText(Eman_APSet.this.getString(R.string.txtsettingtimeout).toString());
                    new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.Eman_APSet.6.1
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            Eman_APSet.this.m_prpgressDialog.dismiss();
                            Eman_APSet.this.m_prpgressDialog = null;
                        }
                    }, 1500L);
                    return;
                case 1:
                    Eman_APSet.this.txtTitleTextView.setText(Eman_APSet.this.getString(R.string.txtsettingsucess));
                    Eman_APSet.this.txtMyProgerssMsg.setText(Eman_APSet.this.getString(R.string.txtsettingsucess_point) + Eman_APSet.this.getString(R.string.connstus_connecting));
                    int iDelayTime = AVAPIs.TIME_SPAN_LOSED;
                    iDelayTime = (Eman_APSet.this.txtSSIDPwd.getText().toString().equals(Eman_APSet.this.sOld_pwd) && Eman_APSet.this.spSSID.getSelectedItem().toString().equals(Eman_APSet.this.sOld_ssid)) ? 18000 : 18000;
                    new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.Eman_APSet.6.2
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            Eman_APSet.this.m_prpgressDialog.dismiss();
                            Eman_APSet.this.m_prpgressDialog = null;
                            if (Eman_APSet.this.iSetKind == 0) {
                                Log.e("UID_LEN", "UID_LEN:" + Eman_APSet.this.sUID.length());
                                if (Eman_APSet.this.sUID.length() == 20) {
                                    String sname = Eman_APSet.this.txtDvrName.getText().toString();
                                    Intent resultIntent = new Intent();
                                    Bundle bundle = new Bundle();
                                    bundle.putString("NewUID", Eman_APSet.this.sUID);
                                    bundle.putString("NewName", sname);
                                    bundle.putInt("AP", Eman_APSet.this.iAP);
                                    resultIntent.putExtras(bundle);
                                    Eman_APSet.this.setResult(-1, resultIntent);
                                }
                            }
                            if (SigCameraService.MainCamera != null) {
                                SigCameraService.MainCamera.setUserNeedAP(true);
                            }
                            Eman_APSet.this.finish();
                            Eman_APSet.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                        }
                    }, iDelayTime);
                    return;
                case 2:
                    Eman_APSet.this.txtTitleTextView.setText(Eman_APSet.this.getString(R.string.txtsettingfailed).toString());
                    Eman_APSet.this.txtMyProgerssMsg.setText(Eman_APSet.this.getString(R.string.txtsettingerr).toString());
                    Eman_APSet.this.pbDialogBar.setVisibility(8);
                    new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.Eman_APSet.6.3
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            Eman_APSet.this.m_prpgressDialog.dismiss();
                            Eman_APSet.this.m_prpgressDialog = null;
                        }
                    }, 1500L);
                    return;
                case 3:
                    Eman_APSet.this.lltMain.setVisibility(0);
                    Eman_APSet.this.m_pbMain.setVisibility(4);
                    Eman_APSet.this.mybtnApply.setVisibility(0);
                    Eman_APSet.this.IniParam2Text();
                    return;
                case 4:
                    Eman_APSet.this.lltMain.setVisibility(0);
                    Eman_APSet.this.m_pbMain.setVisibility(4);
                    Eman_APSet.this.mybtnApply.setVisibility(0);
                    Eman_APSet.this.txtDvrName.setText(BuildConfig.FLAVOR);
                    Log.e("setResult", "case 4444");
                    return;
                default:
                    return;
            }
        }
    };

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (SigCameraService.MainCamera != null) {
                SigCameraService.MainCamera.setUserNeedAP(true);
            }
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eman_ap_set);
        this.txtDvrName = (EditText) findViewById(R.id.txtRaDogName);
        this.txtDvrName.addTextChangedListener(this.mTextWatcher);
        this.lltMain = (LinearLayout) findViewById(R.id.llt_main);
        this.lltMain.setVisibility(4);
        this.spSSID = (Spinner) findViewById(R.id.spSSID);
        this.txtSSIDPwd = (EditText) findViewById(R.id.txtssidpwd);
        this.ivEman = (ImageView) findViewById(R.id.imageView4);
        this.m_pbMain = (ProgressBar) findViewById(R.id.pBMain);
        this.iSetKind = getIntent().getIntExtra("SetKind", 0);
        if (this.iSetKind == 0) {
            new Thread(new Runnable() { // from class: com.RanaEman.client.main.ui.Eman_APSet.2
                @Override // java.lang.Runnable
                public void run() {
                    Eman_APSet.this.TcpGetInfo();
                }
            }).start();
        } else {
            this.cameraset = SigCameraService.MainCamera;
            this.cameraset.registerIOTCListener(this);
            this.cameraset.sendIOCtrl(0, 1120, Packet.intToByteArray_Little(0));
        }
        if (this.wifiManager == null) {
            this.wifiManager = (WifiManager) getSystemService("wifi");
        }
        this.wifiscanResults = this.wifiManager.getScanResults();
        int iwifiCount = this.wifiscanResults.size();
        this.ssidAdapter = new ArrayAdapter<>(this, R.layout.mysppiner);
        this.ssidAdapter.add(getResources().getString(R.string.txtchoosenetwork));
        for (int i = 0; i < iwifiCount; i++) {
            String stemp = this.wifiscanResults.get(i).SSID.toString();
            if (!stemp.equalsIgnoreCase("Family Robot") && !stemp.equalsIgnoreCase("Bayper") && !stemp.equalsIgnoreCase("Robotset") && !stemp.equalsIgnoreCase("Robot")) {
                this.ssidAdapter.add(stemp);
            }
        }
        this.ssidAdapter.setDropDownViewResource(17367049);
        this.spSSID.setAdapter((SpinnerAdapter) this.ssidAdapter);
        this.btnquitButton = (Button) findViewById(R.id.btncancel);
        this.btnquitButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Eman_APSet.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (SigCameraService.MainCamera != null) {
                    SigCameraService.MainCamera.setUserNeedAP(true);
                }
                Eman_APSet.this.finish();
                Eman_APSet.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
        this.mybtnApply = (Button) findViewById(R.id.Button04);
        this.mybtnApply.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Eman_APSet.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (Eman_APSet.this.spSSID.getSelectedItemPosition() == 0) {
                    Toast.makeText(Eman_APSet.this, Eman_APSet.this.getResources().getString(R.string.txtinputfull), 0).show();
                    //return;
                }
                if (Eman_APSet.this.m_prpgressDialog != null) {
                    Eman_APSet.this.m_prpgressDialog.dismiss();
                }
                Eman_APSet.this.m_prpgressDialog = new Dialog(Eman_APSet.this, R.style.Tips);
                Eman_APSet.this.m_prpgressDialog.setContentView(R.layout.myprogress_dialog);
                Eman_APSet.this.txtTitleTextView = (TextView) Eman_APSet.this.m_prpgressDialog.findViewById(R.id.txtDialogTitle);
                Eman_APSet.this.txtTitleTextView.setText(Eman_APSet.this.getString(R.string.txtwait).toString());
                Eman_APSet.this.txtMyProgerssMsg = (TextView) Eman_APSet.this.m_prpgressDialog.findViewById(R.id.txtMessage);
                Eman_APSet.this.txtMyProgerssMsg.setText(Eman_APSet.this.getString(R.string.txtsetting).toString());
                Eman_APSet.this.pbDialogBar = (ProgressBar) Eman_APSet.this.m_prpgressDialog.findViewById(R.id.progressBar1);
                Button btnokk = (Button) Eman_APSet.this.m_prpgressDialog.findViewById(R.id.btnSure);
                btnokk.setVisibility(4);
                Eman_APSet.this.m_prpgressDialog.setCancelable(false);
                Eman_APSet.this.m_prpgressDialog.show();
                Log.e("onActivityResult", "开始设置。");
                if (Eman_APSet.this.iSetKind == 0) {
                    new Thread(new Runnable() { // from class: com.RanaEman.client.main.ui.Eman_APSet.4.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Eman_APSet.this.TcpSetDvrIniParam();
                        }
                    }).start();
                    return;
                }
                Eman_APSet.this.cameraset.sendIOCtrl(0, 1104, Eman_APSet.this.getByteFromView());
                Eman_APSet.this.blnSetOutTime = true;
                new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.ui.Eman_APSet.4.2
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        if (Eman_APSet.this.blnSetOutTime) {
                            Eman_APSet.this.handler.sendEmptyMessage(2);
                        }
                    }
                }, 5000L);
            }
        });
        this.btnTest = (Button) findViewById(R.id.button1);
        this.btnTest.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Eman_APSet.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                int ipos = Eman_APSet.this.ssidAdapter.getPosition("OK");
                if (ipos < 0) {
                    Eman_APSet.this.ssidAdapter.add("OK");
                    Eman_APSet.this.ssidAdapter.notifyDataSetChanged();
                }
                Eman_APSet.this.spSSID.setSelection(Eman_APSet.this.ssidAdapter.getPosition("OK"));
            }
        });
        if (getIntent().getBooleanExtra("ShowAll", false)) {
            this.lltMain.setVisibility(0);
            this.m_pbMain.setVisibility(4);
            this.mybtnApply.setVisibility(0);
            return;
        }
        this.btnTest.setVisibility(8);
    }

    @Override // android.app.Activity
    protected void onResume() {
        if (this.iSetKind == 1) {
            this.cameraset.registerIOTCListener(this);
        }
        super.onResume();
    }

    @Override // android.app.Activity
    protected void onPause() {
        if (this.iSetKind == 1) {
            this.cameraset.unregisterIOTCListener(this);
        }
        super.onPause();
    }

    void TcpGetInfo() {
        DvrIniPacket sendPacket = new DvrIniPacket();
        sendPacket.setTaskID(12905);
        sendPacket.setPacketHead("DVRGETINFO".getBytes(), 10);
        this.tcpSocketclientSocket = new Socket();
        try {
            this.tcpSocketclientSocket.connect(new InetSocketAddress(APMAINADD, 12904));
            try {
                OutputStream osOutputStream = this.tcpSocketclientSocket.getOutputStream();
                try {
                    osOutputStream.write(sendPacket.getData());
                    try {
                        InputStream iStream = this.tcpSocketclientSocket.getInputStream();
                        long StartTime = System.currentTimeMillis();
                        byte[] recvs = new byte[772];
                        do {
                            try {
                                if (iStream.read(recvs, 0, 772) != 0) {
                                    System.arraycopy(recvs, 0, this.pRecvPacket.packet, 0, 772);
                                    this.handler.sendEmptyMessage(3);
                                    return;
                                }
                            } catch (IOException e) {
                                this.handler.sendEmptyMessage(4);
                                e.printStackTrace();
                                return;
                            }
                        } while (System.currentTimeMillis() - StartTime <= 15000);
                        this.handler.sendEmptyMessage(0);
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        this.handler.sendEmptyMessage(4);
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                    this.handler.sendEmptyMessage(4);
                }
            } catch (IOException e22) {
                e22.printStackTrace();
                this.handler.sendEmptyMessage(4);
            }
        } catch (IOException e23) {
            e23.printStackTrace();
            this.handler.sendEmptyMessage(4);
        }
    }

    byte[] getByteFromView() {
        Time t = new Time();
        t.setToNow();
        int year = t.year;
        int month = t.month + 1;
        int date = t.monthDay;
        int hour = t.hour;
        int minute = t.minute;
        int second = t.second;
        byte[] buftime = new byte[28];
        System.arraycopy(Packet.intToByteArray_Little(year), 0, buftime, 0, 4);
        System.arraycopy(Packet.intToByteArray_Little(month), 0, buftime, 4, 4);
        System.arraycopy(Packet.intToByteArray_Little(date), 0, buftime, 8, 4);
        System.arraycopy(Packet.intToByteArray_Little(hour), 0, buftime, 12, 4);
        System.arraycopy(Packet.intToByteArray_Little(minute), 0, buftime, 16, 4);
        System.arraycopy(Packet.intToByteArray_Little(second), 0, buftime, 20, 4);
        DvrIniPacket sendPacket = new DvrIniPacket();
        sendPacket.setTaskID(12904);
        sendPacket.setDvrName(this.txtDvrName.getText().toString());
        if (this.spSSID.getSelectedItemPosition() > 0) {
            String tempString = "ChinaNet-C+W";//this.spSSID.getSelectedItem().toString();
            sendPacket.setCharStr(tempString.getBytes(), 52);
            String tempString2 = "basicHOUSE";//this.txtSSIDPwd.getText().toString();
            sendPacket.setCharStr(tempString2.getBytes(), 116);
        }
        sendPacket.setCharStr(buftime, 712);
        return sendPacket.getData();
    }

    void TcpSetDvrIniParam() {
        if (this.tcpSocketclientSocket == null) {
            this.handler.sendEmptyMessage(0);
            return;
        }
        try {
            OutputStream osOutputStream = this.tcpSocketclientSocket.getOutputStream();
            try {
                osOutputStream.write(getByteFromView());
                try {
                    InputStream iStream = this.tcpSocketclientSocket.getInputStream();
                    long StartTime = System.currentTimeMillis();
                    byte[] recvs = new byte[772];
                    do {
                        try {
                            if (iStream.read(recvs, 0, 772) != 0) {
                                this.handler.sendEmptyMessage(1);
                                try {
                                    this.tcpSocketclientSocket.close();
                                    return;
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    return;
                                }
                            }
                        } catch (IOException e2) {
                            e2.printStackTrace();
                            this.handler.sendEmptyMessage(0);
                            return;
                        }
                    } while (System.currentTimeMillis() - StartTime <= 15000);
                    this.handler.sendEmptyMessage(0);
                } catch (IOException e22) {
                    e22.printStackTrace();
                    this.handler.sendEmptyMessage(0);
                }
            } catch (IOException e1) {
                e1.printStackTrace();
                this.handler.sendEmptyMessage(0);
            }
        } catch (IOException e23) {
            e23.printStackTrace();
            this.handler.sendEmptyMessage(0);
        }
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.hello, menu);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        int item_id = item.getItemId();
        switch (item_id) {
            case 0:
                ShowDlgCode();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    void ShowDlgCode() {
        final Dialog inputPwdDialog = new Dialog(this, R.style.Tips);
        inputPwdDialog.setContentView(R.layout.dialog_input_pwd);
        TextView tvtitleTextView = (TextView) inputPwdDialog.findViewById(R.id.textView1);
        tvtitleTextView.setText(getString(R.string.connstus_wrong_password));
        Button btnokk = (Button) inputPwdDialog.findViewById(R.id.btn_Ok);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Eman_APSet.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                TextView txtPwdNew = (TextView) inputPwdDialog.findViewById(R.id.txtDvrPwd);
                String sPwdNew = txtPwdNew.getText().toString();
                if (sPwdNew.isEmpty() || sPwdNew.equalsIgnoreCase("2AP")) {
                }
            }
        });
        inputPwdDialog.setCancelable(false);
        inputPwdDialog.show();
    }

    void IniParam2Text() {
        this.sRadogName = this.pRecvPacket.GetDvrName();
        if (!this.sRadogName.isEmpty()) {
            this.txtDvrName.setText(this.sRadogName);
        } else {
            this.txtDvrName.setText("Robot");
        }
        try {
            String tempStringSub = new String(this.pRecvPacket.packet, 52, 64, "UTF-8").trim();
            this.sOld_ssid = tempStringSub;
            if (!tempStringSub.isEmpty()) {
                int ipos = this.ssidAdapter.getPosition(tempStringSub);
                if (ipos < 0) {
                    this.ssidAdapter.add(tempStringSub);
                    this.ssidAdapter.notifyDataSetChanged();
                }
                this.spSSID.setSelection(this.ssidAdapter.getPosition(tempStringSub), true);
                this.sOld_pwd = new String(this.pRecvPacket.packet, 116, 64, "UTF-8").trim();
                this.txtSSIDPwd.setText(this.sOld_pwd);
            } else {
                this.spSSID.setSelection(0);
            }
            int ipos2 = this.pRecvPacket.packet[768];
            this.sUID = new String(this.pRecvPacket.packet, 744, 20, "UTF-8").trim();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e("onActivityResult", "requestCode:" + requestCode + ";resultCode:" + resultCode);
        if (requestCode == 0 && resultCode == -1) {
            if (this.m_prpgressDialog != null) {
                this.m_prpgressDialog.dismiss();
            }
            this.m_prpgressDialog = new Dialog(this, R.style.Tips);
            this.m_prpgressDialog.setContentView(R.layout.myprogress_dialog);
            this.txtTitleTextView = (TextView) this.m_prpgressDialog.findViewById(R.id.txtDialogTitle);
            this.txtTitleTextView.setText(getString(R.string.txtwait).toString());
            this.txtMyProgerssMsg = (TextView) this.m_prpgressDialog.findViewById(R.id.txtMessage);
            this.txtMyProgerssMsg.setText(getString(R.string.txtsetting).toString());
            Button btnokk = (Button) this.m_prpgressDialog.findViewById(R.id.btnSure);
            btnokk.setVisibility(4);
            this.m_prpgressDialog.setCancelable(false);
            this.m_prpgressDialog.show();
            Log.e("onActivityResult", "开始设置。");
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveChannelInfo(Camera paramCamera, int paramInt1, int paramInt2) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveFrameInfo(Camera paramCamera, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveIOCtrlData(Camera paramCamera, int paramInt1, int paramInt2, byte[] paramArrayOfByte) {
        if (paramInt2 == 1105) {
            Log.e(this.tag + "receiveIOCtrlData", "0x451:" + paramArrayOfByte.length);
            this.blnSetOutTime = false;
            System.arraycopy(paramArrayOfByte, 0, this.pRecvPacket.packet, 0, paramArrayOfByte.length);
            this.handler.sendEmptyMessage(1);
        } else if (paramInt2 == 1121) {
            Log.e(this.tag + "receiveIOCtrlData", "0x461:" + paramArrayOfByte.length);
            if (this.lltMain.getVisibility() == 4) {
                System.arraycopy(paramArrayOfByte, 0, this.pRecvPacket.packet, 0, paramArrayOfByte.length);
                this.handler.sendEmptyMessage(3);
            }
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveSessionInfo(Camera paramCamera, int paramInt) {
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (this.ivEman != null) {
            AnimationDrawable animDrawable = (AnimationDrawable) this.ivEman.getBackground();
            animDrawable.start();
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveRDTSendFileResult(Camera paramCamera, int iFileKind, int Result, String s, int ikind) {
    }
}
