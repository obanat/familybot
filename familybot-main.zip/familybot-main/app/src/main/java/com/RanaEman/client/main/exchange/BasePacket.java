package com.RanaEman.client.main.exchange;

import com.tutk.IOTC.AVFrame;

/* loaded from: classes.dex */
public class BasePacket {
    public int nLen = 0;
    public byte[] packet;

    public void init() {
    }

    public int getLen() {
        return this.nLen;
    }

    public byte[] getData() {
        return this.packet;
    }

    protected static int getInt(byte b) {
        return (b + 256) % 256;
    }

    protected static long getLong(byte[] data, int begin, int end) {
        long n = 0;
        for (int end2 = end - 1; end2 >= begin; end2--) {
            n = (n << 8) + (data[end2] & AVFrame.FRM_STATE_UNKOWN);
        }
        return n;
    }

    protected static void setLong(long n, byte[] data, int begin, int end) {
        while (begin < end) {
            data[begin] = (byte) (n % 256);
            n >>= 8;
            begin++;
        }
    }

    protected static int getInt(byte[] data, int begin, int end) {
        return (int) getLong(data, begin, end);
    }

    public static void setInt(int n, byte[] data, int begin, int end) {
        setLong(n, data, begin, end);
    }

    protected static boolean getBit(byte b, int bit) {
        return (b >> bit) == 1;
    }

    protected static byte setBit(boolean value, byte b, int bit) {
        return value ? (byte) ((1 << bit) | b) : (byte) (((1 << bit) | b) ^ (1 << bit));
    }
}
