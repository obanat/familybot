package com.RanaEman.client.main.lockpwd;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.RanaEman.client.main.lockpwd.LockPatternView;
import com.RanaEman.client.main.ui.WelcomeActivity;
import com.Robot.client.main.R;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes.dex */
public class LockSetupActivity extends Activity implements LockPatternView.OnPatternListener, View.OnClickListener {
    private static final int STEP_1 = 1;
    private static final int STEP_2 = 2;
    private static final int STEP_3 = 3;
    private static final int STEP_4 = 4;
    private static final int STEP_5 = 5;
    private static final String TAG = "LockSetupActivity";
    Button btnBackButton;
    ToggleButton chkOpenPwd;
    private List<LockPatternView.Cell> choosePattern;
    private Button clearPwdButton;
    int iMode;
    private LockPatternView lockPatternView;
    private Button modiPwdButton;
    RelativeLayout rlt_pwd;
    RelativeLayout rrtbar;
    String sPwd;
    private int step;
    TextView tvTips;
    private boolean confirm = false;
    boolean blnNeedClosePwd = false;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_setup);
        this.lockPatternView = (LockPatternView) findViewById(R.id.lock_pattern);
        this.lockPatternView.setOnPatternListener(this);
        this.modiPwdButton = (Button) findViewById(R.id.btnModiPwd);
        this.clearPwdButton = (Button) findViewById(R.id.btnReSetPwd);
        this.modiPwdButton.setOnClickListener(this);
        this.clearPwdButton.setOnClickListener(this);
        this.tvTips = (TextView) findViewById(R.id.tvTips);
        this.rrtbar = (RelativeLayout) findViewById(R.id.rlTbar);
        this.rlt_pwd = (RelativeLayout) findViewById(R.id.rl_pwd);
        Bundle bdlBundle = getIntent().getExtras();
        if (bdlBundle.getString("MODE").equals("setup")) {
            this.iMode = 0;
            this.step = 1;
            this.clearPwdButton.setVisibility(4);
            this.rlt_pwd.setVisibility(4);
        } else {
            this.iMode = 1;
            this.step = 5;
            this.sPwd = bdlBundle.getString("PWD");
            this.choosePattern = LockPatternView.stringToPattern(this.sPwd);
            this.clearPwdButton.setVisibility(4);
            this.rrtbar.setVisibility(4);
        }
        this.sPwd = WelcomeActivity.patternString;
        this.chkOpenPwd = (ToggleButton) findViewById(R.id.chkBoxAp);
        if (WelcomeActivity.patternString != null) {
            this.chkOpenPwd.setChecked(true);
            this.modiPwdButton.setVisibility(0);
        } else {
            this.chkOpenPwd.setChecked(false);
            this.modiPwdButton.setVisibility(4);
        }
        this.chkOpenPwd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.RanaEman.client.main.lockpwd.LockSetupActivity.1
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                if (arg0.isPressed()) {
                    if (!arg1) {
                        LockSetupActivity.this.chkOpenPwd.setChecked(true);
                        if (LockSetupActivity.this.step != 3) {
                            if (WelcomeActivity.patternString != null) {
                                LockSetupActivity.this.blnNeedClosePwd = true;
                                LockSetupActivity.this.iMode = 1;
                                LockSetupActivity.this.step = 5;
                                LockSetupActivity.this.choosePattern = LockPatternView.stringToPattern(LockSetupActivity.this.sPwd);
                                LockSetupActivity.this.clearPwdButton.setVisibility(4);
                            }
                        } else {
                            return;
                        }
                    }
                    LockSetupActivity.this.rlt_pwd.setAnimation(AnimationUtils.loadAnimation(LockSetupActivity.this, R.anim.slide_in_left));
                    LockSetupActivity.this.rlt_pwd.setVisibility(0);
                }
            }
        });
        this.btnBackButton = (Button) findViewById(R.id.btncancel);
        this.btnBackButton.setOnClickListener(this);
        ViewGroup.LayoutParams lp = this.lockPatternView.getLayoutParams();
        if (WelcomeActivity.totalWdps < 350) {
            lp.width = (int) (250.0f * WelcomeActivity.density);
            lp.height = lp.width;
        }
        this.lockPatternView.setLayoutParams(lp);
        updateView();
    }

    private void updateView() {
        switch (this.step) {
            case 1:
                if (this.iMode == 2) {
                    this.tvTips.setText(getString(R.string.txtdrawnewpwd));
                } else {
                    this.tvTips.setText(getString(R.string.txtdrawpwd));
                }
                this.choosePattern = null;
                this.confirm = false;
                this.lockPatternView.clearPattern();
                this.lockPatternView.enableInput();
                this.clearPwdButton.setVisibility(4);
                return;
            case 2:
                if (this.iMode == 2) {
                    this.tvTips.setText(getString(R.string.txtdrawnewpwda));
                } else {
                    this.tvTips.setText(getString(R.string.txtdrawpwda));
                }
                this.lockPatternView.clearPattern();
                this.lockPatternView.enableInput();
                this.clearPwdButton.setVisibility(0);
                return;
            case 3:
                this.tvTips.setText(getString(R.string.txtdrawoldpwd));
                this.choosePattern = LockPatternView.stringToPattern(this.sPwd);
                this.confirm = false;
                this.lockPatternView.clearPattern();
                this.lockPatternView.enableInput();
                this.clearPwdButton.setVisibility(4);
                this.modiPwdButton.setVisibility(4);
                return;
            case 4:
                if (this.confirm) {
                    this.lockPatternView.disableInput();
                    SharedPreferences preferences = getSharedPreferences(WelcomeActivity.LOCK, 0);
                    preferences.edit().putString(WelcomeActivity.LOCK_KEY, LockPatternView.patternToString(this.choosePattern)).commit();
                    WelcomeActivity.patternString = LockPatternView.patternToString(this.choosePattern);
                    setResult(-1);
                    new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.lockpwd.LockSetupActivity.2
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            LockSetupActivity.this.finish();
                            LockSetupActivity.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                        }
                    }, 1000L);
                    return;
                }
                this.lockPatternView.setDisplayMode(LockPatternView.DisplayMode.Wrong);
                this.lockPatternView.enableInput();
                return;
            case 5:
                this.tvTips.setText(getString(R.string.txtdrawpwd));
                return;
            default:
                return;
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if (v == this.btnBackButton) {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        } else if (v == this.modiPwdButton) {
            this.rlt_pwd.setAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_in_left));
            this.rlt_pwd.setVisibility(0);
            this.iMode = 2;
            this.choosePattern = null;
            this.step = 3;
            updateView();
        } else if (this.clearPwdButton == v) {
            this.step = 1;
            this.choosePattern = null;
            updateView();
        }
    }

    @Override // com.RanaEman.client.main.lockpwd.LockPatternView.OnPatternListener
    public void onPatternStart() {
        Log.d(TAG, "onPatternStart");
    }

    @Override // com.RanaEman.client.main.lockpwd.LockPatternView.OnPatternListener
    public void onPatternCleared() {
        Log.d(TAG, "onPatternCleared");
    }

    @Override // com.RanaEman.client.main.lockpwd.LockPatternView.OnPatternListener
    public void onPatternCellAdded(List<LockPatternView.Cell> pattern) {
        Log.d(TAG, "onPatternCellAdded");
    }

    @Override // com.RanaEman.client.main.lockpwd.LockPatternView.OnPatternListener
    public void onPatternDetected(List<LockPatternView.Cell> pattern) {
        Log.d(TAG, "onPatternDetected");
        if (this.iMode >= 1) {
            if (pattern.equals(this.choosePattern)) {
                if (this.iMode == 2) {
                    this.step = 1;
                    updateView();
                    this.iMode = 0;
                    return;
                }
                setResult(-1);
                if (this.blnNeedClosePwd) {
                    SharedPreferences preferences = getSharedPreferences(WelcomeActivity.LOCK, 0);
                    preferences.edit().remove(WelcomeActivity.LOCK_KEY).commit();
                    WelcomeActivity.patternString = null;
                    this.chkOpenPwd.setChecked(false);
                    this.rlt_pwd.setAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_out_right));
                    this.rlt_pwd.setVisibility(4);
                }
                new Timer().schedule(new TimerTask() { // from class: com.RanaEman.client.main.lockpwd.LockSetupActivity.3
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        LockSetupActivity.this.finish();
                        LockSetupActivity.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                    }
                }, 1000L);
                return;
            }
            this.lockPatternView.setDisplayMode(LockPatternView.DisplayMode.Wrong);
            Toast.makeText(this, (int) R.string.lockpattern_error, 0).show();
        } else if (pattern.size() < 4) {
            Toast.makeText(this, (int) R.string.lockpattern_recording_incorrect_too_short, 1).show();
            this.lockPatternView.setDisplayMode(LockPatternView.DisplayMode.Wrong);
        } else if (this.choosePattern == null) {
            this.choosePattern = new ArrayList(pattern);
            Log.d(TAG, "choosePattern = " + Arrays.toString(this.choosePattern.toArray()));
            this.step = 2;
            updateView();
        } else {
            Log.d(TAG, "choosePattern = " + Arrays.toString(this.choosePattern.toArray()));
            Log.d(TAG, "pattern = " + Arrays.toString(pattern.toArray()));
            if (this.choosePattern.equals(pattern)) {
                Log.d(TAG, "pattern = " + Arrays.toString(pattern.toArray()));
                this.confirm = true;
            } else {
                this.confirm = false;
            }
            this.step = 4;
            updateView();
        }
    }
}
