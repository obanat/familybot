package com.RanaEman.client.main.ui;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import com.RanaEman.client.main.data.localDvrItem;
import com.Robot.client.main.R;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class DeviceListAdapter extends BaseAdapter {
    public static String PWD;
    public static String UID;
    public static String UIDNAME;
    private List<localDvrItem> items;
    Context mContext;
    private LayoutInflater mLayoutInflater;
    int selectedPosition = -1;

    void setSelectedPosition(int i) {
        this.selectedPosition = i;
    }

    public DeviceListAdapter(Context context, List<localDvrItem> datas) {
        this.items = new ArrayList();
        this.mLayoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.items.clear();
        this.items = datas;
        this.mContext = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.items.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        if (this.items.size() > position) {
            return this.items.get(position);
        }
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        if (this.items.size() > position) {
            return this.items.get(position).dvr_no;
        }
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = this.mLayoutInflater.inflate(R.layout.device_list_item, (ViewGroup) null);
        }
        localDvrItem item = (localDvrItem) getItem(position);
        CheckBox chkDefault = (CheckBox) convertView.findViewById(R.id.checkBox1);
        if (item.last_activetime == 1) {
            chkDefault.setChecked(true);
        } else {
            chkDefault.setChecked(false);
        }
        TextView t = (TextView) convertView.findViewById(R.id.txtUID);
        t.setText(item.dvr_name);
        if (((item.status >> 8) & 1) == 1) {
        }
        int i = item.status & 15;
        Log.e("DeviceListAdapter", "item.device_type:" + item.device_type);
        return convertView;
    }
}
