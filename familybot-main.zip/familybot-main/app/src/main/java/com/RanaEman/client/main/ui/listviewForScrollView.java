package com.RanaEman.client.main.ui;

import android.content.Context;
//import android.support.v4.widget.ExploreByTouchHelper;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ListView;

/* loaded from: classes.dex */
public class listviewForScrollView extends ListView {
    public listviewForScrollView(Context context) {
        super(context);
    }

    public listviewForScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public listviewForScrollView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int expandSpec = View.MeasureSpec.makeMeasureSpec(536870911, MeasureSpec.UNSPECIFIED/*ExploreByTouchHelper.INVALID_ID*/);
        super.onMeasure(widthMeasureSpec, expandSpec);
    }
}
