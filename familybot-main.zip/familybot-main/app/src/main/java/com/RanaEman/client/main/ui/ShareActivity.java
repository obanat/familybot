package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.Robot.client.main.R;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/* loaded from: classes.dex */
public class ShareActivity extends Activity {
    Button btnShareButton;
    ImageView imgShow;
    String seManName = null;
    String spicName = null;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        this.imgShow = (ImageView) findViewById(R.id.imageView1);
        Bundle bd = getIntent().getExtras();
        this.seManName = bd.getString("eManName");
        this.spicName = bd.getString("picName");
        FileInputStream fis = null;
        try {
            FileInputStream fis2 = new FileInputStream(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Shot/" + this.seManName + "/" + this.spicName);
            fis = fis2;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        this.btnShareButton = (Button) findViewById(R.id.button1);
        this.btnShareButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.ShareActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                Intent sendIntent = new Intent();
                sendIntent.setAction("android.intent.action.SEND");
                File filetoShare = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Shot/" + ShareActivity.this.seManName + "/" + ShareActivity.this.spicName);
                sendIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + filetoShare.getPath()));
                sendIntent.setType("image/png");
                ShareActivity.this.startActivity(sendIntent);
                ShareActivity.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
        Bitmap bitmap = BitmapFactory.decodeStream(fis);
        this.imgShow.setImageBitmap(bitmap);
    }
}
