package com.RanaEman.client.main.exchange;

import android.util.Log;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class GroupMsgCodecNormal {
    public static Boolean baseDecode(String rowMessage, Map<String, Object> outData) {
        outData.put(CmdParam.cmdFormat, CmdParam.FormatNormal);
        Log.e("baseDecode", "begin base decode, the row message is : " + rowMessage);
        Boolean.valueOf(true);
        if (rowMessage.startsWith("AT+")) {
            String msgProcess = rowMessage.substring("AT+".length());
            if (!msgProcess.endsWith("]")) {
                Log.e("GroupMsgCodecNormal|baseDecode", "the data is not end with ]");
                return false;
            }
            String msgProcess2 = msgProcess.substring(0, msgProcess.length() - 1);
            int posOfCmdEndToken = msgProcess2.indexOf("[", 0);
            String cmdName = msgProcess2.substring(0, posOfCmdEndToken);
            String msgProcess3 = msgProcess2.substring(posOfCmdEndToken + 1);
            List<String> params = new ArrayList<>();
            int index = msgProcess3.indexOf("][");
            while (index != -1) {
                String p = msgProcess3.substring(0, index);
                params.add(p);
                msgProcess3 = msgProcess3.substring("][".length() + index);
                index = msgProcess3.indexOf("][");
            }
            params.add(msgProcess3);
            outData.put(CmdParam.cmd, cmdName);
            if (params.size() <= 2) {
                Log.e("GroupMsgCodecNormal|baseDecode", "参数太少，缺少必要参数");
                return false;
            }
            outData.put(CmdParam.taskId, params.get(0));
            outData.put("mac", params.get(1));
            if (cmdName.equalsIgnoreCase(CmdDef.LI) || cmdName.equalsIgnoreCase(CmdDef.REG) || cmdName.equalsIgnoreCase(CmdDef.REGACCEPT)) {
                outData.put(CmdParam.isResp, CmdParam.deviceType_ipc);
            } else {
                outData.put(CmdParam.isResp, CmdParam.deviceType_dvr);
            }
            if (cmdName.equalsIgnoreCase(CmdDef.REG)) {
                return parseCmdLi(params, outData);
            }
            if (cmdName.equalsIgnoreCase(CmdDef.LI)) {
                return parseCmdReg(params, outData);
            }
            Log.e("GroupMsgCodecNormal|baseDecode", "the cmd [" + cmdName + "] has no decode/encode function");
            return false;
        }
        Log.e("GroupMsgCodecNormal|baseDecode", "the data is not start with AT+");
        return false;
    }

    public static String baseEncode(Map<String, Object> sendData) {
        return BuildConfig.FLAVOR;
    }

    public static Boolean parseCmdLi(List<String> params, Map<String, Object> outData) {
        return true;
    }

    public static Boolean parseCmdReg(List<String> params, Map<String, Object> outData) {
        if (params.size() < 4) {
            Log.e("GroupMsgCodecNormal|parseCmdReg", "参数太少，应有4个参数，实际参数个数为" + String.valueOf(params.size()));
            return false;
        }
        String deviceName = params.get(2);
        String deviceType = params.get(3);
        outData.put(CmdParam.deviceName, deviceName);
        outData.put(CmdParam.deviceType, deviceType);
        return true;
    }
}
