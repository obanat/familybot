package com.RanaEman.client.main.ui;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.Robot.client.main.R;

/* loaded from: classes.dex */
public class SampleListFragment extends ListFragment implements View.OnClickListener {
    Button btnGrandMa;
    Button btnGrandPa;
    Button btnOrg;
    Button btnTom;
    TextView headName;
    int iAudiouLike;
    LinearLayout lltAudioLike;

    @Override // android.support.v4.app.ListFragment, android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View myinflater = inflater.inflate(R.layout.list, (ViewGroup) null);
        this.headName = (TextView) myinflater.findViewById(R.id.textView1);
        this.lltAudioLike = (LinearLayout) myinflater.findViewById(R.id.audio_sub);
        this.lltAudioLike.setVisibility(4);
        this.btnOrg = (Button) myinflater.findViewById(R.id.textView2);
        this.btnOrg.setOnClickListener(this);
        this.btnGrandPa = (Button) myinflater.findViewById(R.id.textView3);
        this.btnGrandPa.setOnClickListener(this);
        this.btnGrandMa = (Button) myinflater.findViewById(R.id.textView4);
        this.btnGrandMa.setOnClickListener(this);
        this.btnTom = (Button) myinflater.findViewById(R.id.textView5);
        this.btnTom.setOnClickListener(this);
        return myinflater;
    }

    public void setName(String sname) {
        if (this.headName != null) {
            this.headName.setText(sname);
        }
    }

    public int GetAudiuLike() {
        return this.iAudiouLike;
    }

    public void ShowAudioSubMenu() {
        if (this.lltAudioLike.getVisibility() == 4) {
            this.lltAudioLike.setVisibility(0);
        } else {
            this.lltAudioLike.setVisibility(4);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        SampleAdapter adapter = new SampleAdapter(getActivity());
        adapter.add(new SampleItem(getResources().getString(R.string.txtWiFiSetting), R.drawable.wifi_set));
        adapter.add(new SampleItem(getResources().getString(R.string.txtmycamera), R.drawable.manager));
        adapter.add(new SampleItem(getResources().getString(R.string.txtpatternlock), R.drawable.hand_pwd));
        adapter.add(new SampleItem(getResources().getString(R.string.txtchangeloginpwd), R.drawable.password_set));
        adapter.add(new SampleItem(getResources().getString(R.string.dialog_AboutMe), R.drawable.about_menu));
        setListAdapter(adapter);
    }

    /* loaded from: classes.dex */
    public class SampleAdapter extends ArrayAdapter<SampleItem> {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public SampleAdapter(Context context) {
            super(context, 0);
            //SampleListFragment.this = this$0;
        }

        @Override // android.widget.ArrayAdapter, android.widget.Adapter
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.row, (ViewGroup) null);
            }
            ImageView icon = (ImageView) convertView.findViewById(R.id.row_icon);
            icon.setImageResource(getItem(position).iconRes);
            TextView title = (TextView) convertView.findViewById(R.id.row_title);
            title.setText(getItem(position).tag);
            return convertView;
        }
    }

    /* loaded from: classes.dex */
    private class SampleItem {
        public int iconRes;
        public String tag;

        public SampleItem(String tag, int iconRes) {
            //SampleListFragment.this = r1;
            this.tag = tag;
            this.iconRes = iconRes;
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        if (arg0 == this.btnGrandMa) {
            this.iAudiouLike = 0;
        } else if (arg0 == this.btnGrandPa) {
            this.iAudiouLike = 2;
        } else if (arg0 == this.btnGrandMa) {
            this.iAudiouLike = 3;
        } else if (arg0 == this.btnTom) {
            this.iAudiouLike = 1;
        }
        ShowAudioSubMenu();
    }
}
