package com.RanaEman.client.main.exchange;

import android.util.Log;
import com.RanaEman.client.main.net.IpAddress;
import com.RanaEman.client.main.net.UdpPacket;
import com.RanaEman.client.main.net.UdpProvider;
import com.RanaEman.client.main.net.UdpProviderListener;
import com.RanaEman.client.main.net.UdpSocket;
import java.io.IOException;
import java.net.SocketException;

/* loaded from: classes.dex */
public class UdpExchange implements UdpProviderListener {
    public int listenPort = 12903;
    private OnExchangeRecvListener messageListener;
    UdpSocket socket;
    private UdpProvider udp_provider;

    public void setOnExchangeRecvListener(OnExchangeRecvListener messageListener) {
        this.messageListener = messageListener;
    }

    public Boolean start() {
        try {
            if (this.socket != null) {
                this.socket.close();
                this.socket = null;
            }
            this.socket = new UdpSocket(this.listenPort);
            this.listenPort = this.socket.getLocalPort();
            this.udp_provider = new UdpProvider(this.socket, this);
            return true;
        } catch (SocketException e) {
            return false;
        }
    }

    public void halt() {
        if (this.udp_provider != null) {
            this.udp_provider.halt();
            this.udp_provider = null;
        }
    }

    public boolean isRunning() {
        return this.udp_provider != null && this.udp_provider.isAlive() && this.udp_provider.isRunning();
    }

    public void checkStatus() {
        if (!isRunning()) {
            start();
        }
    }

    @Override // com.RanaEman.client.main.net.UdpProviderListener
    public void onReceivedPacket(UdpProvider udp, UdpPacket packet) {
        String rowMessage = new String(packet.getData(), packet.getOffset(), packet.getLength());
        Log.e("UdpExchangeServer", rowMessage);
        String remoteIp = packet.getIpAddress().toString();
        String remotePort = String.valueOf(packet.getPort());
        if (this.messageListener != null) {
            Log.e("UdpExchangeServer", "begin to call messageListener.OnExchangeRecv");
            this.messageListener.OnExchangeRecv(rowMessage, remoteIp, remotePort, MainExchange.EXCHANGE_PROTOCOL_UDP);
            return;
        }
        Log.e("UdpExchangeServer", "messageListener is null, can not call it");
    }

    @Override // com.RanaEman.client.main.net.UdpProviderListener
    public void onServiceTerminated(UdpProvider udp, Exception error) {
        Log.e("UdpExchangeServer", "to be terminated, error is : " + error.toString());
    }

    public int getListenPort() {
        return this.listenPort;
    }

    public Boolean sendMessage(IpAddress dest_ipaddr, int dest_port, String message) {
        if (this.udp_provider.isAlive() && this.udp_provider.isRunning()) {
            byte[] buff = message.getBytes();
            UdpPacket packet = new UdpPacket(buff, buff.length, dest_ipaddr, dest_port);
            try {
                this.udp_provider.send(packet);
                return true;
            } catch (IOException e) {
                Log.e("UdpExchange|sendMessage", "Udn IOException");
                return false;
            }
        }
        start();
        return sendMessage(dest_ipaddr, dest_port, message);
    }
}
