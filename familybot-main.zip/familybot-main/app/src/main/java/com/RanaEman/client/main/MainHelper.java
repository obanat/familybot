package com.RanaEman.client.main;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;

/* loaded from: classes.dex */
public class MainHelper {
    public static Context context;
    public static String localMac = com.jeremyfeinstein.slidingmenu.lib.BuildConfig.FLAVOR;
    public static String localIp = com.jeremyfeinstein.slidingmenu.lib.BuildConfig.FLAVOR;
    public static String imeiNumber = com.jeremyfeinstein.slidingmenu.lib.BuildConfig.FLAVOR;
    public static String phoneNumber = com.jeremyfeinstein.slidingmenu.lib.BuildConfig.FLAVOR;

    public static String getLocalMac() {
        if (localMac == null || localMac.length() == 0) {
            initLocalNetworkInfo();
        }
        return localMac;
    }

    public static String getLocalIp() {
        if (localIp == null || localIp.length() == 0) {
            initLocalNetworkInfo();
        }
        return localIp;
    }

    public static void refreshLocalIp() {
        initLocalNetworkInfo();
    }

    public static boolean isSelf(String mac) {
        String localMac2 = getLocalMac();
        return localMac2.equalsIgnoreCase(mac);
    }

    private static void initLocalNetworkInfo() {
        if (context != null) {
            WifiManager wifi = (WifiManager) context.getSystemService("wifi");
            WifiInfo info = wifi.getConnectionInfo();
            localIp = converInt2IpStr(info.getIpAddress());
            localMac = info.getMacAddress();
        }
    }

    private static void initLocalPhoneInfo() {
        if (context != null) {
            TelephonyManager tm = (TelephonyManager) context.getSystemService("phone");
            imeiNumber = tm.getDeviceId();
            phoneNumber = tm.getLine1Number();
        }
    }

    public static String converInt2IpStr(int ip) {
        return (ip & 255) + "." + ((ip >> 8) & 255) + "." + ((ip >> 16) & 255) + "." + ((ip >> 24) & 255);
    }

    public static String getImei() {
        if (imeiNumber == null || imeiNumber.length() == 0) {
            initLocalPhoneInfo();
        }
        return imeiNumber;
    }

    public String getPhoneNumber() {
        if (phoneNumber == null || phoneNumber.length() == 0) {
            initLocalPhoneInfo();
        }
        return phoneNumber;
    }

    static boolean isNetworkAvailable() {
        ConnectivityManager conn;
        NetworkInfo net;
        return (context == null || (conn = (ConnectivityManager) context.getSystemService("connectivity")) == null || (net = conn.getActiveNetworkInfo()) == null || !net.isConnected()) ? false : true;
    }

    public static Boolean isWLan() {
        return true;
    }
}
