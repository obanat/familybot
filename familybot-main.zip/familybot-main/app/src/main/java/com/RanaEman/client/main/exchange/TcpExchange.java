package com.RanaEman.client.main.exchange;

import android.util.Log;
import com.RanaEman.client.main.net.IpAddress;
import com.RanaEman.client.main.net.TcpConnection;
import com.RanaEman.client.main.net.TcpConnectionListener;
import com.RanaEman.client.main.net.TcpSocket;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.io.IOException;

/* loaded from: classes.dex */
public class TcpExchange implements TcpConnectionListener {
    private OnExchangeRecvListener messageListener;
    private TcpConnection tcp_conn;

    public String getProtocol() {
        return CmdParam.tcp;
    }

    public Boolean isValid() {
        return Boolean.valueOf(this.tcp_conn.isRunning());
    }

    public IpAddress getRemoteAddress() {
        if (this.tcp_conn != null) {
            return this.tcp_conn.getRemoteAddress();
        }
        return null;
    }

    public int getRemotePort() {
        if (this.tcp_conn != null) {
            return this.tcp_conn.getRemotePort();
        }
        return 0;
    }

    public void halt() {
        if (this.tcp_conn != null) {
            this.tcp_conn.halt();
        }
    }

    public void setOnExchangeRecvListener(OnExchangeRecvListener messageListener) {
        this.messageListener = messageListener;
    }

    public TcpExchange(IpAddress remoteIp, int remotePort, OnExchangeRecvListener listener) throws IOException {
        this.messageListener = listener;
        TcpSocket socket = new TcpSocket(remoteIp, remotePort);
        this.tcp_conn = new TcpConnection(socket, this);
    }

    public TcpExchange(TcpSocket socket, OnExchangeRecvListener listener) {
        this.messageListener = listener;
        this.tcp_conn = new TcpConnection(socket, this);
    }

    public Boolean sendMessage(String msg) {
        try {
            this.tcp_conn.send(msg.getBytes());
            return true;
        } catch (IOException e) {
            Log.e("TcpExchange", "sendMessage failed");
            return false;
        }
    }

    @Override // com.RanaEman.client.main.net.TcpConnectionListener
    public void onReceivedData(TcpConnection tcp_conn, byte[] data, int len) {
        String rowMessage = new String(data, 0, len);
        String remoteIp = tcp_conn.getRemoteAddress().toString();
        String remotePort = String.valueOf(tcp_conn.getRemotePort());
        Log.e("TcpExchange", "onReceivedData : " + rowMessage);
        if (this.messageListener != null) {
            Log.e("TcpExchange", "onReceivedData : call the listener OnExchangeRecv");
            this.messageListener.OnExchangeRecv(rowMessage, remoteIp, remotePort, CmdParam.tcp);
        }
    }

    @Override // com.RanaEman.client.main.net.TcpConnectionListener
    public void onConnectionTerminated(TcpConnection tcp_conn, Exception error) {
        String errMsg = BuildConfig.FLAVOR;
        if (error != null) {
            errMsg = error.getMessage();
        }
        Log.e("TcpExchange", "onConnectionTerminated :" + errMsg);
        this.messageListener.OnExchangeConnectionTerminated(this, error);
        TcpSocket socket = tcp_conn.getSocket();
        if (socket != null) {
            try {
                socket.close();
            } catch (Exception e) {
            }
        }
        this.tcp_conn = null;
        this.messageListener = null;
    }
}
