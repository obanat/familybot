package com.RanaEman.client.main.net;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;

/* loaded from: classes.dex */
public class TcpConnection extends Thread {
    static final int BUFFER_SIZE = 65535;
    public static final int DEFAULT_SOCKET_TIMEOUT = 2000;
    long alive_time;
    Exception error;
    boolean is_running;
    InputStream istream;
    TcpConnectionListener listener;
    OutputStream ostream;
    TcpSocket socket;
    int socket_timeout;
    boolean stop;

    public TcpConnection(TcpSocket socket, TcpConnectionListener listener) {
        init(socket, 0L, listener);
        start();
    }

    public TcpConnection(TcpSocket socket, long alive_time, TcpConnectionListener listener) {
        init(socket, alive_time, listener);
        start();
    }

    private void init(TcpSocket socket, long alive_time, TcpConnectionListener listener) {
        this.listener = listener;
        this.socket = socket;
        this.socket_timeout = 2000;
        this.alive_time = alive_time;
        this.stop = false;
        this.is_running = true;
        this.istream = null;
        this.ostream = null;
        this.error = null;
        try {
            this.istream = new BufferedInputStream(socket.getInputStream());
            this.ostream = new BufferedOutputStream(socket.getOutputStream());
        } catch (Exception e) {
            this.error = e;
        }
    }

    public boolean isRunning() {
        return this.is_running;
    }

    public TcpSocket getSocket() {
        return this.socket;
    }

    public IpAddress getRemoteAddress() {
        return this.socket.getAddress();
    }

    public int getRemotePort() {
        return this.socket.getPort();
    }

    public void halt() {
        this.stop = true;
    }

    public void send(byte[] buff, int offset, int len) throws IOException {
        if (!this.stop && this.ostream != null) {
            this.ostream.write(buff, offset, len);
            this.ostream.flush();
        }
    }

    public void send(byte[] buff) throws IOException {
        send(buff, 0, buff.length);
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        byte[] buff = new byte[65535];
        long expire = 0;
        if (this.alive_time > 0) {
            expire = System.currentTimeMillis() + this.alive_time;
        }
        try {
        } catch (Exception e) {
            this.error = e;
            this.stop = true;
        }
        if (this.error != null) {
            //throw this.error;
        }
        while (!this.stop) {
            int len = 0;
            if (this.istream != null) {
                try {
                    len = this.istream.read(buff);
                } catch (IOException e2) {
                    if (this.alive_time > 0 && System.currentTimeMillis() > expire) {
                        halt();
                    }
                }
            }
            if (len < 0) {
                this.stop = true;
            } else if (len > 0) {
                if (this.listener != null) {
                    this.listener.onReceivedData(this, buff, len);
                }
                if (this.alive_time > 0) {
                    expire = System.currentTimeMillis() + this.alive_time;
                }
            }
        }
        this.is_running = false;
        if (this.istream != null) {
            try {
                this.istream.close();
            } catch (Exception e3) {
            }
        }
        if (this.ostream != null) {
            try {
                this.ostream.close();
            } catch (Exception e4) {
            }
        }
        if (this.listener != null) {
            this.listener.onConnectionTerminated(this, this.error);
        }
        this.listener = null;
    }

    @Override // java.lang.Thread
    public String toString() {
        return "tcp:";
    }
}
