package com.RanaEman.client.main;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.RanaEman.client.main.net.TcpServer;
import com.tutk.IOTC.AVAPIs;
import com.tutk.IOTC.Camera;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class UpdateManager {
    private static final int DOWN_ERR = 4;
    private static final int DOWN_OVER = 2;
    private static final int DOWN_UPDATE = 1;
    private static final int START_UPDATE = 0;
    private static final int USER_CANCEL = 3;
    Dialog dialog;
    private Thread downLoadThread;
    private Dialog downloadDialog;
    private int iOldCode;
    private Context mContext;
    private ProgressBar mProgress;
    private TextView mTvShow;
    private int progress;
    private String strShow;
    private static String savePath = com.jeremyfeinstein.slidingmenu.lib.BuildConfig.FLAVOR;
    private static String saveFileName = savePath + "UpdateDemoRelease.apk";
    private String TAG = "UpdateManager";
    private String apkUrl = "http://www.Family Robot.com/download/Family Robot.apk";
    private String xmlUrl = "http://www.Family Robot.com/download/UpdateInfo.xml";
    private boolean interceptFlag = false;
    private Handler mHandler = new Handler() { // from class: com.RanaEman.client.main.UpdateManager.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    UpdateManager.this.showDownDialogNew();
                    return;
                case 1:
                    UpdateManager.this.mTvShow.setText(UpdateManager.this.strShow);
                    UpdateManager.this.mProgress.setProgress(UpdateManager.this.progress);
                    return;
                case 2:
                    UpdateManager.this.dialog.dismiss();
                    UpdateManager.this.installApk();
                    return;
                case 3:
                    UpdateManager.this.dialog.dismiss();
                    Intent bcCancelIntent = new Intent("ACTION_USER_CACEL_UPDATE");
                    UpdateManager.this.mContext.sendBroadcast(bcCancelIntent);
                    return;
                case 4:
                    UpdateManager.this.dialog.dismiss();
                    Intent bcErrlIntent = new Intent("ACTION_DWON_ERR");
                    UpdateManager.this.mContext.sendBroadcast(bcErrlIntent);
                    return;
                default:
                    return;
            }
        }
    };
    private Runnable mdownApkRunnable = new Runnable() { // from class: com.RanaEman.client.main.UpdateManager.3
        @Override // java.lang.Runnable
        public void run() {
            try {
                URL url = new URL(UpdateManager.this.apkUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(Camera.RDT_WAIT_TIMEMS);
                conn.connect();
                int length = conn.getContentLength();
                InputStream is = conn.getInputStream();
                File file = new File(UpdateManager.savePath);
                if (!file.exists()) {
                    file.mkdir();
                }
                String apkFile = UpdateManager.saveFileName;
                File ApkFile = new File(apkFile);
                FileOutputStream fos = new FileOutputStream(ApkFile);
                int count = 0;
                byte[] buf = new byte[1024];
                while (true) {
                    int numread = is.read(buf);
                    count += numread;
                    UpdateManager.this.progress = (int) ((count / length) * 100.0f);
                    UpdateManager.this.strShow = UpdateManager.this.progress + "%(" + (count / AVAPIs.TIME_SPAN_LOSED) + "KB/" + (length / AVAPIs.TIME_SPAN_LOSED) + "KB)";
                    UpdateManager.this.mHandler.sendEmptyMessage(1);
                    if (numread <= 0) {
                        UpdateManager.this.mHandler.sendEmptyMessage(2);
                        break;
                    }
                    fos.write(buf, 0, numread);
                    if (UpdateManager.this.interceptFlag) {
                        break;
                    }
                }
                if (UpdateManager.this.interceptFlag) {
                    UpdateManager.this.mHandler.sendEmptyMessage(3);
                }
                fos.close();
                is.close();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                Log.e(UpdateManager.this.TAG, "err:" + e.getMessage().toString());
                UpdateManager.this.mHandler.sendEmptyMessage(4);
            } catch (IOException e2) {
                e2.printStackTrace();
                Log.e(UpdateManager.this.TAG, "err:" + e2.getMessage().toString());
                UpdateManager.this.mHandler.sendEmptyMessage(4);
            }
        }
    };

    public UpdateManager(Context context, int VersionCode) {
        this.iOldCode = VersionCode;
        this.mContext = context;
        savePath = Environment.getExternalStorageDirectory().getPath() + "/eMan/";
        saveFileName = savePath + "ranaUpdateTemp.apk";
    }

    /* loaded from: classes.dex */
    public class UpdataInfo {
        private String description;
        private String url;
        private String version;

        public UpdataInfo() {
            //UpdateManager.this = this$0;
        }

        public String getVersion() {
            return this.version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getUrl() {
            return this.url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }
    }

    public void StartDownApk() {
        this.mHandler.sendEmptyMessage(0);
    }

    public static final boolean ping() {
        int status = 0;
        String result = null;
        try {
            Process p = Runtime.getRuntime().exec("ping -c 2 -w 100 www.baidu.com");
            InputStream input = p.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(input));
            StringBuffer stringBuffer = new StringBuffer();
            while (true) {
                String content = in.readLine();
                if (content == null) {
                    break;
                }
                stringBuffer.append(content);
            }
            Log.e("------ping-----", "result content : " + stringBuffer.toString());
            status = p.waitFor();
        } catch (IOException e) {
            result = "IOException";
        } catch (InterruptedException e2) {
            result = "InterruptedException";
        } finally {
            Log.e("----result---", "result = " + result);
        }
        if (status != 0) {
            result = "failed";
            return false;
        }
        Log.e("----result---", "www.baidu.com is OK.");
        result = "success";
        return true;
    }

    public boolean checkUpdateInfo() {
        boolean z = false;
        try {
            URL url = new URL(this.xmlUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(TcpServer.DEFAULT_SOCKET_TIMEOUT);
            conn.setConnectTimeout(TcpServer.DEFAULT_SOCKET_TIMEOUT);
            conn.connect();
            InputStream is = conn.getInputStream();
            UpdataInfo info = getUpdataInfo(is);
            int iNewCode = Integer.valueOf(info.getVersion()).intValue();
            is.close();
            conn.disconnect();
            if (iNewCode > this.iOldCode) {
                Log.e(this.TAG, "版本号不同 ,提示用户升级 ");
                z = true;
            } else {
                Log.e(this.TAG, "版本号相同无需升级");
            }
        } catch (Exception e) {
            Log.e(this.TAG, "err:" + e.getMessage().toString());
            e.printStackTrace();
        }
        return z;
    }

    public UpdataInfo getUpdataInfo(InputStream is) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(is, "utf-8");
        UpdataInfo info = new UpdataInfo();
        for (int type = parser.getEventType(); type != 1; type = parser.next()) {
            switch (type) {
                case 2:
                    if ("version".equals(parser.getName())) {
                        info.setVersion(safeNextText(parser));
                        break;
                    } else if ("url".equals(parser.getName())) {
                        info.setUrl(safeNextText(parser));
                        break;
                    } else if ("description".equals(parser.getName())) {
                        info.setDescription(safeNextText(parser));
                        break;
                    } else {
                        break;
                    }
            }
        }
        return info;
    }

    private String safeNextText(XmlPullParser parser) throws XmlPullParserException, IOException {
        String result = parser.nextText();
        if (parser.getEventType() != 3) {
            parser.nextTag();
        }
        return result;
    }

    public void showDownDialogNew() {
        this.dialog = new Dialog(this.mContext, com.Robot.client.main.R.style.Tips);
        this.dialog.setContentView(com.Robot.client.main.R.layout.myprogress_dialog_dwon);
        this.mTvShow = (TextView) this.dialog.findViewById(com.Robot.client.main.R.id.txtMessage);
        this.mTvShow.setText("0% " + this.mContext.getString(com.Robot.client.main.R.string.txtgetfile));
        this.mProgress = (ProgressBar) this.dialog.findViewById(com.Robot.client.main.R.id.progressBar1);
        Button btnButton = (Button) this.dialog.findViewById(com.Robot.client.main.R.id.btnSure);
        btnButton.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.UpdateManager.2
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                UpdateManager.this.dialog.dismiss();
                UpdateManager.this.interceptFlag = true;
            }
        });
        this.dialog.setCancelable(false);
        this.dialog.show();
        downloadApk();
    }

    private void downloadApk() {
        this.downLoadThread = new Thread(this.mdownApkRunnable);
        this.downLoadThread.start();
    }

    public void installApk() {
        Intent bcCancelIntent = new Intent("ACTION_INSTALL_APK");
        bcCancelIntent.putExtra("APKNAME", saveFileName);
        this.mContext.sendBroadcast(bcCancelIntent);
    }
}
