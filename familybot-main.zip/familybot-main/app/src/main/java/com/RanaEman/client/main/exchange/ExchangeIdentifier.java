package com.RanaEman.client.main.exchange;

import com.RanaEman.client.main.net.IpAddress;

/* loaded from: classes.dex */
public class ExchangeIdentifier extends Identifier {
    public ExchangeIdentifier(String protocol, IpAddress remote_ipaddr, int remote_port) {
        super(getId(protocol, remote_ipaddr, remote_port));
    }

    public ExchangeIdentifier(ExchangeIdentifier conn_id) {
        super(conn_id);
    }

    public ExchangeIdentifier(String id) {
        super(id);
    }

    public ExchangeIdentifier(TcpExchange conn) {
        super(getId(conn.getProtocol(), conn.getRemoteAddress(), conn.getRemotePort()));
    }

    private static String getId(String protocol, IpAddress remote_ipaddr, int remote_port) {
        return protocol + ":" + remote_ipaddr + ":" + remote_port;
    }
}
