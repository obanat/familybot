package com.RanaEman.client.main;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.RanaEman.client.main.data.DataCenter;
import com.RanaEman.client.main.data.LocalDvrDBAdapter;
import com.RanaEman.client.main.data.localDvrItem;
import com.tutk.IOTC.Camera;
import com.tutk.IOTC.IRegisterIOTCListener;
import com.tutk.IOTC.MyCamera;
import com.tutk.IOTC.Packet;
import java.io.File;
import java.util.Locale;

/* loaded from: classes.dex */
public class SigCameraService extends Service implements IRegisterIOTCListener {
    private BroadcastReceiver oBroadcastReceiver = new BroadcastReceiver() { // from class: com.RanaEman.client.main.SigCameraService.1
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String sActionString = intent.getAction();
            Log.e(SigCameraService.tag, sActionString);
            if (sActionString.equals(SigCameraService.ACTION_ADDUID)) {
                String sUID = intent.getExtras().getString("UID");
                Log.e(SigCameraService.tag, SigCameraService.ACTION_ADDUID + ":" + sUID);
                SigCameraService.sDefaultUID = sUID;
                if (SigCameraService.sDefaultUID != null && SigCameraService.iLastNetStatus == ConnectivityManager.TYPE_WIFI) {
                    new threadNewConnectUID(SigCameraService.sDefaultUID).start();
                    Log.e(SigCameraService.tag, "threadNewConnectUID:" + sUID);
                }
            } else if (sActionString.equals(SigCameraService.ACTION_DELUID)) {
                String dVRUIDtring = intent.getExtras().getString("UID");
                Log.e(SigCameraService.tag, dVRUIDtring + "->delete_start!");
                if (SigCameraService.MainCamera != null && dVRUIDtring.equals(SigCameraService.MainCamera.getUID())) {
                    SigCameraService.MainCamera.unregisterIOTCListener(SigCameraService.this);
                    SigCameraService.MainCamera.disconnect();
                    SigCameraService.MainCamera = null;
                }
            } else if (!sActionString.equals(SigCameraService.ACTION_MODIUIDPWD)) {
                if (sActionString.equals(SigCameraService.ACTION_NETOK)) {
                    int iCurrentStatus = SigCameraService.getAPNType(SigCameraService.this.getApplicationContext());
                    Log.e(SigCameraService.tag, "iLastNetStatus:" + SigCameraService.iLastNetStatus + "->" + iCurrentStatus);
                    if (iCurrentStatus != SigCameraService.iLastNetStatus) {
                        SigCameraService.iLastNetStatus = iCurrentStatus;
                        if (SigCameraService.MainCamera != null) {
                            if (SigCameraService.iLastNetStatus > 0) {
                                SigCameraService.MainCamera.connect(SigCameraService.MainCamera.getUID());
                                SigCameraService.MainCamera.start(0, "admin", SigCameraService.MainCamera.getPassword());
                                Intent intentOnline = new Intent();
                                intentOnline.setAction(SigCameraService.ACTION_NEWUIDOK);
                                SigCameraService.this.sendBroadcast(intentOnline);
                                return;
                            }
                            SigCameraService.MainCamera.disconnect();
                            Intent intentNetOff = new Intent();
                            intentNetOff.setAction(SigCameraService.ACTION_NET_OFFLINE);
                            SigCameraService.this.sendBroadcast(intentNetOff);
                        }
                    }
                }
            } else {
                Bundle dataBundle = intent.getExtras();
                String dVRUIDtring2 = dataBundle.getString("UID");
                String dVRPwd = dataBundle.getString("PWD");
                Log.e(SigCameraService.tag, dVRUIDtring2 + "->modi_pwd!");
                SigCameraService.MainCamera.disconnect();
                SigCameraService.MainCamera.SetPassword(dVRPwd);
                SigCameraService.MainCamera.connect(SigCameraService.MainCamera.getUID());
                SigCameraService.MainCamera.start(0, "admin", dVRPwd);
            }
        }
    };
    private static String ACTION_NETOK = "android.net.conn.CONNECTIVITY_CHANGE";
    public static String ACTION_DELUID = "android.intent.action.ACTION_DELUID";
    public static String ACTION_ADDUID = "android.intent.action.ACTION_ADDUID";
    public static String ACTION_MODIUIDPWD = "android.intent.action.ACTION_MODIUIDPWD";
    public static String ACTION_REFDVRLIST = "android.intent.action.ACTION_REFDVRLIST";
    public static String ACTION_NEWUIDOK = "android.intent.action.ACTION_NEWUIDOK";
    public static String ACTION_NET_OFFLINE = "android.intent.action.ACTION_NET_OFFLINE";
    public static String ACTION_RESENDRECORD_G726FILE = "ACTION_RESENDRECORD_G726FILE";
    public static MyCamera MainCamera = null;
    static String tag = "Sig_CameraService";
    public static int iLastNetStatus = -1;
    public static int ilanguage = 0;
    public static Boolean blnDirOk = false;
    public static String sDefaultUID = null;

    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        Camera.init();
        if (sDefaultUID != null) {
            localDvrItem itemtemp = DataCenter.localdvritems.get(sDefaultUID);
            MainCamera = new MyCamera(itemtemp.dvr_name, itemtemp.dvr_id, itemtemp.dvr_pwd);
            MainCamera.iAP = itemtemp.device_type;
            MainCamera.registerIOTCListener(this);
            Log.e(tag, sDefaultUID + "->new!!!");
            iLastNetStatus = getAPNType(getApplicationContext());
            if (iLastNetStatus > 0) {
                MainCamera.connect(MainCamera.getUID());
                MainCamera.start(0, "admin", MainCamera.getPassword());
            }
        } else {
            Log.e(tag, "sDefaultUID==null");
        }
        registerBroadcastReceiver();
        String language = Locale.getDefault().getLanguage();
        if (language.trim().equals("zh")) {
            ilanguage = 0;
        } else {
            ilanguage = 1;
        }
        blnDirOk = IniDir();
        super.onCreate();
    }

    private Boolean IniDir() {
        File fdir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/");
        if (!fdir.exists()) {
            fdir.mkdir();
        }
        String mainPath = fdir.getPath();
        File fdir2 = new File(mainPath + "/Shot/");
        if (!fdir2.exists()) {
            fdir2.mkdir();
        }
        File fdir3 = new File(mainPath + "/CustomVoice/");
        if (!fdir3.exists()) {
            fdir3.mkdir();
        }
        File fdir4 = new File(mainPath + "/RecvAudio/");
        if (!fdir4.exists()) {
            fdir4.mkdir();
        }
        File fdir5 = new File(mainPath + "/SendAudio/");
        if (!fdir5.exists()) {
            fdir5.mkdir();
        }
        File fdir6 = new File(mainPath + "/Exprission/");
        if (!fdir6.exists()) {
            fdir6.mkdir();
        }
        return true;
    }

    public static int getAPNType(Context context) {
        int netType = 0;
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService("connectivity");
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo == null) {
            return 0;
        }
        int nType = networkInfo.getType();
        if (nType == 1) {
            netType = 1;
        } else if (nType == 0) {
            int nSubType = networkInfo.getSubtype();
            TelephonyManager mTelephony = (TelephonyManager) context.getSystemService("phone");
            if (nSubType == 3 && !mTelephony.isNetworkRoaming()) {
                netType = 2;
            } else {
                netType = 3;
            }
        }
        return netType;
    }

    public void registerBroadcastReceiver() {
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction(ACTION_DELUID);
        myIntentFilter.addAction(ACTION_ADDUID);
        myIntentFilter.addAction(ACTION_MODIUIDPWD);
        myIntentFilter.addAction(ACTION_NETOK);
        registerReceiver(this.oBroadcastReceiver, myIntentFilter);
    }

    public void unRegisterBoradcastReceiver() {
        unregisterReceiver(this.oBroadcastReceiver);
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveChannelInfo(Camera paramCamera, int paramInt1, int paramInt2) {
        paramCamera.iStatus = paramInt2;
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveFrameInfo(Camera paramCamera, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveIOCtrlData(Camera paramCamera, int paramInt1, int paramInt2, byte[] paramArrayOfByte) {
        float fbat;
        Log.e(tag, "receiveIOCtrlData paramInt2:" + paramInt2);
        if (DataCenter.localdvritems.containsKey(paramCamera.mDevUID)) {
            localDvrItem dvritem = DataCenter.localdvritems.get(paramCamera.mDevUID);
            if (paramInt2 == 948) {
                if (dvritem.status != 5 && dvritem.status != 0) {
                    dvritem.status = (paramArrayOfByte[0] + 1) | (dvritem.status & 256);
                    return;
                }
                return;
            } else if (paramInt2 == 1121) {
                String sNewName = new String(paramArrayOfByte, 16, 36).trim();
                int iLed = Packet.byteArrayToInt_Little(paramArrayOfByte, 4);
                MainCamera.setRecharge(Boolean.valueOf(iLed == 0));
                Log.e(tag, "MainCamera.setRecharge:" + MainCamera.isRecharge());
                dvritem.iBat = Packet.byteArrayToInt_Little(paramArrayOfByte, 8);
                float fbat2 = 4.0f - (dvritem.iBat * 0.0064f);
                if (fbat2 > 0.0f) {
                    if (fbat2 < 0.5f) {
                        fbat = (1.0f - (fbat2 / 0.5f)) * 100.0f;
                    } else {
                        fbat = 1.0f;
                    }
                } else {
                    fbat = 100.0f;
                }
                dvritem.iBat = (int) fbat;
                MainCamera.setBat(dvritem.iBat);
                String sOldName = dvritem.dvr_name;
                if (!sNewName.equals(sOldName) && !sNewName.isEmpty()) {
                    dvritem.dvr_name = sNewName;
                    DataCenter.UpdatelocalDvrFromDB(LocalDvrDBAdapter.DVR_NAME, sNewName, paramCamera.mDevUID);
                    if (MainCamera != null && MainCamera.getUID().equals(dvritem.dvr_id)) {
                        MainCamera.setName(sNewName);
                        return;
                    }
                    return;
                }
                return;
            } else {
                return;
            }
        }
        Log.e(tag, "Not UID????");
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveSessionInfo(Camera paramCamera, int paramInt) {
        Log.e(tag, "receiveSessionInfo:" + paramInt);
        if (DataCenter.localdvritems.containsKey(paramCamera.mDevUID)) {
            if (paramInt == 9999) {
                new initAllAndConnectUID(paramCamera.mDevUID).start();
                Log.e(tag, "initAllAndConnectUID...");
                return;
            }
            paramCamera.iStatus = paramInt;
            if (paramInt == 6 || paramInt == 7 || paramInt == 8) {
                iLastNetStatus = getAPNType(getApplicationContext());
                if (iLastNetStatus > 0) {
                    Log.e(tag, "threadReconnecting:");
                    new threadReconnecting(paramCamera.mDevUID).start();
                    return;
                }
                Log.e(tag, "MainCamera.disconnect()");
                MainCamera.disconnect();
            } else if (paramInt == 4) {
                iLastNetStatus = getAPNType(getApplicationContext());
                if (iLastNetStatus == 0) {
                    Log.e(tag, "MainCamera.disconnect()");
                    MainCamera.disconnect();
                }
            }
        }
    }

    /* loaded from: classes.dex */
    public class threadReconnecting extends Thread {
        private String UID;

        public threadReconnecting(String uid) {
            //SigCameraService.this = this$0;
            this.UID = uid;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            if (SigCameraService.MainCamera != null) {
                SigCameraService.MainCamera.disconnect();
                if (SigCameraService.MainCamera.getUID().equals(this.UID)) {
                    SigCameraService.MainCamera.connect(this.UID);
                    SigCameraService.MainCamera.start(0, "admin", SigCameraService.MainCamera.getPassword());
                } else {
                    SigCameraService.MainCamera.unregisterIOTCListener(SigCameraService.this);
                    SigCameraService.MainCamera = null;
                }
            }
            if (SigCameraService.MainCamera == null) {
                localDvrItem Item = DataCenter.localdvritems.get(this.UID);
                SigCameraService.MainCamera = new MyCamera(Item.dvr_name, Item.dvr_id, Item.dvr_pwd);
                SigCameraService.MainCamera.iAP = Item.device_type;
                SigCameraService.MainCamera.connect(this.UID);
                SigCameraService.MainCamera.start(0, "admin", SigCameraService.MainCamera.getPassword());
                SigCameraService.MainCamera.registerIOTCListener(SigCameraService.this);
            }
        }
    }

    /* loaded from: classes.dex */
    public class threadNewConnectUID extends Thread {
        private String UID;

        public threadNewConnectUID(String uid) {
            //SigCameraService.this = this$0;
            this.UID = uid;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            if (SigCameraService.MainCamera != null) {
                SigCameraService.MainCamera.unregisterIOTCListener(SigCameraService.this);
                SigCameraService.MainCamera.disconnect();
                SigCameraService.MainCamera = null;
            }
            localDvrItem Item = DataCenter.localdvritems.get(this.UID);
            SigCameraService.MainCamera = new MyCamera(Item.dvr_name, Item.dvr_id, Item.dvr_pwd);
            SigCameraService.MainCamera.iAP = Item.device_type;
            SigCameraService.MainCamera.connect(this.UID);
            SigCameraService.MainCamera.start(0, "admin", SigCameraService.MainCamera.getPassword());
            SigCameraService.MainCamera.registerIOTCListener(SigCameraService.this);
            Intent intent = new Intent();
            intent.setAction(SigCameraService.ACTION_NEWUIDOK);
            SigCameraService.this.sendBroadcast(intent);
        }
    }

    /* loaded from: classes.dex */
    public class threadDisconnectUID extends Thread {
        private String UID;

        public threadDisconnectUID(String uid) {
            //SigCameraService.this = this$0;
            this.UID = uid;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            if (SigCameraService.MainCamera != null) {
                SigCameraService.MainCamera.unregisterIOTCListener(SigCameraService.this);
                SigCameraService.MainCamera.disconnect();
                SigCameraService.MainCamera = null;
            }
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        Log.e(tag, "CameraServiceonDestroy!!!");
        unRegisterBoradcastReceiver();
        if (MainCamera != null) {
            MainCamera.unregisterIOTCListener(this);
            MainCamera.disconnect();
            MainCamera = null;
        }
        Camera.uninit();
        super.onDestroy();
    }

    /* loaded from: classes.dex */
    public class initAllAndConnectUID extends Thread {
        private String UID;

        public initAllAndConnectUID(String uid) {
            //SigCameraService.this = this$0;
            this.UID = uid;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            if (SigCameraService.MainCamera != null) {
                SigCameraService.MainCamera.unregisterIOTCListener(SigCameraService.this);
                SigCameraService.MainCamera.disconnect();
                SigCameraService.MainCamera = null;
            }
            Camera.uninit();
            Camera.init();
            localDvrItem Item = DataCenter.localdvritems.get(this.UID);
            SigCameraService.MainCamera = new MyCamera(Item.dvr_name, Item.dvr_id, Item.dvr_pwd);
            SigCameraService.MainCamera.iAP = Item.device_type;
            SigCameraService.MainCamera.connect(this.UID);
            SigCameraService.MainCamera.start(0, "admin", SigCameraService.MainCamera.getPassword());
            SigCameraService.MainCamera.registerIOTCListener(SigCameraService.this);
            Intent intent = new Intent();
            intent.setAction(SigCameraService.ACTION_NEWUIDOK);
            SigCameraService.this.sendBroadcast(intent);
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveRDTSendFileResult(Camera paramCamera, int iFileKind, int Result, String s, int i) {
    }
}
