package com.RanaEman.client.main.net;

/* loaded from: classes.dex */
public interface UdpProviderListener {
    void onReceivedPacket(UdpProvider udpProvider, UdpPacket udpPacket);

    void onServiceTerminated(UdpProvider udpProvider, Exception exc);
}
