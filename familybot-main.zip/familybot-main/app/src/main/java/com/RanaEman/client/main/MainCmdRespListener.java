package com.RanaEman.client.main;

import com.RanaEman.client.main.exchange.ExchangeMessage;
import java.util.Map;

/* loaded from: classes.dex */
public interface MainCmdRespListener {
    void onCmdResp(String str, ExchangeMessage exchangeMessage, Map<String, Object> map);

    void onCmdTimeout(String str, ExchangeMessage exchangeMessage);
}
