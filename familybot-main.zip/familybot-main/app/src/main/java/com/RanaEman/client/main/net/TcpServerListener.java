package com.RanaEman.client.main.net;

/* loaded from: classes.dex */
public interface TcpServerListener {
    void onIncomingConnection(TcpServer tcpServer, TcpSocket tcpSocket);

    void onServerTerminated(TcpServer tcpServer, Exception exc);
}
