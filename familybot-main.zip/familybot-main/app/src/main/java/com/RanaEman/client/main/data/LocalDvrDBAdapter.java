package com.RanaEman.client.main.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/* loaded from: classes.dex */
public class LocalDvrDBAdapter {
    private static final String DATABASE_CREATEDVR = "create table tbl_dvr (dvr_no INTEGER PRIMARY KEY, dvr_id TEXT, dvr_name TEXT, dvr_mac TEXT, dvr_username TEXT, dvr_pwd TEXT, device_type INTEGER, status INTEGER, last_activetime INTEGER, always_veritypwd INTEGER  );";
    private static final String DATABASE_NAME = "localDvr.db";
    private static final String DATABASE_TABLE_DVR = "tbl_dvr";
    private static final int DATABASE_VERSION = 2;
    public static final String DEV_TPYE = "device_type";
    public static final String DVR_ID = "dvr_id";
    public static final String DVR_LASTACTIVETIME = "last_activetime";
    public static final String DVR_MAC = "dvr_mac";
    public static final String DVR_NAME = "dvr_name";
    public static final String DVR_NO = "dvr_no";
    public static final String DVR_PWD = "dvr_pwd";
    public static final String DVR_STATUS = "status";
    public static final String DVR_USER = "dvr_username";
    public static final String DVR_VERITYPWD = "always_veritypwd";
    private DatabaseHelper DBHelper;
    private final Context context;
    private SQLiteDatabase db;

    public LocalDvrDBAdapter(Context ctx) {
        this.context = ctx;
        this.DBHelper = new DatabaseHelper(this.context);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context, LocalDvrDBAdapter.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 2);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(LocalDvrDBAdapter.DATABASE_CREATEDVR);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS create table tbl_dvr (dvr_no INTEGER PRIMARY KEY, dvr_id TEXT, dvr_name TEXT, dvr_mac TEXT, dvr_username TEXT, dvr_pwd TEXT, device_type INTEGER, status INTEGER, last_activetime INTEGER, always_veritypwd INTEGER  );");
            onCreate(db);
        }
    }

    public SQLiteDatabase open() throws SQLException {
        this.db = this.DBHelper.getWritableDatabase();
        return this.db;
    }

    public void close() {
        this.DBHelper.close();
    }

    public long insert(localDvrItem item) {
        Log.e("LocalDvrAdapter", "begin insert");
        ContentValues initialValues = new ContentValues();
        initialValues.put(DVR_ID, item.dvr_id);
        initialValues.put(DVR_NAME, item.dvr_name);
        initialValues.put(DVR_MAC, item.dvr_mac);
        initialValues.put(DVR_USER, item.dvr_username);
        initialValues.put(DVR_PWD, item.dvr_pwd);
        initialValues.put("device_type", Integer.valueOf(item.device_type));
        initialValues.put("status", Integer.valueOf(item.status));
        initialValues.put(DVR_LASTACTIVETIME, Integer.valueOf(item.last_activetime));
        initialValues.put(DVR_VERITYPWD, Integer.valueOf(item.always_veritypwd));
        long iresult = this.db.insert(DATABASE_TABLE_DVR, null, initialValues);
        Log.e("LocalDvrAdapter", "insert result：" + iresult);
        return iresult;
    }

    public boolean delete(int deviceId) {
        return this.db.delete(DATABASE_TABLE_DVR, new StringBuilder().append("dvr_no=").append(deviceId).toString(), null) > 0;
    }

    public boolean delete(String UID) {
        return this.db.delete(DATABASE_TABLE_DVR, new StringBuilder().append("dvr_id='").append(UID).append("'").toString(), null) > 0;
    }

    public void deleteAll() {
        this.db.delete(DATABASE_TABLE_DVR, null, null);
    }

    public boolean update(localDvrItem item, String oldUID) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(DVR_ID, item.dvr_id);
        initialValues.put(DVR_NAME, item.dvr_name);
        initialValues.put(DVR_PWD, item.dvr_pwd);
        initialValues.put(DVR_VERITYPWD, Integer.valueOf(item.always_veritypwd));
        return this.db.update(DATABASE_TABLE_DVR, initialValues, new StringBuilder().append("dvr_id='").append(oldUID).append("'").toString(), null) > 0;
    }

    public boolean update(String item, String itemValue, String UID) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(item, itemValue);
        return this.db.update(DATABASE_TABLE_DVR, initialValues, new StringBuilder().append("dvr_id='").append(UID).append("'").toString(), null) > 0;
    }

    public Cursor getAll() {
        Cursor cur = this.db.query(DATABASE_TABLE_DVR, null, null, null, null, null, "device_type DESC");
        return cur;
    }

    public Cursor get(long deviceId) throws SQLException {
        Cursor cur = this.db.query(true, DATABASE_TABLE_DVR, null, "dvr_no=" + deviceId, null, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }

    public Cursor getDeviceByUID(String UID) throws SQLException {
        String[] selectionArgs = {UID};
        Cursor cur = this.db.query(true, DATABASE_TABLE_DVR, null, "dvr_id=?", selectionArgs, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }

    public int getMaxID() throws SQLException {
        Cursor cur = this.db.rawQuery("select max(dvr_no)+1 from tbl_dvr", null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur.getInt(0);
    }

    public Cursor getDeviceByMac(String mac) throws SQLException {
        String[] selectionArgs = {mac};
        Cursor cur = this.db.query(true, DATABASE_TABLE_DVR, null, "MAC=?", selectionArgs, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }

    public int getDeviceIdByMac(String mac) throws SQLException {
        Cursor cur = this.db.query(true, DATABASE_TABLE_DVR, null, "dvr_mac=" + mac, null, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur.getInt(0);
    }
}
