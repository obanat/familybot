package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class CmdDef {
    public static String GROUPINFO = "GROUPINFO";
    public static String GETDEVICELIST = "GETDEVICELIST";
    public static String DEVICELISTUPDATE = "DEVICELISTUPDATE";
    public static String FINDHOST = "FINDHOST";
    public static String HOSTHERE = "HOSTHERE";
    public static String CALLINVITE = "CALLINVITE";
    public static String CALLTAKE = "CALLTAKE";
    public static String CALLCLOSE = "CALLCLOSE";
    public static String REG = "REG";
    public static String REGSUCCEED = "REGSUCCEED";
    public static String REGRECOK = "REGRECOK";
    public static String REGFAIL = "REGFAIL";
    public static String LI = "LI";
    public static String LIOK = "LIOK";
    public static String LIFAIL = "LIFAIL";
    public static String VOIP = "VOIP";
    public static String VOIPOK = "VOIPOK";
    public static String GETREGINFO = "GETREGINFO";
    public static String GETREGOK = "GETREGOK";
    public static String REGGETFAIL = "REGGETFAIL";
    public static String GPNAME = "GPNAME";
    public static String GPNAMEOK = "GPNAMEOK";
    public static String MSG = "MSG";
    public static String MSGOK = "MSGOK";
    public static String REGACCEPT = "REGACCEPT";
    public static String REGACCEPTOK = "REGACCEPTOK";
    public static String ERR = "ERR";
    public static String CBEAT = "CBEAT";
    public static String OPENDOOR = "OPENDOOR";
    public static String DOORBELLTRANS = "DOORBELLTRANS";
    public static String RFSOPENDOOR = "RFSOPENDOOR";
    public static String DOORBELLSTOP = "DOORBELLSTOP";
}
