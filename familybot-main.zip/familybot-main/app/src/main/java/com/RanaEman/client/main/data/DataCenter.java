package com.RanaEman.client.main.data;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import com.RanaEman.client.main.MainHelper;
import com.RanaEman.client.main.exchange.CmdParam;
import com.RanaEman.client.main.ui.WelcomeActivity;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class DataCenter {
    static String hostIp = BuildConfig.FLAVOR;
    static String hostPort = BuildConfig.FLAVOR;
    static String hostMac = BuildConfig.FLAVOR;
    public static int TYPE_HOST = -1;
    public static int TYPE_DVR = 0;
    public static int TYPE_IPC = 1;
    public static int TYPE_ANDROIDPHONE = 2;
    public static int TYPE_IPHONE = 3;
    public static LocalDvrDBAdapter dvrDBAdapter = null;
    public static Map<String, localDvrItem> localdvritems = new HashMap();
    public static boolean isItemDataNeedSave = false;
    public static Map<String, DeviceItem> items = new HashMap();
    public static Map<String, List<MsgItem>> deviceMac2Msgs = new HashMap();

    public static synchronized String GetAllLocalDVRFromDB(String sUID) {
        String sOKUID;
        synchronized (DataCenter.class) {
            sOKUID = null;
            if (dvrDBAdapter == null) {
                dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
            }
            dvrDBAdapter.open();
            Cursor c = dvrDBAdapter.getAll();
            int iRobotCount = c.getCount();
            Log.e("dvrDBAdapter.getAll()", "iRobotCount:" + iRobotCount);
            localdvritems.clear();
            if (c.moveToFirst()) {
                do {
                    localDvrItem item = new localDvrItem();
                    item.dvr_id = c.getString(1);
                    Log.e("DB", "ID:" + item.dvr_id);
                    if (sUID == null || sUID.equals(BuildConfig.FLAVOR)) {
                        if (sOKUID == null) {
                            item.last_activetime = 1;
                            sOKUID = item.dvr_id;
                        }
                    } else if (item.dvr_id.equals(sUID)) {
                        item.last_activetime = 1;
                        sOKUID = sUID;
                    }
                    item.dvr_name = c.getString(2);
                    item.dvr_mac = c.getString(3);
                    item.dvr_username = c.getString(4);
                    item.dvr_pwd = c.getString(5);
                    item.device_type = c.getInt(6);
                    item.status = 7;
                    item.always_veritypwd = c.getInt(9);
                    if (item.always_veritypwd == 0) {
                        item.dvr_pwd = BuildConfig.FLAVOR;
                    }
                    adddvrItem2List(item);
                } while (c.moveToNext());
                dvrDBAdapter.close();
                if (sOKUID == null) {
                }
                SetDefaultUID(sOKUID);
            } else {
                dvrDBAdapter.close();
                if (sOKUID == null) {
                }
                SetDefaultUID(sOKUID);
            }
        }
        return sOKUID;
    }

    public static void SetDefaultUID(String UID) {
        SharedPreferences sPreferences = MainHelper.context.getApplicationContext().getSharedPreferences(WelcomeActivity.DEFAULT_UID, 0);
        sPreferences.edit().putString(WelcomeActivity.DEFAULT_UID_STR, UID).commit();
    }

    public static void adddvrItem2List(localDvrItem i) {
        String mac = i.dvr_id;
        if (mac != null) {
            if (localdvritems.containsKey(mac)) {
                localdvritems.get(mac);
                return;
            }
            new localDvrItem();
            localdvritems.put(mac, i);
        }
    }

    public static synchronized void removeDvrItmes(String mac) {
        synchronized (DataCenter.class) {
            if (localdvritems.containsKey(mac)) {
                localdvritems.remove(mac);
            }
        }
    }

    @SuppressLint({"NewApi"})
    public static synchronized long adddvrItem2DB(localDvrItem i) {
        long result = 0;
        synchronized (DataCenter.class) {
            if (i.dvr_id != null && !i.dvr_id.isEmpty()) {
                if (dvrDBAdapter == null) {
                    dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
                }
                dvrDBAdapter.open();
                Cursor crCursor = dvrDBAdapter.getDeviceByUID(i.dvr_id);
                result = -1;
                Log.e("query", "count():" + crCursor.getCount());
                if (crCursor.getCount() == 0) {
                    result = dvrDBAdapter.insert(i);
                } else if (crCursor.getCount() == 1) {
                    result = 0;
                }
                dvrDBAdapter.close();
            }
        }
        return result;
    }

    public static synchronized Cursor QueryUIDFromDB(String UID) {
        Cursor deviceByUID;
        synchronized (DataCenter.class) {
            if (UID == null) {
                deviceByUID = null;
            } else {
                if (dvrDBAdapter == null) {
                    dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
                }
                dvrDBAdapter.open();
                deviceByUID = dvrDBAdapter.getDeviceByUID(UID);
                dvrDBAdapter.close();
            }
        }
        return deviceByUID;
    }

    public static synchronized int GetMaxNoFromDB() {
        int result;
        synchronized (DataCenter.class) {
            if (dvrDBAdapter == null) {
                dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
            }
            dvrDBAdapter.open();
            result = dvrDBAdapter.getMaxID();
            dvrDBAdapter.close();
        }
        return result;
    }

    public static synchronized boolean DelUIDFromDB(String UID) {
        boolean delete;
        synchronized (DataCenter.class) {
            if (UID == null) {
                delete = false;
            } else {
                if (dvrDBAdapter == null) {
                    dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
                }
                dvrDBAdapter.open();
                delete = dvrDBAdapter.delete(UID);
                dvrDBAdapter.close();
            }
        }
        return delete;
    }

    public static synchronized boolean UpdatelocalDvrFromDB(localDvrItem item, String UID) {
        boolean update;
        synchronized (DataCenter.class) {
            if (item.dvr_id == null) {
                update = false;
            } else {
                if (dvrDBAdapter == null) {
                    dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
                }
                dvrDBAdapter.open();
                update = dvrDBAdapter.update(item, UID);
                dvrDBAdapter.close();
            }
        }
        return update;
    }

    public static synchronized boolean UpdatelocalDvrFromDB(String Item, String itemvalue, String UID) {
        boolean update;
        synchronized (DataCenter.class) {
            if (UID == null) {
                update = false;
            } else {
                if (dvrDBAdapter == null) {
                    dvrDBAdapter = new LocalDvrDBAdapter(MainHelper.context);
                }
                dvrDBAdapter.open();
                update = dvrDBAdapter.update(Item, itemvalue, UID);
                dvrDBAdapter.close();
            }
        }
        return update;
    }

    public static List<localDvrItem> getLocalDvrIpcList() {
        List<localDvrItem> l = new ArrayList<>();
        for (Map.Entry<String, localDvrItem> entry : localdvritems.entrySet()) {
            localDvrItem val = entry.getValue();
            l.add(val);
        }
        return l;
    }

    @SuppressLint({"NewApi"})
    public static String getHostIp() {
        if (hostIp.isEmpty() && MainHelper.context != null) {
            SharedPreferences cfg = MainHelper.context.getSharedPreferences("igroupclient", 0);
            hostIp = cfg.getString("hostip", BuildConfig.FLAVOR);
        }
        return hostIp;
    }

    @SuppressLint({"NewApi"})
    public static String getHostPort() {
        if (hostPort.isEmpty() && MainHelper.context != null) {
            SharedPreferences cfg = MainHelper.context.getSharedPreferences("igroupclient", 0);
            hostPort = cfg.getString("hostport", "12903");
        }
        return hostPort;
    }

    @SuppressLint({"NewApi"})
    public static String getHostMac() {
        if (hostMac.isEmpty() && MainHelper.context != null) {
            SharedPreferences cfg = MainHelper.context.getSharedPreferences("igroupclient", 0);
            hostMac = cfg.getString("hostmac", BuildConfig.FLAVOR);
        }
        return hostMac;
    }

    public static void saveHostConfig(String ip, String port, String mac) {
        hostMac = mac;
        hostIp = ip;
        hostPort = port;
        if (MainHelper.context != null) {
            SharedPreferences cfg = MainHelper.context.getSharedPreferences("igroupclient", 0);
            cfg.edit().putString("hostip", ip).commit();
            cfg.edit().putString("hostport", port).commit();
            cfg.edit().putString("hostmac", mac).commit();
        }
    }

    public static List<DeviceItem> getDeviceList() {
        return new ArrayList(items.values());
    }

    public static DeviceItem getDevice(String mac) {
        if (items.size() == 0) {
            getDeviceList();
        }
        if (items.containsKey(mac)) {
            return items.get(mac);
        }
        return null;
    }

    public static List<DeviceItem> getPhoneList() {
        List<DeviceItem> l = new ArrayList<>();
        for (Map.Entry<String, DeviceItem> entry : items.entrySet()) {
            entry.getKey();
            DeviceItem val = entry.getValue();
            if (!val.mac.equals(MainHelper.getLocalMac()) && (val.device_type == Integer.valueOf(CmdParam.deviceType_iphone).intValue() || val.device_type == Integer.valueOf(CmdParam.deviceType_android).intValue() || val.device_type == -1)) {
                l.add(val);
            }
        }
        if (l.size() == 0) {
            DeviceItem item2 = new DeviceItem();
            item2.device_id = 99;
            item2.device_type = 99;
            item2.name = "点击加入部落";
            item2.mac = "FE:FE:FE:FE:FE:FE";
            item2.phone_number = "13845678999";
            item2.status = 1;
            l.add(item2);
        }
        return l;
    }

    public static List<DeviceItem> getDvrIpcList() {
        List<DeviceItem> l = new ArrayList<>();
        for (Map.Entry<String, DeviceItem> entry : items.entrySet()) {
            entry.getKey();
            DeviceItem val = entry.getValue();
            if (val.device_type == Integer.valueOf(CmdParam.deviceType_dvr).intValue() || val.device_type == Integer.valueOf(CmdParam.deviceType_ipc).intValue()) {
                l.add(val);
            }
        }
        return l;
    }

    public static synchronized void addDevice(DeviceItem d) {
        synchronized (DataCenter.class) {
            if (items.containsKey(d.mac)) {
                items.remove(d.mac);
            }
            items.put(d.mac, d);
        }
    }

    public static synchronized void removeDevice(String mac) {
        synchronized (DataCenter.class) {
            if (items.containsKey(mac)) {
                items.remove(mac);
            }
        }
    }

    public static synchronized void removeAll() {
        synchronized (DataCenter.class) {
            items.clear();
        }
    }

    public static synchronized void modifyDevice(DeviceItem d) {
        synchronized (DataCenter.class) {
            addDevice(d);
        }
    }

    public static synchronized void saveDeviceListToDB() {
        synchronized (DataCenter.class) {
            if (items != null) {
                DeviceDBAdapter dbAdapter = new DeviceDBAdapter(MainHelper.context);
                dbAdapter.open();
                dbAdapter.deleteAll();
                for (Map.Entry<String, DeviceItem> entry : items.entrySet()) {
                    entry.getKey();
                    DeviceItem val = entry.getValue();
                    dbAdapter.insert(val);
                }
                dbAdapter.close();
            }
        }
    }

    public static synchronized void initDeviceListFromDB() {
        synchronized (DataCenter.class) {
            if (items != null) {
                items.clear();
            }
            DeviceDBAdapter dbAdapter = new DeviceDBAdapter(MainHelper.context);
            dbAdapter.open();
            Cursor c = dbAdapter.getAll();
            if (c.moveToFirst()) {
                do {
                    DeviceItem item = new DeviceItem();
                    item.device_id = c.getInt(c.getColumnIndex(DeviceDBAdapter.DEVICE_ID));
                    item.device_type = c.getInt(c.getColumnIndex("device_type"));
                    item.name = c.getString(c.getColumnIndex(DeviceDBAdapter.NAME));
                    item.mac = c.getString(c.getColumnIndex("mac"));
                    item.status = c.getInt(c.getColumnIndex("status"));
                    items.put(item.mac, item);
                } while (c.moveToNext());
                dbAdapter.close();
            } else {
                dbAdapter.close();
            }
        }
    }

    public static void modifyDeviceInDB(DeviceItem d) {
    }

    public static void removeDeviceInDB(String mac) {
    }

    public static void addMsgItem(MsgItem i) {
        List<MsgItem> msgItems;
        String mac = i.deviceMac;
        if (deviceMac2Msgs.containsKey(mac)) {
            msgItems = deviceMac2Msgs.get(mac);
        } else {
            msgItems = new ArrayList<>();
            deviceMac2Msgs.put(mac, msgItems);
        }
        if (msgItems != null) {
            msgItems.add(i);
            saveMsgListFromDB();
        }
    }

    public static void modifyMsgItem(MsgItem i) {
        MsgDBAdapter dbAdapter = new MsgDBAdapter(MainHelper.context);
        dbAdapter.open();
        dbAdapter.update(i);
        dbAdapter.close();
    }

    public static List<MsgItem> getMsgOfDevice(String mac) {
        if (deviceMac2Msgs.containsKey(mac)) {
            return deviceMac2Msgs.get(mac);
        }
        return null;
    }

    public static MsgItem getLastMsgOfDeivce(String mac) {
        if (deviceMac2Msgs.containsKey(mac)) {
            List<MsgItem> msgs = deviceMac2Msgs.get(mac);
            if (msgs.size() > 0) {
                return msgs.get(0);
            }
        }
        return null;
    }

    public static List<DeviceItem> getDeviceHasMsg() {
        List<DeviceItem> items2 = new ArrayList<>();
        List<String> k = new ArrayList<>(deviceMac2Msgs.keySet());
        for (int i = 0; i < k.size(); i++) {
            String mac = k.get(i);
            DeviceItem d = getDevice(mac);
            if (d != null) {
                items2.add(d);
            }
        }
        return items2;
    }

    public static synchronized void initMsgListFromDB() {
        synchronized (DataCenter.class) {
            MsgDBAdapter dbAdapter = new MsgDBAdapter(MainHelper.context);
            dbAdapter.open();
            Cursor c = dbAdapter.getAll();
            if (c.moveToFirst()) {
                do {
                    MsgItem item = new MsgItem();
                    item.msg_id = c.getInt(c.getColumnIndex(MsgDBAdapter.MSG_ID));
                    item.deviceMac = c.getString(c.getColumnIndex(MsgDBAdapter.DEVICE_MAC));
                    item.status = c.getInt(c.getColumnIndex("status"));
                    item.content = c.getString(c.getColumnIndex("content"));
                    item.time = c.getString(c.getColumnIndex("time"));
                    item.flag = c.getInt(c.getColumnIndex(MsgDBAdapter.FLAG));
                    addMsgItem(item);
                } while (c.moveToNext());
                dbAdapter.close();
            } else {
                dbAdapter.close();
            }
        }
    }

    public static synchronized void saveMsgListFromDB() {
        synchronized (DataCenter.class) {
            MsgDBAdapter dbAdapter = new MsgDBAdapter(MainHelper.context);
            dbAdapter.open();
            dbAdapter.deleteAll();
            for (Map.Entry<String, List<MsgItem>> entry : deviceMac2Msgs.entrySet()) {
                entry.getKey();
                List<MsgItem> val = entry.getValue();
                for (int i = 0; i < val.size(); i++) {
                    MsgItem m = val.get(i);
                    dbAdapter.insert(m);
                }
            }
            dbAdapter.close();
        }
    }
}
