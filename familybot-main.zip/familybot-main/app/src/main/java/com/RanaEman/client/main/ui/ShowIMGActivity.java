package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListAdapter;
import com.Robot.client.main.R;
import com.example.stickyheadergridview.GridItem;
import com.example.stickyheadergridview.ImageScanner;
import com.example.stickyheadergridview.StickyGridAdapter;
import com.example.stickyheadergridview.YMComparator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.TimeZone;

/* loaded from: classes.dex */
public class ShowIMGActivity extends Activity {
    private static int section = 1;
    Button btnBack;
    private GridView mGridView;
    private ProgressDialog mProgressDialog;
    private ImageScanner mScanner;
    private List<GridItem> mGirdList = new ArrayList();
    private Map<String, Integer> sectionMap = new HashMap();

    static /* synthetic */ int access$308() {
        int i = section;
        section = i + 1;
        return i;
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_img);
        this.mGridView = (GridView) findViewById(R.id.asset_grid);
        this.mScanner = new ImageScanner(this);
        this.btnBack = (Button) findViewById(R.id.btncancel);
        this.btnBack.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.ShowIMGActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                ShowIMGActivity.this.finish();
                ShowIMGActivity.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
        this.mScanner.scanImages(new ImageScanner.ScanCompleteCallBack() { // from class: com.RanaEman.client.main.ui.ShowIMGActivity.2
            {
                //ShowIMGActivity.this = this;
                ShowIMGActivity.this.mProgressDialog = ProgressDialog.show(ShowIMGActivity.this, null, ShowIMGActivity.this.getResources().getString(R.string.loading));
            }

            @Override // com.example.stickyheadergridview.ImageScanner.ScanCompleteCallBack
            public void scanComplete(Cursor cursor2, Cursor cursor) {
                ShowIMGActivity.this.mProgressDialog.dismiss();
                while (cursor.moveToNext()) {
                    String path = cursor.getString(cursor.getColumnIndex("_data"));
                    if (path.contains("eMan/Shot/")) {
                        long times = cursor.getLong(cursor.getColumnIndex("date_modified"));
                        ShowIMGActivity.this.mGirdList.add(new GridItem(path, ShowIMGActivity.paserTimeToYM(times), 0));
                    }
                }
                cursor.close();
                while (cursor2.moveToNext()) {
                    String path2 = cursor2.getString(cursor2.getColumnIndex("_data"));
                    if (path2.contains("eMan/Shot/")) {
                        long times2 = cursor2.getLong(cursor2.getColumnIndex("date_modified"));
                        GridItem mGridItem = new GridItem(path2, ShowIMGActivity.paserTimeToYM(times2), 1);
                        mGridItem.setMidia_ID(cursor2.getInt(cursor2.getColumnIndex("_id")));
                        ShowIMGActivity.this.mGirdList.add(mGridItem);
                    }
                }
                cursor2.close();
                Collections.sort(ShowIMGActivity.this.mGirdList, new YMComparator());
                ListIterator<GridItem> it = ShowIMGActivity.this.mGirdList.listIterator();
                while (it.hasNext()) {
                    GridItem mGridItem2 = it.next();
                    String ym = mGridItem2.getTime();
                    if (!ShowIMGActivity.this.sectionMap.containsKey(ym)) {
                        mGridItem2.setSection(ShowIMGActivity.section);
                        ShowIMGActivity.this.sectionMap.put(ym, Integer.valueOf(ShowIMGActivity.section));
                        ShowIMGActivity.access$308();
                    } else {
                        mGridItem2.setSection(((Integer) ShowIMGActivity.this.sectionMap.get(ym)).intValue());
                    }
                }
                ShowIMGActivity.this.mGridView.setAdapter((ListAdapter) new StickyGridAdapter(ShowIMGActivity.this, ShowIMGActivity.this.mGirdList, ShowIMGActivity.this.mGridView));
                Log.e("mGridView.setAdapter", "mGridView.setAdapter!!");
            }
        });
    }

    public static String paserTimeToYM(long time) {
        System.setProperty("user.timezone", "Asia/Shanghai");
        TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(tz);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(new Date(1000 * time));
    }
}
