package com.RanaEman.client.main.data;

/* loaded from: classes.dex */
public class ExprissionItem {
    public boolean IsDefault;
    public boolean IsDownMore;
    public boolean IsNeedDwon;
    public boolean IsShow;
    public String sExpCHName;
    public String sExpLocalName;
    public String sExpName;

    public String toString() {
        return this.sExpName;
    }
}
