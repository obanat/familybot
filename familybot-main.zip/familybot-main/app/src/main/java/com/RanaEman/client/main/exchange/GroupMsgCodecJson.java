package com.RanaEman.client.main.exchange;

import android.util.Log;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class GroupMsgCodecJson {
    public static Boolean baseDecode(byte[] inData, Map<String, Object> outData) {
        String rowMessage = String.valueOf(inData);
        return baseDecode(rowMessage, outData);
    }

    public static Boolean baseDecode(String rowMessage, Map<String, Object> outData) {
        boolean z = false;
        Log.v("GroupMsgCodecJson|baseDecode", "收到命令，原始命令为：" + rowMessage);
        outData.put(CmdParam.cmdFormat, CmdParam.FormatJson);
        try {
            JSONObject jsonObj = new JSONObject(rowMessage);
            if (parseKeyParams(jsonObj, outData).booleanValue()) {
                String cmd = (String) outData.get(CmdParam.cmd);
                String isResp = (String) outData.get(CmdParam.isResp);
                if (isResp.equalsIgnoreCase(CmdParam.deviceType_ipc)) {
                    if (cmd.equalsIgnoreCase(CmdDef.LI) || cmd.equalsIgnoreCase(CmdDef.REGACCEPT)) {
                        z = true;
                    } else if (cmd.equalsIgnoreCase(CmdDef.REG)) {
                        z = parseCmdReqReg(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.CALLINVITE)) {
                        z = parseCmdReqCallInvite(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.CALLTAKE)) {
                        z = parseCmdReqCallTake(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.CALLCLOSE)) {
                        z = parseCmdReqCallClose(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.DEVICELISTUPDATE)) {
                        z = parseCmdReqDeviceListUpdate(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.MSG)) {
                        z = parseCmdReqMsg(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.CBEAT)) {
                        z = parseCmdHeartBeat(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.DOORBELLTRANS)) {
                        z = parseCmdDoorbell(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.DOORBELLSTOP)) {
                        z = true;
                    } else {
                        Log.e("GroupMsgCodecJson", "收到请求包，命令没有对应的处理函数:" + cmd);
                        z = false;
                    }
                } else {
                    Log.v("GroupMsgCodecJson", "收到命令的应答包：" + cmd);
                    if (cmd.equalsIgnoreCase(CmdDef.LI) || cmd.equalsIgnoreCase(CmdDef.REG) || cmd.equalsIgnoreCase(CmdDef.CALLINVITE) || cmd.equalsIgnoreCase(CmdDef.CALLTAKE) || cmd.equalsIgnoreCase(CmdDef.CALLCLOSE) || cmd.equalsIgnoreCase(CmdDef.MSG) || cmd.equalsIgnoreCase(CmdDef.CBEAT)) {
                        if (!jsonObj.has(CmdParam.resultCode)) {
                            Log.e("GroupMsgCodecJson", "缺少字段 resultCode");
                            z = false;
                        } else {
                            String resultCode = jsonObj.getString(CmdParam.resultCode);
                            outData.put(CmdParam.resultCode, resultCode);
                            z = true;
                        }
                    } else if (cmd.equalsIgnoreCase(CmdDef.FINDHOST)) {
                        z = parseCmdRespFindHost(jsonObj, outData);
                    } else if (cmd.equalsIgnoreCase(CmdDef.GETDEVICELIST)) {
                        z = parseCmdRespGetDeviceList(jsonObj, outData);
                    }
                }
                return z;
            }
            z = false;
            return z;
        } catch (JSONException e) {
            Log.e("GroupMsgCodecJson", "收到的数据不是正确的Json格式，解包失败");
            return false;
        }
    }

    public static String baseEncode(Map<String, Object> sendData) {
        if (!sendData.containsKey(CmdParam.cmd)) {
            Log.v("GroupMsgCodecJson|baseEncode", "缺少参数 cmd");
            return BuildConfig.FLAVOR;
        } else if (!sendData.containsKey(CmdParam.taskId)) {
            Log.v("GroupMsgCodecJson|baseEncode", "缺少参数 taskId");
            return BuildConfig.FLAVOR;
        } else if (!sendData.containsKey(CmdParam.isResp)) {
            Log.v("GroupMsgCodecJson|baseEncode", "缺少参数 taskId");
            return BuildConfig.FLAVOR;
        } else if (!sendData.containsKey("mac")) {
            Log.v("GroupMsgCodecJson|baseEncode", "缺少参数 mac");
            return BuildConfig.FLAVOR;
        } else {
            String cmd = (String) sendData.get(CmdParam.cmd);
            String str = (String) sendData.get(CmdParam.isResp);
            JSONObject jsonObj = new JSONObject();
            if (cmd.equalsIgnoreCase(CmdDef.LI) || cmd.equalsIgnoreCase(CmdDef.REG) || cmd.equalsIgnoreCase(CmdDef.CALLCLOSE) || cmd.equalsIgnoreCase(CmdDef.CALLINVITE) || cmd.equalsIgnoreCase(CmdDef.CALLTAKE) || cmd.equalsIgnoreCase(CmdDef.FINDHOST) || cmd.equalsIgnoreCase(CmdDef.GETDEVICELIST) || cmd.equalsIgnoreCase(CmdDef.MSG) || cmd.equalsIgnoreCase(CmdDef.CBEAT) || cmd.equalsIgnoreCase(CmdDef.OPENDOOR) || cmd.equalsIgnoreCase(CmdDef.RFSOPENDOOR) || cmd.equalsIgnoreCase(CmdDef.DOORBELLSTOP)) {
                if (!encodeBaisc(jsonObj, sendData).booleanValue()) {
                    Log.e("GroupMsgCodecJson|baseEncode", "encodeBaisc failed, cmd is:" + cmd);
                    return BuildConfig.FLAVOR;
                }
                return jsonObj.toString();
            }
            Log.e("GroupMsgCodecJson|baseEncode", "没有找到encode, cmd is:" + cmd);
            return BuildConfig.FLAVOR;
        }
    }

    public static Boolean parseKeyParams(JSONObject jsonObj, Map<String, Object> outData) {
        boolean z;
        if (!jsonObj.has(CmdParam.cmd)) {
            Log.e("GroupMsgCodecJson|parseKeyParams", "缺少字段 cmd");
            return false;
        } else if (!jsonObj.has(CmdParam.taskId)) {
            Log.e("GroupMsgCodecJson|parseKeyParams", "缺少字段 taskId");
            return false;
        } else if (!jsonObj.has("mac")) {
            Log.e("GroupMsgCodecJson|parseKeyParams", "缺少字段 mac");
            return false;
        } else if (!jsonObj.has(CmdParam.isResp)) {
            Log.e("GroupMsgCodecJson|parseKeyParams", "缺少字段 isResp");
            return false;
        } else {
            try {
                String cmd = jsonObj.getString(CmdParam.cmd);
                String taskId = jsonObj.getString(CmdParam.taskId);
                String mac = jsonObj.getString("mac");
                String isResp = jsonObj.getString(CmdParam.isResp);
                if (cmd == null || cmd.length() == 0 || taskId == null || taskId.length() == 0 || mac == null || mac.length() == 0 || isResp == null || isResp.length() == 0) {
                    Log.e("GroupMsgCodecJson|parseKeyParams", "有关键参数的内容为空");
                    z = false;
                } else {
                    outData.put(CmdParam.cmd, cmd);
                    outData.put(CmdParam.taskId, taskId);
                    outData.put("mac", mac);
                    outData.put(CmdParam.isResp, isResp);
                    z = true;
                }
                return z;
            } catch (JSONException e) {
                Log.e("GroupMsgCodecJson|parseKeyParams", "JSONException");
                return false;
            }
        }
    }

    public static Boolean parseCmdReqLi(JSONObject jsonObj, Map<String, Object> outData) {
        String isResp = (String) outData.get(CmdParam.isResp);
        if (isResp.equalsIgnoreCase(CmdParam.deviceType_ipc)) {
        }
        return true;
    }

    public static Boolean parseCmdReqReg(JSONObject jsonObj, Map<String, Object> outData) {
        boolean z;
        if (!jsonObj.has(CmdParam.deviceName)) {
            Log.e("GroupMsgCodecJson|parseCmdReg", "缺少参数 deviceName");
            return false;
        } else if (!jsonObj.has(CmdParam.deviceType)) {
            Log.e("GroupMsgCodecJson|parseCmdReg", "缺少参数 deviceType");
            return false;
        } else {
            try {
                String deviceName = jsonObj.getString(CmdParam.deviceName);
                String deviceType = jsonObj.getString(CmdParam.deviceType);
                if (deviceName == null || deviceName.length() == 0 || deviceType == null || deviceType.length() == 0) {
                    Log.e("GroupMsgCodecJson|parseCmdReg", "有关键参数的内容为空");
                    z = false;
                } else {
                    outData.put(CmdParam.deviceName, deviceName);
                    outData.put(CmdParam.deviceType, deviceType);
                    z = true;
                }
                return z;
            } catch (JSONException e) {
                Log.e("GroupMsgCodecJson|parseCmdReg", "JSONException");
                return false;
            }
        }
    }

    public static Boolean parseCmdReqCallInvite(JSONObject jsonObj, Map<String, Object> outData) {
        return true;
    }

    public static Boolean parseCmdReqCallTake(JSONObject jsonObj, Map<String, Object> outData) {
        return true;
    }

    public static Boolean parseCmdReqCallClose(JSONObject jsonObj, Map<String, Object> outData) {
        boolean z;
        if (!jsonObj.has(CmdParam.reasonCode)) {
            Log.e("GroupMsgCodecJson|parseCmdCallClose", "缺少参数 reasonCode");
            return false;
        }
        try {
            String reasonCode = jsonObj.getString(CmdParam.reasonCode);
            if (reasonCode == null || reasonCode.length() == 0) {
                Log.e("GroupMsgCodecJson|parseCmdCallClose", "reasonCode内容为空");
                z = false;
            } else {
                outData.put(CmdParam.reasonCode, reasonCode);
                z = true;
            }
            return z;
        } catch (JSONException e) {
            Log.e("GroupMsgCodecJson|parseCmdCallClose", "JSONException");
            return false;
        }
    }

    public static Boolean parseCmdRespFindHost(JSONObject jsonObj, Map<String, Object> outData) {
        if (!jsonObj.has(CmdParam.resultCode)) {
            Log.e("GroupMsgCodecJson", "缺少字段 resultCode");
            return false;
        } else if (!jsonObj.has(CmdParam.tcpPort)) {
            Log.e("GroupMsgCodecJson", "缺少字段 tcpPort");
            return false;
        } else {
            try {
                String resultCode = jsonObj.getString(CmdParam.resultCode);
                String tcpPort = jsonObj.getString(CmdParam.tcpPort);
                outData.put(CmdParam.resultCode, resultCode);
                outData.put(CmdParam.tcpPort, tcpPort);
                return true;
            } catch (JSONException e) {
                return false;
            }
        }
    }

    public static Boolean parseCmdReqDeviceListUpdate(JSONObject jsonObj, Map<String, Object> outData) {
        List<Map<String, String>> deList = new ArrayList<>();
        try {
            JSONArray jsonList = jsonObj.getJSONArray(CmdParam.deviceList);
            for (int i = 0; i < jsonList.length(); i++) {
                JSONObject jsonItem = (JSONObject) jsonList.opt(i);
                String deviceName = jsonItem.getString(CmdParam.deviceName);
                String deviceType = jsonItem.getString(CmdParam.deviceType);
                String deviceMac = jsonItem.getString(CmdParam.deviceMac);
                String deviceIp = jsonItem.getString(CmdParam.deviceIp);
                Map<String, String> itemData = new HashMap<>();
                itemData.put(CmdParam.deviceName, deviceName);
                itemData.put(CmdParam.deviceType, deviceType);
                itemData.put(CmdParam.deviceMac, deviceMac);
                itemData.put(CmdParam.deviceIp, deviceIp);
                deList.add(itemData);
            }
            outData.put(CmdParam.deviceList, deList);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    public static Boolean parseCmdReqMsg(JSONObject jsonObj, Map<String, Object> outData) {
        if (!jsonObj.has("content")) {
            Log.e("parseCmdReqMsg", "缺少参数 content");
            return false;
        } else if (!jsonObj.has("time")) {
            Log.e("parseCmdReqMsg", "缺少参数 time");
            return false;
        } else {
            try {
                String content = jsonObj.getString("content");
                String time = jsonObj.getString("time");
                outData.put("content", content);
                outData.put("time", time);
                return true;
            } catch (JSONException e) {
                Log.e("parseCmdReqMsg", "JSONException");
                return false;
            }
        }
    }

    public static Boolean parseCmdDoorbell(JSONObject jsonObj, Map<String, Object> outData) {
        if (!jsonObj.has(CmdParam.ipcip)) {
            Log.e("parseCmdReqMsg", "缺少参数 IPCIP");
            return false;
        } else if (!jsonObj.has(CmdParam.ipcmac)) {
            Log.e("parseCmdReqMsg", "缺少参数 IPMAC");
            return false;
        } else {
            try {
                String ip = jsonObj.getString(CmdParam.ipcip);
                outData.put(CmdParam.ipcip, ip);
                String ip2 = jsonObj.getString(CmdParam.ipcmac);
                outData.put(CmdParam.ipcmac, ip2);
                return true;
            } catch (JSONException e) {
                Log.e("parseCmdDoorbell", "JSONException");
                return false;
            }
        }
    }

    public static Boolean parseCmdHeartBeat(JSONObject jsonObj, Map<String, Object> outData) {
        if (!jsonObj.has(CmdParam.workStatus)) {
            Log.e("parseCmdHeartBeat", "缺少参数 workStatus");
            return false;
        }
        try {
            String workStatus = jsonObj.getString(CmdParam.workStatus);
            outData.put(CmdParam.workStatus, workStatus);
            return true;
        } catch (JSONException e) {
            Log.e("parseCmdHeartBeat", "JSONException");
            return false;
        }
    }

    public static Boolean parseCmdRespGetDeviceList(JSONObject jsonObj, Map<String, Object> outData) {
        List<Map<String, String>> deList = new ArrayList<>();
        try {
            JSONArray jsonList = jsonObj.getJSONArray(CmdParam.deviceList);
            for (int i = 0; i < jsonList.length(); i++) {
                JSONObject jsonItem = (JSONObject) jsonList.opt(i);
                String deviceName = jsonItem.getString(CmdParam.deviceName);
                String deviceType = jsonItem.getString(CmdParam.deviceType);
                String deviceMac = jsonItem.getString(CmdParam.deviceMac);
                String deviceIp = jsonItem.getString(CmdParam.deviceIp);
                String devicePort = jsonItem.getString(CmdParam.devicePort);
                Map<String, String> itemData = new HashMap<>();
                itemData.put(CmdParam.deviceName, deviceName);
                itemData.put(CmdParam.deviceType, deviceType);
                itemData.put(CmdParam.deviceMac, deviceMac);
                itemData.put(CmdParam.deviceIp, deviceIp);
                itemData.put(CmdParam.devicePort, devicePort);
                deList.add(itemData);
            }
            outData.put(CmdParam.deviceList, deList);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    public static Boolean encodeBaisc(JSONObject jsonObj, Map<String, Object> sendData) {
        for (Map.Entry<String, Object> entry : sendData.entrySet()) {
            String key = entry.getKey();
            String val = String.valueOf(entry.getValue());
            if (!key.equalsIgnoreCase(CmdParam.ip) && !key.equalsIgnoreCase(CmdParam.port) && !key.equalsIgnoreCase(CmdParam.proto)) {
                try {
                    jsonObj.put(key, val);
                } catch (JSONException e) {
                    Log.v("GroupMsgCodecJson|baseEncode", "打包成Json数据时出错");
                    return false;
                }
            }
        }
        return true;
    }

    public static Boolean encodeRespFindHost(JSONObject jsonObj, Map<String, Object> sendData) {
        return true;
    }
}
