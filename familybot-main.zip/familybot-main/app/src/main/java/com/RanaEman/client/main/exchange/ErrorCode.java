package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class ErrorCode {
    public static int SUCCEED = 0;
    public static int ERR_PARAMS = 1001;
    public static int ERR_HOST = 1002;
    public static int ERR_REG_ALREADY_SUCCEED = 2001;
    public static int ERR_REG_ALREADY_WAIT_ALLOW = 2002;
    public static int ERR_REG_NAME_EXIST = 2003;
    public static int ERR_REG_RECV_WAIT_ALLOW = 2004;
    public static int ERR_LI_NOT_REG = 3001;
    public static int ERR_LI_REG_NOT_ALLOW = 3002;
    public static int ERR_CALL_BUSY = 4001;
    public static int ERR_CALL_USER_CLOSE = 4002;
}
