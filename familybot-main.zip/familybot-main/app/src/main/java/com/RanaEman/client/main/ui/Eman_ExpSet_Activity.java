package com.RanaEman.client.main.ui;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.RanaEman.client.main.SigCameraService;
import com.RanaEman.client.main.data.ExprissionItem;
import com.RanaEman.client.main.net.TcpServer;
import com.Robot.client.main.R;
import com.tutk.IOTC.AVAPIs;
import com.tutk.IOTC.Camera;
import com.tutk.IOTC.IRegisterIOTCListener;
import com.tutk.IOTC.MyCamera;
import com.tutk.IOTC.Packet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: classes.dex */
public class Eman_ExpSet_Activity extends Activity implements IRegisterIOTCListener, View.OnClickListener, AdapterView.OnItemSelectedListener {
    private static final int DOWN_ERR = 10;
    private static final int DOWN_OVER = 8;
    private static final int DOWN_UPDATE = 7;
    static final int RECV_EXPRESSIONFILE_RESULT = 4;
    static final int RECV_EXPRESSION_INFO = 1;
    static final int RECV_SETTIMEOUT = 3;
    static final int REFRESHLISTVIEW = 5;
    private static final int START_UPDATE = 6;
    private static final int USER_CANCEL = 9;
    private static String tag = "EMAIN_EXPRESSION_SET";
    private Button btnBack;
    private Button btnSure;
    private Thread downLoadThread;
    ExprissionListAdapter exprissionAdapter;
    int iExpIndex;
    int iExpIndex_inList;
    ListView lvExprission;
    TextView lvStaus;
    ProgressBar pbDown;
    ProgressBar pbmainBar;
    int progress;
    String sExpExist;
    String strShow;
    Timer timerSetTimeout;
    private String xmlUrl = "http://rana.cc/download/exprission/exprission.xml";
    public MyCamera cameraset = null;
    byte[] sExPressdata = new byte[104];
    Dialog m_mygprogressDialog = null;
    Boolean blnSetOutTime = false;
    List<ExprissionItem> datas = new ArrayList();
    Handler handler = new Handler() { // from class: com.RanaEman.client.main.ui.Eman_ExpSet_Activity.2
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    Eman_ExpSet_Activity.this.pbmainBar.setVisibility(4);
                    Eman_ExpSet_Activity.this.lvExprission.setVisibility(0);
                    if (Eman_ExpSet_Activity.this.sExpExist != null) {
                        boolean exFind = false;
                        int i = 0;
                        while (true) {
                            if (i < Eman_ExpSet_Activity.this.datas.size() - 1) {
                                if (!Eman_ExpSet_Activity.this.datas.get(i).sExpName.equals(Eman_ExpSet_Activity.this.sExpExist)) {
                                    i++;
                                } else {
                                    Eman_ExpSet_Activity.this.iExpIndex_inList = i;
                                    exFind = true;
                                    break;
                                }
                            }
                        }
                        if (!exFind) {
                            Eman_ExpSet_Activity.this.datas.remove(Eman_ExpSet_Activity.this.datas.size() - 1);
                            ExprissionItem defaultItem = new ExprissionItem();
                            defaultItem.sExpCHName = Eman_ExpSet_Activity.this.sExpExist;
                            defaultItem.sExpName = Eman_ExpSet_Activity.this.sExpExist;
                            Eman_ExpSet_Activity.this.datas.add(defaultItem);
                            Eman_ExpSet_Activity.this.iExpIndex_inList = Eman_ExpSet_Activity.this.datas.size() - 1;
                            ExprissionItem defaultItem2 = new ExprissionItem();
                            defaultItem2.sExpCHName = Eman_ExpSet_Activity.this.getString(R.string.txtMoreExp);
                            defaultItem2.IsDownMore = true;
                            Eman_ExpSet_Activity.this.datas.add(defaultItem2);
                        }
                        if (Eman_ExpSet_Activity.this.iExpIndex == 0) {
                            Eman_ExpSet_Activity.this.datas.get(0).IsDefault = true;
                        } else {
                            Eman_ExpSet_Activity.this.datas.get(Eman_ExpSet_Activity.this.iExpIndex_inList).IsDefault = true;
                        }
                    } else {
                        Eman_ExpSet_Activity.this.datas.get(0).IsDefault = true;
                    }
                    Eman_ExpSet_Activity.this.exprissionAdapter.notifyDataSetChanged();
                    return;
                case 2:
                case 9:
                case 10:
                default:
                    return;
                case 3:
                    Eman_ExpSet_Activity.this.showdialog(Eman_ExpSet_Activity.this.getString(R.string.txtsettingfailed), Eman_ExpSet_Activity.this.getString(R.string.txtsettingtimeout), false);
                    return;
                case 4:
                    Bundle bd = msg.getData();
                    int iKind = bd.getInt("iKind");
                    int iResult = bd.getInt("iResult");
                    if (iKind == 1) {
                        Eman_ExpSet_Activity.this.updatePregress(1, 0, iResult);
                        return;
                    } else if (iKind == 3) {
                        Eman_ExpSet_Activity.this.updatePregress(3, 0, 100);
                        return;
                    } else if (iKind == 2 && iResult > 0) {
                        Eman_ExpSet_Activity.this.updatePregress(2, 0, 100);
                        Eman_ExpSet_Activity.this.handler.postDelayed(new Runnable() { // from class: com.RanaEman.client.main.ui.Eman_ExpSet_Activity.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Eman_ExpSet_Activity.this.finish();
                            }
                        }, 1500L);
                        return;
                    } else {
                        return;
                    }
                case 5:
                    Eman_ExpSet_Activity.this.getExprssionListFromFile(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Exprission/Exprission.xml");
                    Eman_ExpSet_Activity.this.exprissionAdapter.notifyDataSetChanged();
                    return;
                case 6:
                    Eman_ExpSet_Activity.this.updatePregress(0, 0, 0);
                    return;
                case 7:
                    Eman_ExpSet_Activity.this.updatePregress(0, 0, Eman_ExpSet_Activity.this.progress);
                    return;
                case 8:
                    Eman_ExpSet_Activity.this.cameraset.startRDT_SendFile(0, 12, msg.getData().getString("FileName"));
                    Eman_ExpSet_Activity.this.updatePregress(1, 0, 0);
                    return;
            }
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eman_newexp);
        this.btnBack = (Button) findViewById(R.id.btncancel);
        this.btnBack.setOnClickListener(this);
        this.btnSure = (Button) findViewById(R.id.Button04);
        this.btnSure.setOnClickListener(this);
        getExprssionListFromFile(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Exprission/Exprission.xml");
        this.pbmainBar = (ProgressBar) findViewById(R.id.pBMain);
        this.exprissionAdapter = new ExprissionListAdapter(this, this.datas);
        this.lvExprission = (ListView) findViewById(R.id.listView1);
        this.lvExprission.setAdapter((ListAdapter) this.exprissionAdapter);
        this.lvExprission.setVisibility(4);
        this.lvExprission.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.RanaEman.client.main.ui.Eman_ExpSet_Activity.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                if (arg0.getAdapter() == Eman_ExpSet_Activity.this.exprissionAdapter) {
                    ExprissionItem Item = (ExprissionItem) Eman_ExpSet_Activity.this.exprissionAdapter.getItem(arg2);
                    Log.e(Eman_ExpSet_Activity.tag, "arg2:" + arg2);
                    Log.e(Eman_ExpSet_Activity.tag, Item.sExpCHName);
                    if (Item.IsDownMore) {
                        new Thread(new Runnable() { // from class: com.RanaEman.client.main.ui.Eman_ExpSet_Activity.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Eman_ExpSet_Activity.this.getExprssionListFromServer();
                            }
                        }).start();
                        return;
                    }
                    for (int i = 0; i < Eman_ExpSet_Activity.this.datas.size(); i++) {
                        Eman_ExpSet_Activity.this.datas.get(i).IsDefault = false;
                    }
                    Item.IsDefault = true;
                    Eman_ExpSet_Activity.this.exprissionAdapter.notifyDataSetChanged();
                }
            }
        });
        if (this.cameraset == null) {
            this.cameraset = SigCameraService.MainCamera;
            this.cameraset.registerIOTCListener(this);
            if (this.cameraset != null) {
                this.cameraset.sendIOCtrl(0, 12343, Packet.intToByteArray_Little(0));
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        if (arg0 == this.btnBack) {
            finish();
        } else if (arg0 == this.btnSure) {
            for (int i = 0; i < this.datas.size(); i++) {
                ExprissionItem item = this.datas.get(i);
                item.IsShow = false;
                if (item.IsDefault) {
                    if (i == 0 || i == this.iExpIndex_inList) {
                        if (i == 0) {
                            this.cameraset.sendIOCtrl(0, 12309, Packet.intToByteArray_Little(0));
                        } else {
                            this.cameraset.sendIOCtrl(0, 12309, Packet.intToByteArray_Little(1));
                        }
                        item.IsShow = true;
                    } else {
                        if (new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Exprission/" + item.sExpName + ".zip").exists()) {
                            item.IsNeedDwon = false;
                            this.cameraset.startRDT_SendFile(0, 12, Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Exprission/" + item.sExpName + ".zip");
                        } else {
                            item.IsNeedDwon = true;
                            downloadFile(item.sExpName + ".zip");
                        }
                        item.IsShow = true;
                    }
                }
            }
            this.exprissionAdapter.notifyDataSetChanged();
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public void getExprssionListFromFile(String sfilename) {
        ExprissionItem defaultItem;
        this.datas.clear();
        ExprissionItem defaultItem2 = new ExprissionItem();
        defaultItem2.sExpCHName = getResources().getString(R.string.txtDefaultExp);
        defaultItem2.sExpName = "default";
        this.datas.add(defaultItem2);
        File xmlfile = new File(sfilename);
        if (xmlfile.exists()) {
            try {
                InputStream is = new FileInputStream(xmlfile);
                XmlPullParser parser = Xml.newPullParser();
                parser.setInput(is, "utf-8");
                int type = parser.getEventType();
                ExprissionItem defaultItem3 = defaultItem2;
                while (type != 1) {
                    switch (type) {
                        case 2:
                            try {
                                if ("Exprission".equals(parser.getName())) {
                                    defaultItem = new ExprissionItem();
                                    break;
                                } else if ("Name".equals(parser.getName())) {
                                    defaultItem3.sExpName = parser.nextText();
                                    defaultItem = defaultItem3;
                                    break;
                                } else {
                                    if ("CHName".equals(parser.getName())) {
                                        defaultItem3.sExpCHName = parser.nextText();
                                        defaultItem = defaultItem3;
                                        break;
                                    }
                                    defaultItem = defaultItem3;
                                    break;
                                }
                            } catch (Exception e) {
                                e = e;
                                e.printStackTrace();
                                ExprissionItem defaultItem4 = new ExprissionItem();
                                defaultItem4.sExpCHName = getResources().getString(R.string.txtMoreExp);
                                defaultItem4.IsDownMore = true;
                                this.datas.add(defaultItem4);
                            }
                        case 3:
                            if ("Exprission".equals(parser.getName())) {
                                this.datas.add(defaultItem3);
                            }
                            defaultItem = defaultItem3;
                            break;
                        default:
                            defaultItem = defaultItem3;
                            break;
                    }
                    type = parser.next();
                    defaultItem3 = defaultItem;
                }
                is.close();
            } catch (Exception e2) {
                //e = e2;
            }
        }
        ExprissionItem defaultItem42 = new ExprissionItem();
        defaultItem42.sExpCHName = getResources().getString(R.string.txtMoreExp);
        defaultItem42.IsDownMore = true;
        this.datas.add(defaultItem42);
    }

    public void getExprssionListFromServer() {
        try {
            URL url = new URL(this.xmlUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(TcpServer.DEFAULT_SOCKET_TIMEOUT);
            conn.setConnectTimeout(TcpServer.DEFAULT_SOCKET_TIMEOUT);
            conn.connect();
            InputStream is = conn.getInputStream();
            File fxmlfileFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Exprission/Exprission.xml");
            if (fxmlfileFile.exists()) {
                fxmlfileFile.delete();
            }
            fxmlfileFile.createNewFile();
            OutputStream os = new FileOutputStream(fxmlfileFile);
            byte[] buffer = new byte[8192];
            while (true) {
                int bytesRead = is.read(buffer, 0, 8192);
                if (bytesRead == -1) {
                    break;
                }
                os.write(buffer, 0, bytesRead);
            }
            is.close();
            os.close();
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.handler.sendEmptyMessage(5);
    }

    void updatePregress(int iKind, int iadd, int iProgress) {
        if (this.pbDown == null) {
            this.pbDown = this.exprissionAdapter.getCurPB();
            this.lvStaus = this.exprissionAdapter.getCurTV();
        }
        if (iKind == 0) {
            if (this.lvStaus != null) {
                this.lvStaus.setText(getResources().getString(R.string.txtDownExp) + this.strShow);
            }
        } else if (iKind == 1) {
            if (this.lvStaus != null) {
                this.lvStaus.setText(getResources().getString(R.string.txtDown2Device) + "(" + iProgress + "%)");
            }
        } else if (iKind == 2) {
            if (this.lvStaus != null) {
                this.lvStaus.setText(getResources().getString(R.string.txtsettingsucess));
            }
        } else if (iKind == 3 && this.lvStaus != null) {
            this.lvStaus.setText(getResources().getString(R.string.connstus_connection_failed));
            this.lvStaus.setTextColor(Color.parseColor("#FF4500"));
        }
        if (this.pbDown != null) {
            this.pbDown.setProgress(iProgress);
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveChannelInfo(Camera paramCamera, int paramInt1, int paramInt2) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveFrameInfo(Camera paramCamera, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveIOCtrlData(Camera paramCamera, int paramInt1, int paramInt2, byte[] paramArrayOfByte) {
        Log.e(tag + "receiveIOCtrlData_dvrset", "paramInt1:" + paramInt1);
        Log.e(tag + "receiveIOCtrlData_dvrset", "paramInt2:" + paramInt2);
        if (paramInt2 == 12344) {
            this.iExpIndex = Packet.byteArrayToInt_Little(paramArrayOfByte, 100);
            if (paramArrayOfByte[50] == 0) {
                this.sExpExist = null;
            } else {
                byte[] ex = new byte[50];
                System.arraycopy(paramArrayOfByte, 50, ex, 0, 50);
                this.sExpExist = new String(ex).trim();
            }
            this.handler.sendEmptyMessage(1);
        } else if (paramInt2 == 12310) {
            Message msgMessage = this.handler.obtainMessage();
            msgMessage.what = 4;
            Bundle bundledata = new Bundle();
            bundledata.putInt("iResult", Packet.byteArrayToInt_Little(paramArrayOfByte, 0));
            bundledata.putInt("iKind", 2);
            msgMessage.setData(bundledata);
            this.handler.sendMessage(msgMessage);
        }
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveSessionInfo(Camera paramCamera, int paramInt) {
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.timerSetTimeout != null) {
            this.timerSetTimeout.cancel();
        }
        if (this.cameraset != null) {
            this.cameraset.unregisterIOTCListener(this);
        }
        super.onDestroy();
    }

    public void showdialog(String stitle, String msg, boolean closeactivity) {
        if (this.m_mygprogressDialog != null) {
            this.m_mygprogressDialog.dismiss();
            this.m_mygprogressDialog = null;
        }
        this.m_mygprogressDialog = new Dialog(this, R.style.Tips);
        this.m_mygprogressDialog.setContentView(R.layout.myprogress_dialog);
        TextView txtTitleTextView = (TextView) this.m_mygprogressDialog.findViewById(R.id.txtDialogTitle);
        txtTitleTextView.setText(stitle);
        TextView txtMyProgerssMsg = (TextView) this.m_mygprogressDialog.findViewById(R.id.txtMessage);
        txtMyProgerssMsg.setText(msg);
        RelativeLayout pbdialogBar = (RelativeLayout) this.m_mygprogressDialog.findViewById(R.id.rlDialogPb);
        pbdialogBar.setVisibility(8);
        Button btnokk = (Button) this.m_mygprogressDialog.findViewById(R.id.btnSure);
        btnokk.setOnClickListener(new View.OnClickListener() { // from class: com.RanaEman.client.main.ui.Eman_ExpSet_Activity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Eman_ExpSet_Activity.this.m_mygprogressDialog.dismiss();
            }
        });
        this.m_mygprogressDialog.setCancelable(true);
        this.m_mygprogressDialog.show();
    }

    /* loaded from: classes.dex */
    public class downApkRunnable implements Runnable {
        String fileame = null;
        String apkUrl = null;
        String savePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/eMan/Exprission/";
        Boolean isRunning = true;

        public downApkRunnable() {
            //Eman_ExpSet_Activity.this = this$0;
        }

        public void SetDownFile(String sfileame) {
            this.fileame = sfileame;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.apkUrl = "http://rana.cc/download/exprission/" + this.fileame;
            try {
                URL url = new URL(this.apkUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(Camera.RDT_WAIT_TIMEMS);
                conn.connect();
                int length = conn.getContentLength();
                InputStream is = conn.getInputStream();
                File file = new File(this.savePath);
                if (!file.exists()) {
                    file.mkdir();
                }
                File ApkFile = new File(this.savePath + this.fileame);
                FileOutputStream fos = new FileOutputStream(ApkFile);
                int count = 0;
                byte[] buf = new byte[1024];
                do {
                    int numread = is.read(buf);
                    count += numread;
                    Eman_ExpSet_Activity.this.progress = (int) ((count / length) * 100.0f);
                    Eman_ExpSet_Activity.this.strShow = Eman_ExpSet_Activity.this.progress + "%(" + (count / AVAPIs.TIME_SPAN_LOSED) + "KB/" + (length / AVAPIs.TIME_SPAN_LOSED) + "KB)";
                    Eman_ExpSet_Activity.this.handler.sendEmptyMessage(7);
                    if (numread <= 0) {
                        break;
                    }
                    fos.write(buf, 0, numread);
                } while (this.isRunning.booleanValue());
                if (!this.isRunning.booleanValue()) {
                    Eman_ExpSet_Activity.this.handler.sendEmptyMessage(9);
                }
                fos.close();
                is.close();
                conn.disconnect();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                Log.e(Eman_ExpSet_Activity.tag, "err:" + e.getMessage().toString());
                Eman_ExpSet_Activity.this.handler.sendEmptyMessage(10);
            } catch (IOException e2) {
                e2.printStackTrace();
                Log.e(Eman_ExpSet_Activity.tag, "err:" + e2.getMessage().toString());
                Eman_ExpSet_Activity.this.handler.sendEmptyMessage(10);
            }
            Message msgMessage = Eman_ExpSet_Activity.this.handler.obtainMessage();
            msgMessage.what = 8;
            Bundle bd = new Bundle();
            bd.putString("FileName", this.savePath + this.fileame);
            msgMessage.setData(bd);
            Eman_ExpSet_Activity.this.handler.sendMessage(msgMessage);
        }
    }

    private void downloadFile(String sFileName) {
        downApkRunnable downFile = new downApkRunnable();
        downFile.SetDownFile(sFileName);
        this.downLoadThread = new Thread(downFile);
        this.downLoadThread.start();
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> arg0) {
    }

    @Override // com.tutk.IOTC.IRegisterIOTCListener
    public void receiveRDTSendFileResult(Camera paramCamera, int iFileKind, int Result, String s, int ikind) {
        if (ikind == 12) {
            Message msgMessage = this.handler.obtainMessage();
            msgMessage.what = 4;
            Bundle bundledata = new Bundle();
            bundledata.putInt("iResult", Result);
            bundledata.putInt("iKind", ikind);
            msgMessage.setData(bundledata);
            this.handler.sendMessage(msgMessage);
        }
    }
}
