package com.RanaEman.client.main.ui;

import android.app.KeyguardManager;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.PowerManager;
import com.RanaEman.client.main.MainHelper;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class CallDialogHelper {
    private Context mContext;
    MediaPlayer mMediaPlayer;
    private PowerManager pm;
    ToneGenerator ringbackPlayer;
    private PowerManager.WakeLock wakeLock;
    KeyguardManager mKeyguardManager = null;
    private KeyguardManager.KeyguardLock mKeyguardLock = null;

    public CallDialogHelper(Context t) {
        this.mContext = t;
    }

    public void LightScreen() {
        this.pm = (PowerManager) this.mContext.getSystemService("power");
        this.mKeyguardManager = (KeyguardManager) this.mContext.getSystemService("keyguard");
        this.wakeLock = this.pm.newWakeLock(805306394, "SimpleTimer");
        this.wakeLock.acquire();
        this.mKeyguardLock = this.mKeyguardManager.newKeyguardLock(BuildConfig.FLAVOR);
        this.mKeyguardLock.disableKeyguard();
    }

    public void releaseLight() {
        this.wakeLock.release();
        this.mKeyguardLock.reenableKeyguard();
    }

    public void lockScreen() {
        this.pm = (PowerManager) this.mContext.getSystemService("power");
        this.mKeyguardManager = (KeyguardManager) this.mContext.getSystemService("keyguard");
        this.wakeLock = this.pm.newWakeLock(805306394, "SimpleTimer");
        this.wakeLock.acquire();
    }

    public void releaseLock() {
        this.wakeLock.release();
    }

    public void lightScreen(int iMsec) {
        this.pm = (PowerManager) this.mContext.getSystemService("power");
        this.mKeyguardManager = (KeyguardManager) this.mContext.getSystemService("keyguard");
        this.wakeLock = this.pm.newWakeLock(805306394, "SimpleTimer");
        this.wakeLock.acquire(iMsec);
    }

    void stopTone() {
        if (this.ringbackPlayer != null) {
            this.ringbackPlayer.stopTone();
        }
    }

    void playRing() {
        this.mMediaPlayer = MediaPlayer.create(MainHelper.context, getDefaultRingtoneUri(1));
        this.mMediaPlayer.setLooping(true);
        this.mMediaPlayer.start();
    }

    void stopRing() {
        if (this.mMediaPlayer != null) {
            this.mMediaPlayer.stop();
        }
    }

    public Ringtone getDefaultRingtone(int type) {
        return RingtoneManager.getRingtone(MainHelper.context, RingtoneManager.getActualDefaultRingtoneUri(MainHelper.context, type));
    }

    public Uri getDefaultRingtoneUri(int type) {
        return RingtoneManager.getActualDefaultRingtoneUri(MainHelper.context, type);
    }

    public List<Ringtone> getRingtoneList(int type) {
        List<Ringtone> resArr = new ArrayList<>();
        RingtoneManager manager = new RingtoneManager(MainHelper.context);
        manager.setType(type);
        Cursor cursor = manager.getCursor();
        int count = cursor.getCount();
        for (int i = 0; i < count; i++) {
            resArr.add(manager.getRingtone(i));
        }
        return resArr;
    }

    public Ringtone getRingtone(int type, int pos) {
        RingtoneManager manager = new RingtoneManager(MainHelper.context);
        manager.setType(type);
        return manager.getRingtone(pos);
    }

    public List<String> getRingtoneTitleList(int type) {
        List<String> resArr = new ArrayList<>();
        RingtoneManager manager = new RingtoneManager(MainHelper.context);
        manager.setType(type);
        Cursor cursor = manager.getCursor();
        if (cursor.moveToFirst()) {
            do {
                resArr.add(cursor.getString(1));
            } while (cursor.moveToNext());
            return resArr;
        }
        return resArr;
    }

    public String getRingtoneUriPath(int type, int pos, String def) {
        RingtoneManager manager = new RingtoneManager(MainHelper.context);
        manager.setType(type);
        Uri uri = manager.getRingtoneUri(pos);
        if (uri == null) {
            return def;
        }
        String def2 = uri.toString();
        return def2;
    }

    public Ringtone getRingtoneByUriPath(int type, String uriPath) {
        RingtoneManager manager = new RingtoneManager(MainHelper.context);
        manager.setType(type);
        Uri uri = Uri.parse(uriPath);
        return RingtoneManager.getRingtone(MainHelper.context, uri);
    }
}
