package com.RanaEman.client.main.data;

import com.RanaEman.client.main.MainHelper;
import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class OnlineCenter {
    public static Map<String, OnlineData> onlineDevice = new HashMap();

    public static synchronized void addOnline(String dest_ipaddr, String dest_port, String mac) {
        synchronized (OnlineCenter.class) {
            if (onlineDevice.containsKey(mac)) {
                onlineDevice.remove(mac);
            }
            OnlineData oData = new OnlineData();
            oData.mac = mac;
            oData.ip = dest_ipaddr.toString();
            oData.port = dest_port;
            oData.lastCmdTime = System.currentTimeMillis();
            onlineDevice.put(mac, oData);
        }
    }

    public static Boolean isOnline(String mac) {
        return Boolean.valueOf(onlineDevice.containsKey(mac));
    }

    public static synchronized void removeOnline(String mac) {
        synchronized (OnlineCenter.class) {
            onlineDevice.remove(mac);
        }
    }

    public static String getDeviceIp(String mac) {
        if (onlineDevice.containsKey(mac)) {
            OnlineData oData = onlineDevice.get(mac);
            return oData.ip;
        }
        return BuildConfig.FLAVOR;
    }

    public static void removeOnline(String proto, String dest_ipaddr, String dest_port) {
        String ip = dest_ipaddr.toString();
        for (Map.Entry<String, OnlineData> entry : onlineDevice.entrySet()) {
            String key = entry.getKey();
            OnlineData val = entry.getValue();
            if (val != null && proto.equalsIgnoreCase(val.proto) && ip.equalsIgnoreCase(val.ip) && dest_port.equalsIgnoreCase(val.port)) {
                removeOnline(key);
                return;
            }
        }
    }

    public static OnlineData getOnlineData(String mac) {
        if (onlineDevice.containsKey(mac)) {
            return onlineDevice.get(mac);
        }
        return null;
    }

    public static void removeAllOnline() {
        onlineDevice.clear();
    }

    public static String getFirstOnlineDevice() {
        for (Map.Entry<String, OnlineData> entry : onlineDevice.entrySet()) {
            entry.getKey();
            OnlineData val = entry.getValue();
            if (val != null && val.mac != MainHelper.getLocalMac()) {
                return val.mac;
            }
        }
        return BuildConfig.FLAVOR;
    }
}
