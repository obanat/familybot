package com.RanaEman.client.main;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.RanaEman.client.main.exchange.CmdParam;
import com.RanaEman.client.main.exchange.ExchangeMessage;
import com.RanaEman.client.main.exchange.GroupMessageSrvCodec;
import com.RanaEman.client.main.exchange.OnExchangeRecvListener;
import com.RanaEman.client.main.exchange.TcpExchange;
import com.RanaEman.client.main.exchange.UdpExchange;
import com.RanaEman.client.main.net.IpAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public class MainExchange implements OnExchangeRecvListener {
    public static final int TimeOut_Cmd = 1;
    private Timer CmdTimeOutTimer;
    private int nListenPort = 12903;
    private UdpExchange udpExchange = null;
    private MainCmdComingListener cmdComingListener = null;
    private MainCmdRespListener cmdRespListener = null;
    private ConcurrentHashMap<String, TaskInfo> taskContainer = new ConcurrentHashMap<>();
    private int nTaskId = 1001;
    Handler handler = new Handler() { // from class: com.RanaEman.client.main.MainExchange.3
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    MainExchange.this.checkTaskTimeout();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    public boolean start() {
        startCmdTimeOutTimer();
        this.udpExchange = new UdpExchange();
        this.udpExchange.listenPort = this.nListenPort;
        this.udpExchange.setOnExchangeRecvListener(this);
        return this.udpExchange.start().booleanValue();
    }

    public void stop() {
        stopCmdTimeOutTimer();
        if (this.udpExchange != null) {
            this.udpExchange.halt();
            this.udpExchange = null;
        }
    }

    public void setCmdComingListner(MainCmdComingListener l) {
        this.cmdComingListener = l;
    }

    public void setCmdRespListner(MainCmdRespListener l) {
        this.cmdRespListener = l;
    }

    /* loaded from: classes.dex */
    public class TaskInfo {
        public int reTryTimes = 0;
        public String taskId;
        public ExchangeMessage taskMsg;
        public long taskTime;

        public TaskInfo() {
            //MainExchange.this = this$0;
        }
    }

    public void sendMessage(final ExchangeMessage msg, final boolean needRecord) {
        new Thread(null, new Runnable() { // from class: com.RanaEman.client.main.MainExchange.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    Log.e("sendMessage", String.format("begin to realSendMessage, rowMessage is : %s", msg.getTextMessage2Send()));
                    MainExchange.this.realSendMessage(msg, needRecord);
                } catch (Exception e) {
                    Log.e("OnExchangeRecv", String.format("Exception when realSendMessage, rowMessage is : %s, exception info is : %s", msg.getTextMessage2Send(), e.getMessage()));
                }
            }
        }, "bgd_snd").start();
    }

    public synchronized boolean realSendMessage(ExchangeMessage msg, boolean needRecord) {
        boolean z = false;
        synchronized (this) {
            if (msg == null) {
                Log.e("MainExchange|sendMessage", "null");
            } else if (!msg.containsKey(CmdParam.ip).booleanValue() || !msg.containsKey(CmdParam.port).booleanValue()) {
                Log.e("MainExchange|sendMessage", "缺少必要参数1001");
            } else {
                String ip = (String) msg.get(CmdParam.ip);
                if (!ip.isEmpty()) {
                    String port = (String) msg.get(CmdParam.port);
                    if (!port.isEmpty()) {
                        int dest_port = Integer.valueOf(port).intValue();
                        IpAddress dest_ipaddr = new IpAddress(ip);
                        String textMsg = msg.getTextMessage2Send();
                        if (textMsg == com.jeremyfeinstein.slidingmenu.lib.BuildConfig.FLAVOR || textMsg.length() == 0) {
                            Log.e("MainExchange|sendMessage", "getTextMessage2Send failed");
                        } else {
                            this.udpExchange.sendMessage(dest_ipaddr, dest_port, textMsg);
                            if (needRecord) {
                                String taskId = (String) msg.get(CmdParam.taskId);
                                addTask(taskId, msg);
                            }
                            z = true;
                        }
                    }
                }
            }
        }
        return z;
    }

    public String getNextTaskId() {
        this.nTaskId++;
        return String.valueOf(this.nTaskId);
    }

    public void addTask(String taskId, ExchangeMessage msg) {
        TaskInfo ti = new TaskInfo();
        ti.taskId = taskId;
        ti.taskMsg = msg;
        ti.reTryTimes = 0;
        ti.taskTime = System.currentTimeMillis();
        this.taskContainer.put(taskId, ti);
    }

    public void removeTask(String taskId) {
        this.taskContainer.remove(taskId);
    }

    public TaskInfo getTask(String taskId) {
        if (this.taskContainer.containsKey(taskId)) {
            return this.taskContainer.get(taskId);
        }
        return null;
    }

    public void startCmdTimeOutTimer() {
        stopCmdTimeOutTimer();
        this.CmdTimeOutTimer = new Timer(true);
        this.CmdTimeOutTimer.schedule(new TimerTask() { // from class: com.RanaEman.client.main.MainExchange.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                Message message = MainExchange.this.handler.obtainMessage();
                message.what = 1;
                MainExchange.this.handler.sendMessage(message);
            }
        }, 1000L, 1000L);
    }

    public void stopCmdTimeOutTimer() {
        if (this.CmdTimeOutTimer != null) {
            this.CmdTimeOutTimer.cancel();
            this.CmdTimeOutTimer = null;
        }
    }

    public void checkTaskTimeout() {
        this.udpExchange.checkStatus();
        long now = System.currentTimeMillis();
        Iterator iter = this.taskContainer.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<String, TaskInfo> entry = (Map.Entry<String, TaskInfo>) iter.next();
            String taskId = entry.getKey();
            TaskInfo val = entry.getValue();
            if (now - val.taskTime > 5000) {
                if (val.reTryTimes >= 3) {
                    iter.remove();
                    if (this.cmdRespListener != null) {
                        this.cmdRespListener.onCmdTimeout(taskId, val.taskMsg);
                    }
                    Log.v("checkTaskTimeout", "命令超时，删除" + val.taskMsg.getTextMessage2Send());
                } else {
                    val.taskTime = System.currentTimeMillis();
                    val.reTryTimes++;
                    sendMessage(val.taskMsg, false);
                    Log.v("checkTaskTimeout", String.format("第%d次重发命令:%s", Integer.valueOf(val.reTryTimes), val.taskMsg.getTextMessage2Send()));
                }
            }
        }
    }

    @Override // com.RanaEman.client.main.exchange.OnExchangeRecvListener
    public void OnExchangeRecv(String rowMessage, String fromIp, String fromPort, String proto) {
        Log.v("OnExchangeRecv", String.format("begin OnExchangeRecv, rowMessage is : %s", rowMessage));
        Map<String, Object> mapData = new HashMap<>();
        mapData.put(CmdParam.ip, fromIp);
        mapData.put(CmdParam.port, fromPort);
        mapData.put(CmdParam.proto, proto);
        if (!GroupMessageSrvCodec.baseDecode(rowMessage, mapData).booleanValue()) {
            Log.v("OnExchangeRecv", "baseDecode failed");
            return;
        }
        String str = (String) mapData.get(CmdParam.cmd);
        String taskId = (String) mapData.get(CmdParam.taskId);
        String isResp = (String) mapData.get(CmdParam.isResp);
        if (isResp.equalsIgnoreCase(CmdParam.deviceType_dvr)) {
            TaskInfo ti = getTask(taskId);
            ExchangeMessage sendMsg = null;
            if (ti != null) {
                sendMsg = ti.taskMsg;
            }
            if (this.cmdRespListener != null) {
                try {
                    Log.e("OnExchangeRecv", String.format("cmdRespListener.onCmdResp, rowMessage is : %s", rowMessage));
                    this.cmdRespListener.onCmdResp(taskId, sendMsg, mapData);
                } catch (Exception e) {
                    Log.e("OnExchangeRecv", String.format("Exception in cmdRespListener.onCmdResp, rowMessage is : %s , exception info is %s", rowMessage, e.getMessage()));
                    e.printStackTrace();
                }
            } else {
                Log.e("OnExchangeRecv", String.format("cmdRespListener is null, rowMessage is : %s", rowMessage));
            }
            removeTask(taskId);
        } else if (this.cmdComingListener != null) {
            Log.e("OnExchangeRecv", String.format("cmdComingListener.onCmdComing, rowMessage is : %s", rowMessage));
            this.cmdComingListener.onCmdComing(mapData);
        } else {
            Log.e("OnExchangeRecv", String.format("cmdComingListener is null, rowMessage is : %s", rowMessage));
        }
    }

    @Override // com.RanaEman.client.main.exchange.OnExchangeRecvListener
    public void OnExchangeConnectionTerminated(TcpExchange tcp, Exception error) {
    }
}
