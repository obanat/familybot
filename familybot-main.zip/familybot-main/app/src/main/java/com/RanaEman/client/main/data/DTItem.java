package com.RanaEman.client.main.data;

/* loaded from: classes.dex */
public class DTItem {
    public int DT_ExprissonID;
    public int DT_ExprissonSound_ID;
    public int DT_ID;
    public String DT_Lable;
    public int DT_RepeatKind;
    public int DT_TimeKind;
    public byte[] DT_Date = new byte[12];
    public byte[] DT_Time = new byte[8];

    public String toString() {
        return this.DT_Lable;
    }
}
