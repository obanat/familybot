package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class Identifier {
    String id;

    public Identifier() {
    }

    public Identifier(String id) {
        this.id = id;
    }

    public Identifier(Identifier i) {
        this.id = i.id;
    }

    public boolean equals(Object obj) {
        try {
            Identifier i = (Identifier) obj;
            return this.id.equals(i.id);
        } catch (Exception e) {
            return false;
        }
    }

    public int hashCode() {
        return this.id.hashCode();
    }

    public String toString() {
        return this.id;
    }
}
