package com.RanaEman.client.main.data;

/* loaded from: classes.dex */
public class MsgItem {
    public String content;
    public String deviceMac;
    public int flag;
    public int msg_id;
    public int status;
    public String time;

    public String toString() {
        return this.content;
    }
}
