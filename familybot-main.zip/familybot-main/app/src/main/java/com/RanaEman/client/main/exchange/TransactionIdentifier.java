package com.RanaEman.client.main.exchange;

/* loaded from: classes.dex */
public class TransactionIdentifier extends Identifier {
    public TransactionIdentifier(TransactionIdentifier i) {
        super(i);
    }

    public TransactionIdentifier(String method) {
        this.id = method;
    }

    public TransactionIdentifier(String call_id, long seqn, String method, String sent_by, String branch) {
        if (branch == null) {
        }
    }
}
