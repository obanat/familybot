package com.RanaEman.client.main.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/* loaded from: classes.dex */
public class DeviceDBAdapter {
    private static final String DATABASE_CREATE = "create table tbl_device (device_id INTEGER PRIMARY KEY, device_type INTEGER, name TEXT, mac TEXT, PHONENUMBER TEXT, status INTEGER);";
    private static final String DATABASE_NAME = "iGroupSrv.db";
    private static final String DATABASE_TABLE = "tbl_device";
    private static final int DATABASE_VERSION = 2;
    public static final String DEVICE_ID = "device_id";
    public static final String DEVICE_TYPE = "device_type";
    public static final String MAC = "mac";
    public static final String NAME = "name";
    public static final String PHONENUMBER = "PHONENUMBER";
    public static final String STATUS = "status";
    private DatabaseHelper DBHelper;
    private final Context context;
    private SQLiteDatabase db;

    public DeviceDBAdapter(Context ctx) {
        this.context = ctx;
        this.DBHelper = new DatabaseHelper(this.context);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context, DeviceDBAdapter.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 2);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DeviceDBAdapter.DATABASE_CREATE);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS tbl_device");
            onCreate(db);
        }
    }

    public SQLiteDatabase open() throws SQLException {
        this.db = this.DBHelper.getWritableDatabase();
        return this.db;
    }

    public void close() {
        this.DBHelper.close();
    }

    public long insert(DeviceItem item) {
        Log.e("DeviceDBAdapter", "begin insert");
        ContentValues initialValues = new ContentValues();
        initialValues.put("device_type", Integer.valueOf(item.device_type));
        initialValues.put(NAME, item.name);
        initialValues.put("mac", item.mac);
        initialValues.put(PHONENUMBER, item.phone_number);
        initialValues.put("status", Integer.valueOf(item.status));
        Log.e("DeviceDBAdapter", "插入数据成功");
        return this.db.insert(DATABASE_TABLE, null, initialValues);
    }

    public boolean delete(int deviceId) {
        return this.db.delete(DATABASE_TABLE, new StringBuilder().append("device_id=").append(deviceId).toString(), null) > 0;
    }

    public boolean delete(String mac) {
        return this.db.delete(DATABASE_TABLE, new StringBuilder().append("mac=").append(mac).toString(), null) > 0;
    }

    public void deleteAll() {
        this.db.delete(DATABASE_TABLE, null, null);
    }

    public boolean update(DeviceItem item) {
        ContentValues initialValues = new ContentValues();
        initialValues.put("device_type", Integer.valueOf(item.device_type));
        initialValues.put(NAME, item.name);
        initialValues.put("mac", item.mac);
        initialValues.put(PHONENUMBER, item.phone_number);
        initialValues.put("status", Integer.valueOf(item.status));
        return this.db.update(DATABASE_TABLE, initialValues, new StringBuilder().append("mac=").append(item.mac).toString(), null) > 0;
    }

    public Cursor getAll() {
        Cursor cur = this.db.query(DATABASE_TABLE, null, null, null, null, null, null);
        return cur;
    }

    public Cursor get(long deviceId) throws SQLException {
        Cursor cur = this.db.query(true, DATABASE_TABLE, null, "device_id=" + deviceId, null, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }

    public Cursor getDeviceByMac(String mac) throws SQLException {
        String[] selectionArgs = {mac};
        Cursor cur = this.db.query(true, DATABASE_TABLE, null, "MAC=?", selectionArgs, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur;
    }

    public int getDeviceIdByMac(String mac) throws SQLException {
        Cursor cur = this.db.query(true, DATABASE_TABLE, null, "mac=" + mac, null, null, null, null, null);
        if (cur != null) {
            cur.moveToFirst();
        }
        return cur.getInt(0);
    }
}
