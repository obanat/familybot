package com.RanaEman.client.main.exchange;

import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class ExchangeMessage {
    private Map<String, Object> paramters = new HashMap();
    private String strCmd = BuildConfig.FLAVOR;

    public void addParamter(String key, Object value) {
        this.paramters.put(key, value);
    }

    public Boolean containsKey(String key) {
        return Boolean.valueOf(this.paramters.containsKey(key));
    }

    public Object get(String key) {
        return this.paramters.get(key);
    }

    public String getTextMessage2Send() {
        if (this.strCmd.isEmpty()) {
            this.strCmd = GroupMessageSrvCodec.baseEncode(this.paramters);
        }
        return this.strCmd;
    }
}
