package com.RanaEman.client.main.exchange;

import com.jeremyfeinstein.slidingmenu.lib.BuildConfig;
import java.util.Map;

/* loaded from: classes.dex */
public class GroupMessageSrvCodec {
    public static Boolean baseDecode(byte[] inData, Map<String, Object> outData) {
        String rowMessage = String.valueOf(inData);
        return baseDecode(rowMessage, outData);
    }

    public static Boolean baseDecode(String rowMessage, Map<String, Object> outData) {
        return rowMessage.startsWith("AT+") ? GroupMsgCodecNormal.baseDecode(rowMessage, outData) : GroupMsgCodecJson.baseDecode(rowMessage, outData);
    }

    public static String baseEncode(Map<String, Object> sendData) {
        String cmdFormat;
        if (!sendData.containsKey(CmdParam.cmdFormat)) {
            cmdFormat = CmdParam.FormatJson;
        } else {
            cmdFormat = (String) sendData.get(CmdParam.cmdFormat);
        }
        if (cmdFormat.equalsIgnoreCase(CmdParam.FormatJson)) {
            return GroupMsgCodecJson.baseEncode(sendData);
        }
        if (cmdFormat.equalsIgnoreCase(CmdParam.FormatNormal)) {
            return GroupMsgCodecNormal.baseEncode(sendData);
        }
        return BuildConfig.FLAVOR;
    }
}
